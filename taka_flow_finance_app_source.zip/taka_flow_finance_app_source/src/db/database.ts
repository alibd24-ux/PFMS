// ============================================================================
// PHASE 1: INDEXEDDB STORAGE ENGINE, SCHEMA MIGRATIONS & SEED REPOSITORY
// Implements all 19 normalized object stores, indexes, schema versioning (v2),
// atomic multi-store read/write transactions, and initial seed records.
// ============================================================================

import {
  Account,
  AppNotification,
  AppSettings,
  Attachment,
  AuditLog,
  Budget,
  BudgetCategory,
  Category,
  Contact,
  DatabaseSnapshot,
  DebtPayment,
  DebtRecord,
  LoanPayment,
  LoanRecord,
  LoanScheduleItem,
  RecurringTransaction,
  SavingsContribution,
  SavingsGoal,
  Subcategory,
  Transaction,
  TransactionSplit,
} from '../types/models';

export const DB_NAME = 'TakaFlowProDB';
export const CURRENT_SCHEMA_VERSION = 2;
const FALLBACK_STORAGE_KEY = 'takaflow_pro_db_snapshot_v2';
const PRE_RESTORE_BACKUP_KEY = 'takaflow_pro_pre_restore_backup_v2';

export const STORE_NAMES = [
  'AppSettings',
  'Accounts',
  'Transactions',
  'TransactionSplits',
  'Categories',
  'Subcategories',
  'Budgets',
  'BudgetCategories',
  'Contacts',
  'Debts',
  'DebtPayments',
  'Loans',
  'LoanPayments',
  'SavingsGoals',
  'SavingsContributions',
  'RecurringTransactions',
  'Attachments',
  'Notifications',
  'AuditLogs',
] as const;

export function generateLoanSchedule(
  principalPoisha: number,
  interestRateAnnual: number,
  totalInstallments: number,
  startDate: string
): { installmentAmountPoisha: number; schedule: LoanScheduleItem[] } {
  const n = Math.max(1, Math.round(totalInstallments));
  const schedule: LoanScheduleItem[] = [];
  const start = new Date(startDate + 'T00:00:00');

  if (!interestRateAnnual || interestRateAnnual <= 0) {
    const baseInstallment = Math.floor(principalPoisha / n);
    let remaining = principalPoisha;
    for (let i = 1; i <= n; i++) {
      const due = new Date(start);
      due.setMonth(due.getMonth() + i);
      const dueStr = due.toISOString().slice(0, 10);
      const principalPart = i === n ? remaining : baseInstallment;
      remaining = Math.max(0, remaining - principalPart);
      schedule.push({
        installmentNumber: i,
        dueDate: dueStr,
        installmentPoisha: principalPart,
        principalPoisha: principalPart,
        interestPoisha: 0,
        remainingBalancePoisha: remaining,
        isPaid: false,
      });
    }
    return { installmentAmountPoisha: baseInstallment, schedule };
  }

  const r = interestRateAnnual / 12 / 100;
  const factor = Math.pow(1 + r, n);
  const emiPoisha = Math.round((principalPoisha * r * factor) / (factor - 1));
  let remaining = principalPoisha;

  for (let i = 1; i <= n; i++) {
    const due = new Date(start);
    due.setMonth(due.getMonth() + i);
    const dueStr = due.toISOString().slice(0, 10);
    const interestPart = Math.round(remaining * r);
    const principalPart = i === n ? remaining : Math.min(remaining, Math.max(0, emiPoisha - interestPart));
    const actualInstallment = principalPart + interestPart;
    remaining = Math.max(0, remaining - principalPart);
    schedule.push({
      installmentNumber: i,
      dueDate: dueStr,
      installmentPoisha: actualInstallment,
      principalPoisha: principalPart,
      interestPoisha: interestPart,
      remainingBalancePoisha: remaining,
      isPaid: false,
    });
  }

  return { installmentAmountPoisha: emiPoisha, schedule };
}

export function createInitialSeedSnapshot(): DatabaseSnapshot {
  const now = '2026-11-06T09:00:00.000Z';

  const settings: AppSettings = {
    id: 'default_settings',
    appName: 'TakaFlow Pro',
    language: 'en',
    defaultCurrency: 'BDT',
    dateFormat: 'DD MMM YYYY',
    numberFormat: 'bd_lakh',
    firstDayOfWeek: 'saturday',
    financialMonthStartDay: 1,
    theme: 'light',
    accentColor: 'emerald',
    fontSize: 'md',
    dashboardLayout: 'standard',
    navigationLayout: 'bottom_bar',
    defaultAccountId: 'acc_bank',
    defaultTransactionType: 'expense',
    defaultBudgetPeriod: 'monthly',
    budgetWarningThresholds: [50, 75, 90, 100],
    currencyPrecision: 2,
    exchangeRates: {
      BDT: 1,
      USD: 120,
      EUR: 130,
      GBP: 152,
      INR: 1.42,
    },
    notificationsConfig: {
      budgetAlerts: true,
      paymentReminders: true,
      recurringReminders: true,
      debtDueReminders: true,
      savingsReminders: true,
    },
    enabledModules: {
      budgets: true,
      debts: true,
      loans: true,
      savings: true,
      recurring: true,
      reports: true,
    },
    schemaVersion: CURRENT_SCHEMA_VERSION,
    updatedAt: now,
  };

  // 8 Default Customizable Accounts
  const accounts: Account[] = [
    {
      id: 'acc_cash',
      name: 'Cash Wallet',
      nameBn: 'নগদ ক্যাশ',
      type: 'cash',
      openingBalancePoisha: 1500000, // ৳ 15,000.00
      currentBalancePoisha: 1500000,
      currency: 'BDT',
      icon: 'Wallet',
      color: '#10b981',
      description: 'Daily physical cash in hand',
      alertThresholdPoisha: 200000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_bank',
      name: 'Bank Account (City Bank)',
      nameBn: 'ব্যাংক অ্যাকাউন্ট',
      type: 'bank',
      openingBalancePoisha: 8500000, // ৳ 85,000.00
      currentBalancePoisha: 8500000,
      currency: 'BDT',
      icon: 'Landmark',
      color: '#3b82f6',
      description: 'Primary salary & checking bank account',
      alertThresholdPoisha: 1000000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_savings',
      name: 'Savings Account (FDR/DPS)',
      nameBn: 'সঞ্চয়ী হিসাব',
      type: 'savings',
      openingBalancePoisha: 12000000, // ৳ 1,20,000.00
      currentBalancePoisha: 12000000,
      currency: 'BDT',
      icon: 'PiggyBank',
      color: '#0d9488',
      description: 'Long-term reserve & emergency savings',
      alertThresholdPoisha: 2500000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_cc',
      name: 'Credit Card (Visa Signature)',
      nameBn: 'ক্রেডিট কার্ড',
      type: 'credit_card',
      openingBalancePoisha: 0,
      currentBalancePoisha: 0,
      currency: 'BDT',
      icon: 'CreditCard',
      color: '#8b5cf6',
      description: 'Credit card revolving account',
      alertThresholdPoisha: 0,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_bkash',
      name: 'bKash Personal',
      nameBn: 'বিকাশ ওয়ালেট',
      type: 'mobile_wallet',
      openingBalancePoisha: 1250000, // ৳ 12,500.00
      currentBalancePoisha: 1250000,
      currency: 'BDT',
      icon: 'Smartphone',
      color: '#e11d48',
      description: 'bKash MFS account for bills & sends',
      alertThresholdPoisha: 100000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_nagad',
      name: 'Nagad Wallet',
      nameBn: 'নগদ ওয়ালেট',
      type: 'mobile_wallet',
      openingBalancePoisha: 650000, // ৳ 6,500.00
      currentBalancePoisha: 650000,
      currency: 'BDT',
      icon: 'Smartphone',
      color: '#f97316',
      description: 'Nagad MFS wallet',
      alertThresholdPoisha: 50000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_rocket',
      name: 'Rocket (DBBL)',
      nameBn: 'রকেট ওয়ালেট',
      type: 'mobile_wallet',
      openingBalancePoisha: 300000, // ৳ 3,000.00
      currentBalancePoisha: 300000,
      currency: 'BDT',
      icon: 'Smartphone',
      color: '#7c3aed',
      description: 'DBBL Rocket mobile banking',
      alertThresholdPoisha: 50000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'acc_other',
      name: 'Other USD Wallet',
      nameBn: 'অন্যান্য ওয়ালেট (USD)',
      type: 'other',
      openingBalancePoisha: 25000, // $ 250.00
      currentBalancePoisha: 25000,
      currency: 'USD',
      icon: 'Globe',
      color: '#64748b',
      description: 'Freelance multi-currency wallet',
      alertThresholdPoisha: 5000,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
  ];

  // 16 Default Expense Categories + Office Group + 8 Default Income Categories
  const categories: Category[] = [
    { id: 'cat_food', name: 'Food', nameBn: 'খাবার ও রেস্তোরাঁ', type: 'expense', groupName: 'Essential', icon: 'Utensils', color: '#f97316', sortOrder: 1, monthlyLimitPoisha: 500000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_grocery', name: 'Grocery', nameBn: 'কাঁচাবাজার ও মুদি', type: 'expense', groupName: 'Essential', icon: 'ShoppingBag', color: '#10b981', sortOrder: 2, monthlyLimitPoisha: 600000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_transport', name: 'Transportation', nameBn: 'যাতায়াত ও পরিবহন', type: 'expense', groupName: 'Essential', icon: 'Car', color: '#3b82f6', sortOrder: 3, monthlyLimitPoisha: 300000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_shopping', name: 'Shopping', nameBn: 'কেনাকাটা', type: 'expense', groupName: 'Personal', icon: 'ShoppingBag', color: '#ec4899', sortOrder: 4, monthlyLimitPoisha: 300000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_rent', name: 'Rent', nameBn: 'বাসা ভাড়া', type: 'expense', groupName: 'Essential', icon: 'Home', color: '#6366f1', sortOrder: 5, monthlyLimitPoisha: 400000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_electricity', name: 'Electricity', nameBn: 'বিদ্যুৎ বিল', type: 'expense', groupName: 'Essential', icon: 'Zap', color: '#eab308', sortOrder: 6, monthlyLimitPoisha: 150000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_gas', name: 'Gas', nameBn: 'গ্যাস বিল', type: 'expense', groupName: 'Essential', icon: 'Flame', color: '#ef4444', sortOrder: 7, monthlyLimitPoisha: 108000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_internet', name: 'Internet', nameBn: 'ইন্টারনেট ও মোবাইল', type: 'expense', groupName: 'Essential', icon: 'Wifi', color: '#06b6d4', sortOrder: 8, monthlyLimitPoisha: 120000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_medical', name: 'Medical', nameBn: 'চিকিৎসা ও ওষুধ', type: 'expense', groupName: 'Family', icon: 'HeartPulse', color: '#f43f5e', sortOrder: 9, monthlyLimitPoisha: 200000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_education', name: 'Education', nameBn: 'শিক্ষা ও বই', type: 'expense', groupName: 'Family', icon: 'GraduationCap', color: '#8b5cf6', sortOrder: 10, monthlyLimitPoisha: 250000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_entertainment', name: 'Entertainment', nameBn: 'বিনোদন ও সাবস্ক্রিপশন', type: 'expense', groupName: 'Personal', icon: 'Film', color: '#a855f7', sortOrder: 11, monthlyLimitPoisha: 150000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_family', name: 'Family', nameBn: 'পরিবার ও স্বজন', type: 'expense', groupName: 'Family', icon: 'Users', color: '#14b8a6', sortOrder: 12, monthlyLimitPoisha: 500000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_office', name: 'Office', nameBn: 'অফিস ও কর্মক্ষেত্র', type: 'expense', groupName: 'Office', icon: 'Briefcase', color: '#0284c7', sortOrder: 13, monthlyLimitPoisha: 200000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_travel', name: 'Travel', nameBn: 'ভ্রমণ', type: 'expense', groupName: 'Personal', icon: 'Plane', color: '#0ea5e9', sortOrder: 14, monthlyLimitPoisha: 300000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_personal_care', name: 'Personal Care', nameBn: 'ব্যক্তিগত যত্ন', type: 'expense', groupName: 'Personal', icon: 'Sparkles', color: '#d946ef', sortOrder: 15, monthlyLimitPoisha: 100000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_investment', name: 'Investment', nameBn: 'বিনিয়োগ', type: 'expense', groupName: 'Financial', icon: 'TrendingUp', color: '#059669', sortOrder: 16, monthlyLimitPoisha: 500000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_others_exp', name: 'Others', nameBn: 'অন্যান্য ব্যয়', type: 'expense', groupName: 'Personal', icon: 'MoreHorizontal', color: '#64748b', sortOrder: 17, monthlyLimitPoisha: 200000, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },

    // Income Categories (8 Default)
    { id: 'cat_salary', name: 'Salary', nameBn: 'বেতন (Salary)', type: 'income', groupName: 'Income', icon: 'Briefcase', color: '#10b981', sortOrder: 1, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_business', name: 'Business', nameBn: 'ব্যবসা', type: 'income', groupName: 'Income', icon: 'Store', color: '#059669', sortOrder: 2, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_freelancing', name: 'Freelancing', nameBn: 'ফ্রিল্যান্সিং', type: 'income', groupName: 'Income', icon: 'Laptop', color: '#0ea5e9', sortOrder: 3, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_bonus', name: 'Bonus', nameBn: 'বোনাস', type: 'income', groupName: 'Income', icon: 'Award', color: '#f59e0b', sortOrder: 4, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_interest', name: 'Interest', nameBn: 'মুনাফা ও সুদ', type: 'income', groupName: 'Income', icon: 'Percent', color: '#6366f1', sortOrder: 5, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_inv_return', name: 'Investment Return', nameBn: 'বিনিয়োগ লভ্যাংশ', type: 'income', groupName: 'Income', icon: 'TrendingUp', color: '#14b8a6', sortOrder: 6, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_gift', name: 'Gift', nameBn: 'উপহার', type: 'income', groupName: 'Income', icon: 'Gift', color: '#ec4899', sortOrder: 7, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
    { id: 'cat_other_inc', name: 'Other Income', nameBn: 'অন্যান্য আয়', type: 'income', groupName: 'Income', icon: 'PlusCircle', color: '#64748b', sortOrder: 8, monthlyLimitPoisha: 0, isEnabled: true, isArchived: false, createdAt: now, updatedAt: now },
  ];

  // Subcategories
  const subcategories: Subcategory[] = [
    { id: 'sub_fam_wife', categoryId: 'cat_family', name: 'Wife', nameBn: 'স্ত্রী', icon: 'Heart', color: '#14b8a6', monthlyLimitPoisha: 200000, isArchived: false, createdAt: now },
    { id: 'sub_fam_children', categoryId: 'cat_family', name: 'Children', nameBn: 'সন্তান', icon: 'Smile', color: '#14b8a6', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_fam_parents', categoryId: 'cat_family', name: 'Parents', nameBn: 'বাবা-মা', icon: 'Users', color: '#14b8a6', monthlyLimitPoisha: 300000, isArchived: false, createdAt: now },
    { id: 'sub_fam_household', categoryId: 'cat_family', name: 'Household', nameBn: 'গৃহস্থালি', icon: 'Home', color: '#14b8a6', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_off_transport', categoryId: 'cat_office', name: 'Transportation', nameBn: 'অফিস যাতায়াত', icon: 'Car', color: '#0284c7', monthlyLimitPoisha: 100000, isArchived: false, createdAt: now },
    { id: 'sub_off_food', categoryId: 'cat_office', name: 'Food', nameBn: 'অফিস লাঞ্চ ও নাস্তা', icon: 'Coffee', color: '#0284c7', monthlyLimitPoisha: 80000, isArchived: false, createdAt: now },
    { id: 'sub_off_recharge', categoryId: 'cat_office', name: 'Mobile Recharge', nameBn: 'মোবাইল রিচার্জ', icon: 'Smartphone', color: '#0284c7', monthlyLimitPoisha: 50000, isArchived: false, createdAt: now },
    { id: 'sub_off_official', categoryId: 'cat_office', name: 'Official Expenses', nameBn: 'দাপ্তরিক খরচ', icon: 'FileText', color: '#0284c7', monthlyLimitPoisha: 100000, isArchived: false, createdAt: now },
    { id: 'sub_shop_general', categoryId: 'cat_shopping', name: 'Shopping', nameBn: 'সাধারণ কেনাকাটা', icon: 'ShoppingBag', color: '#ec4899', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_shop_clothing', categoryId: 'cat_shopping', name: 'Clothing', nameBn: 'পোশাক ও জুতা', icon: 'Shirt', color: '#ec4899', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_shop_electronics', categoryId: 'cat_shopping', name: 'Electronics', nameBn: 'ইলেকট্রনিক্স', icon: 'Laptop', color: '#ec4899', isArchived: false, createdAt: now },
    { id: 'sub_food_dining', categoryId: 'cat_food', name: 'Restaurant & Dining', nameBn: 'রেস্তোরাঁ', icon: 'Utensils', color: '#f97316', monthlyLimitPoisha: 350000, isArchived: false, createdAt: now },
    { id: 'sub_food_snacks', categoryId: 'cat_food', name: 'Tea & Snacks', nameBn: 'চা ও নাস্তা', icon: 'Coffee', color: '#f97316', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_groc_bazar', categoryId: 'cat_grocery', name: 'Fresh Market (Kacha Bazar)', nameBn: 'কাঁচাবাজার', icon: 'ShoppingBag', color: '#10b981', monthlyLimitPoisha: 450000, isArchived: false, createdAt: now },
    { id: 'sub_groc_super', categoryId: 'cat_grocery', name: 'Superstore Staples', nameBn: 'সুপারশপ ও চাল-ডাল', icon: 'ShoppingBag', color: '#10b981', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_trans_rickshaw', categoryId: 'cat_transport', name: 'Rickshaw & CNG', nameBn: 'রিকশা ও সিএনজি', icon: 'Car', color: '#3b82f6', monthlyLimitPoisha: 120000, isArchived: false, createdAt: now },
    { id: 'sub_trans_fuel', categoryId: 'cat_transport', name: 'Fuel & Ride Share', nameBn: 'জ্বালানি ও রাইড শেয়ার', icon: 'Car', color: '#3b82f6', monthlyLimitPoisha: 180000, isArchived: false, createdAt: now },
    { id: 'sub_med_pharmacy', categoryId: 'cat_medical', name: 'Pharmacy & Medicine', nameBn: 'ওষুধ', icon: 'HeartPulse', color: '#f43f5e', monthlyLimitPoisha: 150000, isArchived: false, createdAt: now },
    { id: 'sub_med_doctor', categoryId: 'cat_medical', name: 'Doctor Consultation', nameBn: 'ডাক্তার ভিজিট', icon: 'HeartPulse', color: '#f43f5e', monthlyLimitPoisha: 50000, isArchived: false, createdAt: now },
  ];

  // Contacts
  const contacts: Contact[] = [
    { id: 'con_tanvir', name: 'Tanvir Ahmed', phone: '+8801711-223344', email: 'tanvir@example.com', relation: 'Colleague', notes: 'Short-term personal loan contact', createdAt: now },
    { id: 'con_rafiq', name: 'Rafiqul Islam', phone: '+8801819-556677', email: 'rafiq@example.com', relation: 'Friend', notes: 'Business supply partner', createdAt: now },
    { id: 'con_landlord', name: 'Alhaj Abdul Karim', phone: '+8801911-889900', relation: 'Landlord', notes: 'Apartment 4B house owner', createdAt: now },
  ];

  // Budgets: Monthly (Current & Previous), Weekly, and Yearly Budgets
  const budgets: Budget[] = [
    {
      id: 'bgt_nov_2026',
      name: 'November 2026 Monthly Budget',
      period: 'monthly',
      startDate: '2026-11-01',
      endDate: '2026-11-30',
      totalLimitPoisha: 3000000, // ৳ 30,000.00
      warningThresholds: [50, 75, 90, 100],
      notes: 'Primary household & personal monthly budget (৳30,000)',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'bgt_week_nov_2026',
      name: 'Nov Week 1 Weekly Budget',
      period: 'weekly',
      startDate: '2026-11-01',
      endDate: '2026-11-07',
      totalLimitPoisha: 1500000, // ৳ 15,000.00
      warningThresholds: [50, 75, 90, 100],
      notes: 'First week of November spending cap',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'bgt_year_2026',
      name: 'Annual 2026 Yearly Budget',
      period: 'yearly',
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      totalLimitPoisha: 36000000, // ৳ 3,60,000.00
      warningThresholds: [50, 75, 90, 100],
      notes: 'Full year 2026 household expense budget',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'bgt_oct_2026',
      name: 'October 2026 Monthly Budget',
      period: 'monthly',
      startDate: '2026-10-01',
      endDate: '2026-10-31',
      totalLimitPoisha: 3000000, // ৳ 30,000.00
      warningThresholds: [50, 75, 90, 100],
      notes: 'Previous month benchmark budget',
      createdAt: '2026-10-01T00:00:00.000Z',
      updatedAt: '2026-10-01T00:00:00.000Z',
    },
  ];

  // Category & Subcategory Budget Allocations
  const budgetCategories: BudgetCategory[] = [
    // November 2026 Category Budgets (৳30,000 exact specification)
    { id: 'bc_nov_food', budgetId: 'bgt_nov_2026', categoryId: 'cat_food', allocatedPoisha: 500000 },
    { id: 'bc_nov_grocery', budgetId: 'bgt_nov_2026', categoryId: 'cat_grocery', allocatedPoisha: 600000 },
    { id: 'bc_nov_transport', budgetId: 'bgt_nov_2026', categoryId: 'cat_transport', allocatedPoisha: 300000 },
    { id: 'bc_nov_family', budgetId: 'bgt_nov_2026', categoryId: 'cat_family', allocatedPoisha: 500000 },
    { id: 'bc_nov_medical', budgetId: 'bgt_nov_2026', categoryId: 'cat_medical', allocatedPoisha: 200000 },
    { id: 'bc_nov_shopping', budgetId: 'bgt_nov_2026', categoryId: 'cat_shopping', allocatedPoisha: 300000 },
    { id: 'bc_nov_rent', budgetId: 'bgt_nov_2026', categoryId: 'cat_rent', allocatedPoisha: 400000 },
    { id: 'bc_nov_others', budgetId: 'bgt_nov_2026', categoryId: 'cat_others_exp', allocatedPoisha: 200000 },

    // November 2026 Subcategory Budgets
    { id: 'bc_nov_sub_parents', budgetId: 'bgt_nov_2026', categoryId: 'cat_family', subcategoryId: 'sub_fam_parents', allocatedPoisha: 300000 },
    { id: 'bc_nov_sub_dining', budgetId: 'bgt_nov_2026', categoryId: 'cat_food', subcategoryId: 'sub_food_dining', allocatedPoisha: 350000 },
    { id: 'bc_nov_sub_bazar', budgetId: 'bgt_nov_2026', categoryId: 'cat_grocery', subcategoryId: 'sub_groc_bazar', allocatedPoisha: 450000 },
    { id: 'bc_nov_sub_pharm', budgetId: 'bgt_nov_2026', categoryId: 'cat_medical', subcategoryId: 'sub_med_pharmacy', allocatedPoisha: 150000 },

    // Weekly Budget Allocations
    { id: 'bc_wk_food', budgetId: 'bgt_week_nov_2026', categoryId: 'cat_food', allocatedPoisha: 300000 },
    { id: 'bc_wk_grocery', budgetId: 'bgt_week_nov_2026', categoryId: 'cat_grocery', allocatedPoisha: 500000 },
    { id: 'bc_wk_transport', budgetId: 'bgt_week_nov_2026', categoryId: 'cat_transport', allocatedPoisha: 200000 },
    { id: 'bc_wk_rent', budgetId: 'bgt_week_nov_2026', categoryId: 'cat_rent', allocatedPoisha: 500000 },

    // Yearly Budget Allocations
    { id: 'bc_yr_food', budgetId: 'bgt_year_2026', categoryId: 'cat_food', allocatedPoisha: 6000000 },
    { id: 'bc_yr_grocery', budgetId: 'bgt_year_2026', categoryId: 'cat_grocery', allocatedPoisha: 7200000 },
    { id: 'bc_yr_rent', budgetId: 'bgt_year_2026', categoryId: 'cat_rent', allocatedPoisha: 4800000 },
    { id: 'bc_yr_family', budgetId: 'bgt_year_2026', categoryId: 'cat_family', allocatedPoisha: 6000000 },

    // October 2026 Category Budgets
    { id: 'bc_oct_food', budgetId: 'bgt_oct_2026', categoryId: 'cat_food', allocatedPoisha: 500000 },
    { id: 'bc_oct_grocery', budgetId: 'bgt_oct_2026', categoryId: 'cat_grocery', allocatedPoisha: 600000 },
    { id: 'bc_oct_transport', budgetId: 'bgt_oct_2026', categoryId: 'cat_transport', allocatedPoisha: 300000 },
    { id: 'bc_oct_family', budgetId: 'bgt_oct_2026', categoryId: 'cat_family', allocatedPoisha: 500000 },
    { id: 'bc_oct_medical', budgetId: 'bgt_oct_2026', categoryId: 'cat_medical', allocatedPoisha: 200000 },
    { id: 'bc_oct_shopping', budgetId: 'bgt_oct_2026', categoryId: 'cat_shopping', allocatedPoisha: 300000 },
    { id: 'bc_oct_rent', budgetId: 'bgt_oct_2026', categoryId: 'cat_rent', allocatedPoisha: 400000 },
    { id: 'bc_oct_others', budgetId: 'bgt_oct_2026', categoryId: 'cat_others_exp', allocatedPoisha: 200000 },
  ];

  // Real Transactions stored in DB
  const transactions: Transaction[] = [
    {
      id: 'txn_oct_sal',
      type: 'income',
      amountPoisha: 6500000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-10-01',
      time: '10:15',
      accountId: 'acc_bank',
      categoryId: 'cat_salary',
      description: 'October Monthly Salary Credit',
      notes: 'Credited via EFT',
      tags: ['salary', 'monthly'],
      paymentMethod: 'Bank EFT',
      isSplit: false,
      fingerprint: 'income|acc_bank||cat_salary|6500000|2026-10-01|october monthly salary credit',
      createdAt: '2026-10-01T10:15:00.000Z',
      updatedAt: '2026-10-01T10:15:00.000Z',
    },
    {
      id: 'txn_oct_rent',
      type: 'expense',
      amountPoisha: 400000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-10-03',
      time: '11:00',
      accountId: 'acc_bank',
      categoryId: 'cat_rent',
      contactId: 'con_landlord',
      personName: 'Alhaj Abdul Karim',
      description: 'October House Rent Allocation',
      notes: 'Paid on time',
      tags: ['rent', 'housing'],
      paymentMethod: 'Bank Transfer',
      isSplit: false,
      fingerprint: 'expense|acc_bank||cat_rent|400000|2026-10-03|october house rent allocation',
      createdAt: '2026-10-03T11:00:00.000Z',
      updatedAt: '2026-10-03T11:00:00.000Z',
    },
    {
      id: 'txn_oct_groc',
      type: 'expense',
      amountPoisha: 540000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-10-10',
      time: '18:20',
      accountId: 'acc_cash',
      categoryId: 'cat_grocery',
      subcategoryId: 'sub_groc_bazar',
      description: 'October Monthly Grocery & Bazar',
      notes: 'Rice, oil, vegetables, fish',
      tags: ['bazar', 'grocery'],
      paymentMethod: 'Cash',
      isSplit: false,
      fingerprint: 'expense|acc_cash||cat_grocery|540000|2026-10-10|october monthly grocery & bazar',
      createdAt: '2026-10-10T18:20:00.000Z',
      updatedAt: '2026-10-10T18:20:00.000Z',
    },
    {
      id: 'txn_oct_food',
      type: 'expense',
      amountPoisha: 420000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-10-18',
      time: '20:45',
      accountId: 'acc_bkash',
      categoryId: 'cat_food',
      subcategoryId: 'sub_food_dining',
      description: 'October Family Dining & Snacks',
      notes: 'Weekend dinner',
      tags: ['dining', 'food'],
      paymentMethod: 'bKash',
      isSplit: false,
      fingerprint: 'expense|acc_bkash||cat_food|420000|2026-10-18|october family dining & snacks',
      createdAt: '2026-10-18T20:45:00.000Z',
      updatedAt: '2026-10-18T20:45:00.000Z',
    },
    {
      id: 'txn_nov_sal',
      type: 'income',
      amountPoisha: 6800000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-01',
      time: '09:30',
      accountId: 'acc_bank',
      categoryId: 'cat_salary',
      description: 'November Monthly Salary',
      notes: 'Full salary with performance allowance',
      tags: ['salary', 'november'],
      paymentMethod: 'Bank EFT',
      isSplit: false,
      fingerprint: 'income|acc_bank||cat_salary|6800000|2026-11-01|november monthly salary',
      createdAt: '2026-11-01T09:30:00.000Z',
      updatedAt: '2026-11-01T09:30:00.000Z',
    },
    {
      id: 'txn_nov_freelance',
      type: 'income',
      amountPoisha: 1500000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-02',
      time: '14:10',
      accountId: 'acc_bkash',
      categoryId: 'cat_freelancing',
      description: 'UI/UX Audit Client Milestone',
      notes: 'Remittance cashed to bKash',
      tags: ['freelance', 'design'],
      paymentMethod: 'bKash',
      isSplit: false,
      fingerprint: 'income|acc_bkash||cat_freelancing|1500000|2026-11-02|ui/ux audit client milestone',
      createdAt: '2026-11-02T14:10:00.000Z',
      updatedAt: '2026-11-02T14:10:00.000Z',
    },
    {
      id: 'txn_nov_rent',
      type: 'expense',
      amountPoisha: 400000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-02',
      time: '11:00',
      accountId: 'acc_bank',
      categoryId: 'cat_rent',
      contactId: 'con_landlord',
      personName: 'Alhaj Abdul Karim',
      description: 'November House Rent Share',
      notes: 'Monthly flat rent',
      tags: ['rent', 'fixed'],
      paymentMethod: 'Bank Transfer',
      isSplit: false,
      fingerprint: 'expense|acc_bank||cat_rent|400000|2026-11-02|november house rent share',
      createdAt: '2026-11-02T11:00:00.000Z',
      updatedAt: '2026-11-02T11:00:00.000Z',
    },
    {
      id: 'txn_nov_groc',
      type: 'expense',
      amountPoisha: 465000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-03',
      time: '17:30',
      accountId: 'acc_cash',
      categoryId: 'cat_grocery',
      subcategoryId: 'sub_groc_bazar',
      description: 'Weekly Kacha Bazar & Superstore Staples',
      notes: 'Miniket rice 25kg, soybean oil, vegetables, fish',
      tags: ['bazar', 'weekly'],
      paymentMethod: 'Cash',
      isSplit: false,
      fingerprint: 'expense|acc_cash||cat_grocery|465000|2026-11-03|weekly kacha bazar & superstore staples',
      createdAt: '2026-11-03T17:30:00.000Z',
      updatedAt: '2026-11-03T17:30:00.000Z',
    },
    {
      id: 'txn_nov_family_split',
      type: 'expense',
      amountPoisha: 380000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-04',
      time: '19:00',
      accountId: 'acc_bkash',
      categoryId: 'cat_family',
      subcategoryId: 'sub_fam_parents',
      description: 'Parents Allowance & Monthly Medicine',
      notes: 'Split transaction: ৳2,600 family support + ৳1,200 pharmacy',
      tags: ['family', 'parents', 'medicine'],
      paymentMethod: 'bKash',
      isSplit: true,
      fingerprint: 'expense|acc_bkash||cat_family|380000|2026-11-04|parents allowance & monthly medicine',
      createdAt: '2026-11-04T19:00:00.000Z',
      updatedAt: '2026-11-04T19:00:00.000Z',
    },
    {
      id: 'txn_debt_lent_tanvir',
      type: 'loan_given',
      amountPoisha: 1000000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-03',
      time: '12:00',
      accountId: 'acc_bank',
      categoryId: 'cat_others_exp',
      contactId: 'con_tanvir',
      personName: 'Tanvir Ahmed',
      description: 'Lent to Tanvir Ahmed (Emergency Medical Need)',
      notes: 'Receivable principal - excluded from regular expenses',
      tags: ['pawna', 'receivable'],
      paymentMethod: 'Bank Transfer',
      isSplit: false,
      debtId: 'debt_tanvir_10k',
      fingerprint: 'loan_given|acc_bank||cat_others_exp|1000000|2026-11-03|lent to tanvir ahmed',
      createdAt: '2026-11-03T12:00:00.000Z',
      updatedAt: '2026-11-03T12:00:00.000Z',
    },
    {
      id: 'txn_debt_col_tanvir',
      type: 'debt_collection',
      amountPoisha: 300000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-05',
      time: '16:20',
      accountId: 'acc_bkash',
      categoryId: 'cat_other_inc',
      contactId: 'con_tanvir',
      personName: 'Tanvir Ahmed',
      description: 'Partial Collection from Tanvir Ahmed',
      notes: 'Returned ৳3,000 via bKash; ৳7,000 remaining receivable',
      tags: ['pawna', 'collection'],
      paymentMethod: 'bKash',
      isSplit: false,
      debtId: 'debt_tanvir_10k',
      fingerprint: 'debt_collection|acc_bkash||cat_other_inc|300000|2026-11-05|partial collection from tanvir ahmed',
      createdAt: '2026-11-05T16:20:00.000Z',
      updatedAt: '2026-11-05T16:20:00.000Z',
    },
    {
      id: 'txn_debt_borrowed_rafiq',
      type: 'loan_received',
      amountPoisha: 500000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-04',
      time: '15:00',
      accountId: 'acc_nagad',
      categoryId: 'cat_other_inc',
      contactId: 'con_rafiq',
      personName: 'Rafiqul Islam',
      description: 'Short-term Borrowed from Rafiqul Islam',
      notes: 'Payable Dena record - excluded from regular income',
      tags: ['dena', 'payable'],
      paymentMethod: 'Nagad',
      isSplit: false,
      debtId: 'debt_rafiq_5k',
      fingerprint: 'loan_received|acc_nagad||cat_other_inc|500000|2026-11-04|short-term borrowed from rafiqul islam',
      createdAt: '2026-11-04T15:00:00.000Z',
      updatedAt: '2026-11-04T15:00:00.000Z',
    },
    {
      id: 'txn_nov_transfer',
      type: 'transfer',
      amountPoisha: 500000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-05',
      time: '10:30',
      accountId: 'acc_bank',
      destinationAccountId: 'acc_cash',
      categoryId: 'cat_others_exp',
      description: 'ATM Cash Withdrawal for Daily Expenses',
      notes: 'Internal account transfer',
      tags: ['atm', 'transfer'],
      paymentMethod: 'ATM Card',
      isSplit: false,
      fingerprint: 'transfer|acc_bank|acc_cash|cat_others_exp|500000|2026-11-05|atm cash withdrawal',
      createdAt: '2026-11-05T10:30:00.000Z',
      updatedAt: '2026-11-05T10:30:00.000Z',
    },
    {
      id: 'txn_nov_food_today',
      type: 'expense',
      amountPoisha: 285000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-06',
      time: '13:45',
      accountId: 'acc_cash',
      categoryId: 'cat_food',
      subcategoryId: 'sub_food_dining',
      description: 'Friday Family Lunch at Panshi Restaurant',
      notes: 'Traditional Bengali lunch platter',
      tags: ['lunch', 'family'],
      paymentMethod: 'Cash',
      isSplit: false,
      fingerprint: 'expense|acc_cash||cat_food|285000|2026-11-06|friday family lunch at panshi restaurant',
      createdAt: '2026-11-06T13:45:00.000Z',
      updatedAt: '2026-11-06T13:45:00.000Z',
    },
    {
      id: 'txn_nov_transport_today',
      type: 'expense',
      amountPoisha: 165000,
      currency: 'BDT',
      exchangeRateToBase: 1,
      date: '2026-11-06',
      time: '09:15',
      accountId: 'acc_nagad',
      categoryId: 'cat_transport',
      subcategoryId: 'sub_trans_fuel',
      description: 'CNG & Ride Share Commute Pass',
      notes: 'Weekly commute rides',
      tags: ['commute', 'transport'],
      paymentMethod: 'Nagad',
      isSplit: false,
      fingerprint: 'expense|acc_nagad||cat_transport|165000|2026-11-06|cng & ride share commute pass',
      createdAt: '2026-11-06T09:15:00.000Z',
      updatedAt: '2026-11-06T09:15:00.000Z',
    },
  ];

  const transactionSplits: TransactionSplit[] = [
    {
      id: 'splt_1',
      transactionId: 'txn_nov_family_split',
      categoryId: 'cat_family',
      subcategoryId: 'sub_fam_parents',
      amountPoisha: 260000,
      note: 'Parents monthly pocket support',
    },
    {
      id: 'splt_2',
      transactionId: 'txn_nov_family_split',
      categoryId: 'cat_medical',
      subcategoryId: 'sub_med_pharmacy',
      amountPoisha: 120000,
      note: 'Parents blood pressure & diabetes medicine',
    },
  ];

  // Dena-Pawna Records (Receivables & Payables)
  const debts: DebtRecord[] = [
    {
      id: 'debt_tanvir_10k',
      direction: 'receivable',
      contactId: 'con_tanvir',
      personName: 'Tanvir Ahmed',
      phone: '+8801711-223344',
      principalPoisha: 1000000,
      paidPoisha: 300000,
      remainingPoisha: 700000,
      transactionDate: '2026-11-03',
      dueDate: '2026-11-20',
      reminderDate: '2026-11-06',
      accountId: 'acc_bank',
      purpose: 'Emergency family medical support',
      description: 'Lent ৳10,000; ৳3,000 returned via bKash',
      notes: 'Promised remaining ৳7,000 by Nov 20',
      status: 'partial',
      initialTransactionId: 'txn_debt_lent_tanvir',
      createdAt: '2026-11-03T12:00:00.000Z',
      updatedAt: '2026-11-05T16:20:00.000Z',
    },
    {
      id: 'debt_rafiq_5k',
      direction: 'payable',
      contactId: 'con_rafiq',
      personName: 'Rafiqul Islam',
      phone: '+8801819-556677',
      principalPoisha: 500000,
      paidPoisha: 0,
      remainingPoisha: 500000,
      transactionDate: '2026-11-04',
      dueDate: '2026-11-15',
      reminderDate: '2026-11-06',
      accountId: 'acc_nagad',
      purpose: 'Short-term cash bridge',
      description: 'Borrowed ৳5,000 via Nagad',
      notes: 'Settle after mid-month invoice',
      status: 'active',
      initialTransactionId: 'txn_debt_borrowed_rafiq',
      createdAt: '2026-11-04T15:00:00.000Z',
      updatedAt: '2026-11-04T15:00:00.000Z',
    },
  ];

  const debtPayments: DebtPayment[] = [
    {
      id: 'dp_tanvir_1',
      debtId: 'debt_tanvir_10k',
      transactionId: 'txn_debt_col_tanvir',
      amountPoisha: 300000,
      paymentDate: '2026-11-05',
      accountId: 'acc_bkash',
      type: 'collection',
      note: 'First installment returned via bKash',
      createdAt: '2026-11-05T16:20:00.000Z',
    },
  ];

  const laptopSchedule = generateLoanSchedule(6000000, 9.0, 6, '2026-10-10');
  const phoneSchedule = generateLoanSchedule(3600000, 0, 6, '2026-10-15');

  const loans: LoanRecord[] = [
    {
      id: 'loan_bank_laptop',
      name: 'Workstation Laptop Bank EMI',
      loanType: 'bank',
      lender: 'City Bank Amex EMI',
      principalPoisha: 6000000,
      interestRateAnnual: 9.0,
      loanDate: '2026-10-10',
      totalInstallments: 6,
      installmentAmountPoisha: laptopSchedule.installmentAmountPoisha,
      nextDueDate: laptopSchedule.schedule[0].dueDate,
      remainingPrincipalPoisha: 6000000,
      totalInterestPaidPoisha: 0,
      paidInstallments: 0,
      accountId: 'acc_bank',
      status: 'active',
      schedule: laptopSchedule.schedule,
      notes: '6-month reducing balance EMI',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'loan_0_appliance',
      name: 'Inverter Refrigerator 0% EMI',
      loanType: 'installment',
      lender: 'Transcom Digital 0% EMI',
      principalPoisha: 3600000,
      interestRateAnnual: 0,
      loanDate: '2026-10-15',
      totalInstallments: 6,
      installmentAmountPoisha: phoneSchedule.installmentAmountPoisha,
      nextDueDate: phoneSchedule.schedule[0].dueDate,
      remainingPrincipalPoisha: 3600000,
      totalInterestPaidPoisha: 0,
      paidInstallments: 0,
      accountId: 'acc_bank',
      status: 'active',
      schedule: phoneSchedule.schedule,
      notes: '0% interest installment plan',
      createdAt: now,
      updatedAt: now,
    },
  ];

  const savingsGoals: SavingsGoal[] = [
    {
      id: 'sav_emergency',
      name: 'Emergency Medical & Family Reserve',
      targetAmountPoisha: 20000000,
      savedAmountPoisha: 12000000,
      targetDate: '2027-06-30',
      accountId: 'acc_savings',
      icon: 'ShieldCheck',
      color: '#10b981',
      description: '6 months essential household reserve',
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sav_vacation',
      name: "Cox's Bazar & Sajek Family Tour",
      targetAmountPoisha: 5000000,
      savedAmountPoisha: 2250000,
      targetDate: '2027-01-15',
      accountId: 'acc_savings',
      icon: 'Plane',
      color: '#0ea5e9',
      description: 'Winter family vacation fund',
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sav_education',
      name: "Children's Higher Education DPS",
      targetAmountPoisha: 50000000,
      savedAmountPoisha: 9500000,
      targetDate: '2029-12-31',
      accountId: 'acc_savings',
      icon: 'GraduationCap',
      color: '#8b5cf6',
      description: 'Dedicated education fund',
      status: 'active',
      createdAt: now,
      updatedAt: now,
    },
  ];

  const savingsContributions: SavingsContribution[] = [
    {
      id: 'sc_init_1',
      goalId: 'sav_emergency',
      type: 'deposit',
      amountPoisha: 12000000,
      date: '2026-10-01',
      accountId: 'acc_savings',
      note: 'Initial emergency reserve allocation',
      createdAt: '2026-10-01T09:00:00.000Z',
    },
    {
      id: 'sc_init_2',
      goalId: 'sav_vacation',
      type: 'deposit',
      amountPoisha: 2250000,
      date: '2026-10-25',
      accountId: 'acc_savings',
      note: 'Winter trip savings contribution',
      createdAt: '2026-10-25T09:00:00.000Z',
    },
    {
      id: 'sc_init_3',
      goalId: 'sav_education',
      type: 'deposit',
      amountPoisha: 9500000,
      date: '2026-11-01',
      accountId: 'acc_savings',
      note: 'Education DPS acumulado',
      createdAt: '2026-11-01T09:00:00.000Z',
    },
  ];

  const recurringTransactions: RecurringTransaction[] = [
    {
      id: 'rec_salary',
      title: 'Monthly Office Salary',
      type: 'income',
      amountPoisha: 6800000,
      accountId: 'acc_bank',
      categoryId: 'cat_salary',
      frequency: 'monthly',
      startDate: '2026-01-01',
      nextExecutionDate: '2026-12-01',
      lastExecutedDate: '2026-11-01',
      autoPost: true,
      status: 'active',
      description: 'Monthly payroll EFT credit',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'rec_isp_bill',
      title: 'AmberIT Fiber Broadband Bill',
      type: 'expense',
      amountPoisha: 120000,
      accountId: 'acc_bkash',
      categoryId: 'cat_internet',
      frequency: 'monthly',
      startDate: '2026-01-10',
      nextExecutionDate: '2026-11-10',
      lastExecutedDate: '2026-10-10',
      autoPost: false,
      status: 'active',
      description: '50 Mbps home fiber internet bill',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'rec_desco_elec',
      title: 'Prepaid Electricity Recharge',
      type: 'expense',
      amountPoisha: 150000,
      accountId: 'acc_nagad',
      categoryId: 'cat_electricity',
      frequency: 'monthly',
      startDate: '2026-01-12',
      nextExecutionDate: '2026-11-12',
      lastExecutedDate: '2026-10-12',
      autoPost: false,
      status: 'active',
      description: 'Monthly smart meter recharge',
      createdAt: now,
      updatedAt: now,
    },
  ];

  const notifications: AppNotification[] = [
    {
      id: 'notif_welcome_1',
      type: 'budget_alert',
      severity: 'warning',
      title: 'Rent Budget Reached 100%',
      message: 'Rent category has utilized ৳ 4,000.00 of ৳ 4,000.00 (100%) for November 2026.',
      relatedEntityId: 'bgt_nov_2026',
      isRead: false,
      createdAt: now,
    },
    {
      id: 'notif_welcome_2',
      type: 'budget_alert',
      severity: 'info',
      title: 'Grocery Budget Passed 75% Threshold',
      message: 'Grocery spending is at ৳ 4,650.00 of ৳ 6,000.00 (77.5%) for November 2026.',
      relatedEntityId: 'bgt_nov_2026',
      isRead: false,
      createdAt: now,
    },
    {
      id: 'notif_welcome_3',
      type: 'debt_due',
      severity: 'info',
      title: 'Dena-Pawna Reminder Today',
      message: 'Follow up with Tanvir Ahmed (৳ 7,000.00 receivable) and Rafiqul Islam (৳ 5,000.00 payable).',
      relatedEntityId: 'debt_tanvir_10k',
      isRead: false,
      createdAt: now,
    },
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'audit_init_v2',
      action: 'SCHEMA_MIGRATION',
      entityType: 'Database',
      entityId: 'TakaFlowProDB',
      summary: 'Initialized versioned IndexedDB schema v2 with 19 normalized stores and integer poisha ledger',
      detailsJson: JSON.stringify({ fromVersion: 1, toVersion: 2, timestamp: now }),
      timestamp: now,
    },
  ];

  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    exportedAt: now,
    settings,
    accounts,
    transactions,
    transactionSplits,
    categories,
    subcategories,
    budgets,
    budgetCategories,
    contacts,
    debts,
    debtPayments,
    loans,
    loanPayments: [],
    savingsGoals,
    savingsContributions,
    recurringTransactions,
    attachments: [],
    notifications,
    auditLogs,
  };
}

/**
 * IndexedDB + Safe Local Fallback Persistence Service
 */
export class IndexedDBRepository {
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  private openDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve) => {
      try {
        if (typeof indexedDB === 'undefined') {
          resolve(null);
          return;
        }
        const request = indexedDB.open(DB_NAME, CURRENT_SCHEMA_VERSION);
        request.onupgradeneeded = (event) => {
          const db = request.result;
          const oldVersion = event.oldVersion || 0;

          for (const storeName of STORE_NAMES) {
            if (!db.objectStoreNames.contains(storeName)) {
              const store = db.createObjectStore(storeName, { keyPath: 'id' });
              if (storeName === 'Transactions') {
                store.createIndex('by_date', 'date', { unique: false });
                store.createIndex('by_account', 'accountId', { unique: false });
                store.createIndex('by_category', 'categoryId', { unique: false });
                store.createIndex('by_type', 'type', { unique: false });
                store.createIndex('by_fingerprint', 'fingerprint', { unique: false });
              } else if (storeName === 'Subcategories') {
                store.createIndex('by_category', 'categoryId', { unique: false });
              } else if (storeName === 'BudgetCategories') {
                store.createIndex('by_budget', 'budgetId', { unique: false });
              } else if (storeName === 'Debts') {
                store.createIndex('by_direction', 'direction', { unique: false });
                store.createIndex('by_status', 'status', { unique: false });
              }
            }
          }

          if (oldVersion === 1 && db.objectStoreNames.contains('AuditLogs') && request.transaction) {
            const auditStore = request.transaction.objectStore('AuditLogs');
            auditStore.put({
              id: `mig_v1_v2_${Date.now()}`,
              action: 'MIGRATE_V1_TO_V2',
              entityType: 'Schema',
              entityId: 'v2',
              summary: 'Upgraded schema from v1 to v2 preserving all existing user records',
              detailsJson: JSON.stringify({ oldVersion, newVersion: CURRENT_SCHEMA_VERSION }),
              timestamp: new Date().toISOString(),
            });
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
    return this.dbPromise;
  }

  public async loadSnapshot(): Promise<DatabaseSnapshot> {
    const db = await this.openDB();
    if (db) {
      try {
        const snapshot = await this.readAllFromIDB(db);
        if (snapshot && snapshot.accounts && snapshot.accounts.length > 0) {
          return snapshot;
        }
      } catch {
        // Fallback
      }
    }

    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(FALLBACK_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as DatabaseSnapshot;
          if (parsed && parsed.accounts && parsed.accounts.length > 0) {
            return parsed;
          }
        }
      }
    } catch {
      // Ignore
    }

    const seed = createInitialSeedSnapshot();
    await this.saveSnapshot(seed);
    return seed;
  }

  public async saveSnapshot(snapshot: DatabaseSnapshot): Promise<void> {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(snapshot));
      }
    } catch {
      // Ignore
    }

    const db = await this.openDB();
    if (!db) return;

    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAMES as unknown as string[], 'readwrite');
        const map: Record<(typeof STORE_NAMES)[number], unknown[]> = {
          AppSettings: [snapshot.settings],
          Accounts: snapshot.accounts,
          Transactions: snapshot.transactions,
          TransactionSplits: snapshot.transactionSplits,
          Categories: snapshot.categories,
          Subcategories: snapshot.subcategories,
          Budgets: snapshot.budgets,
          BudgetCategories: snapshot.budgetCategories,
          Contacts: snapshot.contacts,
          Debts: snapshot.debts,
          DebtPayments: snapshot.debtPayments,
          Loans: snapshot.loans,
          LoanPayments: snapshot.loanPayments,
          SavingsGoals: snapshot.savingsGoals,
          SavingsContributions: snapshot.savingsContributions,
          RecurringTransactions: snapshot.recurringTransactions,
          Attachments: snapshot.attachments,
          Notifications: snapshot.notifications,
          AuditLogs: snapshot.auditLogs,
        };

        for (const storeName of STORE_NAMES) {
          const store = tx.objectStore(storeName);
          store.clear();
          for (const item of map[storeName] || []) {
            store.put(item);
          }
        }

        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }

  public savePreRestoreBackup(snapshot: DatabaseSnapshot): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(PRE_RESTORE_BACKUP_KEY, JSON.stringify(snapshot));
      }
    } catch {
      // Ignore
    }
  }

  public getPreRestoreBackup(): DatabaseSnapshot | null {
    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(PRE_RESTORE_BACKUP_KEY);
        if (raw) return JSON.parse(raw) as DatabaseSnapshot;
      }
    } catch {
      // Ignore
    }
    return null;
  }

  private readAllFromIDB(db: IDBDatabase): Promise<DatabaseSnapshot | null> {
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAMES as unknown as string[], 'readonly');
        const results: Record<string, any[]> = {};
        let completed = 0;

        for (const storeName of STORE_NAMES) {
          const store = tx.objectStore(storeName);
          const req = store.getAll();
          req.onsuccess = () => {
            results[storeName] = req.result || [];
            completed++;
            if (completed === STORE_NAMES.length) {
              if (!results.AppSettings || results.AppSettings.length === 0) {
                resolve(null);
                return;
              }
              resolve({
                schemaVersion: results.AppSettings[0].schemaVersion || CURRENT_SCHEMA_VERSION,
                exportedAt: new Date().toISOString(),
                settings: results.AppSettings[0],
                accounts: results.Accounts || [],
                transactions: results.Transactions || [],
                transactionSplits: results.TransactionSplits || [],
                categories: results.Categories || [],
                subcategories: results.Subcategories || [],
                budgets: results.Budgets || [],
                budgetCategories: results.BudgetCategories || [],
                contacts: results.Contacts || [],
                debts: results.Debts || [],
                debtPayments: results.DebtPayments || [],
                loans: results.Loans || [],
                loanPayments: results.LoanPayments || [],
                savingsGoals: results.SavingsGoals || [],
                savingsContributions: results.SavingsContributions || [],
                recurringTransactions: results.RecurringTransactions || [],
                attachments: results.Attachments || [],
                notifications: results.Notifications || [],
                auditLogs: results.AuditLogs || [],
              });
            }
          };
          req.onerror = () => resolve(null);
        }
      } catch {
        resolve(null);
      }
    });
  }
}
