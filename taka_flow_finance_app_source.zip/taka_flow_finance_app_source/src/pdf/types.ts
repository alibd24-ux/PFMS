// ============================================================================
// HISABPRO / TAKAFLOW PRO — ADVANCED PDF REPORT GENERATOR TYPES & TEMPLATES
// Defines all 18 Report Sections, Page Sizes, Orientations, Themes,
// Header/Footer Customization, Filter Options, and Saved Report Templates.
// ============================================================================

import { CurrencyCode, LanguageCode } from '../types/models';

export type PdfSectionKey =
  | 'dashboard_summary'
  | 'all_transactions'
  | 'income_report'
  | 'expense_report'
  | 'account_statements'
  | 'category_reports'
  | 'subcategory_reports'
  | 'budget_reports'
  | 'receivables_report'
  | 'payables_report'
  | 'loans_report'
  | 'savings_report'
  | 'recurring_report'
  | 'cashflow_report'
  | 'networth_report'
  | 'monthly_summary'
  | 'yearly_summary'
  | 'custom_builder';

export type PdfPageSize = 'A4' | 'A5' | 'Letter';
export type PdfOrientation = 'portrait' | 'landscape';
export type PdfThemeStyle = 'professional' | 'minimal' | 'compact' | 'colorful' | 'bw';

export interface PdfHeaderFooterConfig {
  appName: string;
  showAppName: boolean;
  reportTitle: string;
  showReportTitle: boolean;
  userName: string;
  showUserName: boolean;
  profileInfo: string;
  showProfileInfo: boolean;
  customLogoText: string;
  showLogo: boolean;
  contactInfo: string;
  showContactInfo: boolean;
  showGenerationDate: boolean;
  showReportingPeriod: boolean;
  footerText: string;
  showFooterText: boolean;
  showPageNumbers: boolean;
  confidentialityNotice: string;
  showConfidentialityNotice: boolean;
  includeTableOfContents: boolean;
  includeSummaryPage: boolean;
  includeCharts: boolean;
}

export interface PdfFilterOptions {
  dateFrom: string;
  dateTo: string;
  accountIds: string[]; // empty = all accounts
  categoryIds: string[]; // empty = all categories
  subcategoryIds: string[]; // empty = all subcategories
  contactName: string; // empty = all contacts
  transactionTypes: string[]; // empty = all types
  minAmountPoisha: number;
  maxAmountPoisha: number; // 0 = no max limit
  groupBy: 'none' | 'date' | 'category' | 'account';
  sortBy: 'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc';
}

export interface SavedPdfTemplate {
  id: string;
  name: string;
  description: string;
  sections: PdfSectionKey[];
  pageSize: PdfPageSize;
  orientation: PdfOrientation;
  theme: PdfThemeStyle;
  language: LanguageCode;
  currency: CurrencyCode;
  filters: PdfFilterOptions;
  headerFooter: PdfHeaderFooterConfig;
  createdAt: string;
}

export interface BuiltPdfKpi {
  label: string;
  value: string;
  subtext?: string;
  tone?: 'positive' | 'negative' | 'neutral' | 'accent';
}

export interface BuiltPdfChartItem {
  label: string;
  valueMajor: number;
  formattedValue: string;
  percent: number;
  color: string;
}

export interface BuiltPdfTable {
  title: string;
  subtitle?: string;
  headers: string[];
  alignRightCols: number[]; // column indices right-aligned
  rows: string[][];
  footerRow?: string[];
}

export interface BuiltPdfSection {
  id: string;
  sectionKey: PdfSectionKey;
  title: string;
  subtitle: string;
  kpis: BuiltPdfKpi[];
  charts: Array<{
    title: string;
    type: 'bar' | 'horizontal_progress';
    items: BuiltPdfChartItem[];
  }>;
  tables: BuiltPdfTable[];
  notes?: string[];
}

export interface BuiltPdfDocument {
  filename: string;
  generatedAt: string;
  periodLabel: string;
  pageSize: PdfPageSize;
  orientation: PdfOrientation;
  theme: PdfThemeStyle;
  language: LanguageCode;
  currency: CurrencyCode;
  headerFooter: PdfHeaderFooterConfig;
  summaryKpis: BuiltPdfKpi[];
  sections: BuiltPdfSection[];
}

export const DEFAULT_PDF_TEMPLATES: SavedPdfTemplate[] = [
  {
    id: 'tpl_complete_monthly',
    name: 'Complete Monthly Financial Statement',
    description: 'Dashboard summary, Account statements, Category spending, Budgets, and Dena-Pawna',
    sections: [
      'dashboard_summary',
      'account_statements',
      'category_reports',
      'budget_reports',
      'receivables_report',
      'payables_report',
    ],
    pageSize: 'A4',
    orientation: 'portrait',
    theme: 'professional',
    language: 'en',
    currency: 'BDT',
    filters: {
      dateFrom: '2026-11-01',
      dateTo: '2026-11-30',
      accountIds: [],
      categoryIds: [],
      subcategoryIds: [],
      contactName: '',
      transactionTypes: [],
      minAmountPoisha: 0,
      maxAmountPoisha: 0,
      groupBy: 'none',
      sortBy: 'date_desc',
    },
    headerFooter: {
      appName: 'HisabPro',
      showAppName: true,
      reportTitle: 'Complete Monthly Financial Statement',
      showReportTitle: true,
      userName: 'Personal Finance Account Holder',
      showUserName: true,
      profileInfo: 'Verified Local Ledger Statement',
      showProfileInfo: true,
      customLogoText: '৳ HisabPro',
      showLogo: true,
      contactInfo: 'Sylhet / Dhaka, Bangladesh',
      showContactInfo: true,
      showGenerationDate: true,
      showReportingPeriod: true,
      footerText: 'Generated locally by HisabPro Financial Engine — 100% Offline & Private',
      showFooterText: true,
      showPageNumbers: true,
      confidentialityNotice: 'CONFIDENTIAL PERSONAL FINANCIAL RECORD — DO NOT DISTRIBUTE WITHOUT PERMISSION',
      showConfidentialityNotice: true,
      includeTableOfContents: true,
      includeSummaryPage: true,
      includeCharts: true,
    },
    createdAt: '2026-11-06T09:00:00.000Z',
  },
  {
    id: 'tpl_essential_categories',
    name: 'Food + Grocery + Transportation Expense Audit',
    description: 'Combined category & subcategory audit for Food, Grocery, and Transportation',
    sections: ['category_reports', 'subcategory_reports', 'budget_reports'],
    pageSize: 'A4',
    orientation: 'portrait',
    theme: 'colorful',
    language: 'en',
    currency: 'BDT',
    filters: {
      dateFrom: '2026-11-01',
      dateTo: '2026-11-30',
      accountIds: [],
      categoryIds: ['cat_food', 'cat_grocery', 'cat_transport'],
      subcategoryIds: [],
      contactName: '',
      transactionTypes: ['expense'],
      minAmountPoisha: 0,
      maxAmountPoisha: 0,
      groupBy: 'category',
      sortBy: 'amount_desc',
    },
    headerFooter: {
      appName: 'HisabPro',
      showAppName: true,
      reportTitle: 'Essential Categories Spending Report (Food, Grocery & Transport)',
      showReportTitle: true,
      userName: 'Personal Finance Account Holder',
      showUserName: true,
      profileInfo: 'Category & Budget Audit',
      showProfileInfo: true,
      customLogoText: '৳ HisabPro',
      showLogo: true,
      contactInfo: 'Bangladesh',
      showContactInfo: false,
      showGenerationDate: true,
      showReportingPeriod: true,
      footerText: 'HisabPro Category & Budget Statement',
      showFooterText: true,
      showPageNumbers: true,
      confidentialityNotice: 'CONFIDENTIAL PERSONAL FINANCIAL RECORD',
      showConfidentialityNotice: true,
      includeTableOfContents: false,
      includeSummaryPage: true,
      includeCharts: true,
    },
    createdAt: '2026-11-06T09:00:00.000Z',
  },
  {
    id: 'tpl_dena_pawna_full',
    name: 'All Debt, Receivables (Pawna) & Payables (Dena) Statement',
    description: 'Complete Dena-Pawna person-wise statement, payment history, and overdue tracker',
    sections: ['receivables_report', 'payables_report', 'loans_report'],
    pageSize: 'A4',
    orientation: 'portrait',
    theme: 'professional',
    language: 'bn',
    currency: 'BDT',
    filters: {
      dateFrom: '2026-10-01',
      dateTo: '2026-11-30',
      accountIds: [],
      categoryIds: [],
      subcategoryIds: [],
      contactName: '',
      transactionTypes: [],
      minAmountPoisha: 0,
      maxAmountPoisha: 0,
      groupBy: 'none',
      sortBy: 'date_desc',
    },
    headerFooter: {
      appName: 'হিসাবপ্রো (HisabPro)',
      showAppName: true,
      reportTitle: 'দেনা-পাওনা ও ঋণ বিবরণী (Dena-Pawna & Loan Statement)',
      showReportTitle: true,
      userName: 'ব্যক্তিগত হিসাব বিবরণী',
      showUserName: true,
      profileInfo: 'ভেরিফাইড লেজার স্টেটমেন্ট',
      showProfileInfo: true,
      customLogoText: '৳ হিসাবপ্রো',
      showLogo: true,
      contactInfo: 'বাংলাদেশ',
      showContactInfo: true,
      showGenerationDate: true,
      showReportingPeriod: true,
      footerText: 'হিসাবপ্রো ফিন্যান্সিয়াল ইঞ্জিন দ্বারা অফলাইনে তৈরি',
      showFooterText: true,
      showPageNumbers: true,
      confidentialityNotice: 'গোপনীয় ব্যক্তিগত আর্থিক নথি (CONFIDENTIAL)',
      showConfidentialityNotice: true,
      includeTableOfContents: true,
      includeSummaryPage: true,
      includeCharts: true,
    },
    createdAt: '2026-11-06T09:00:00.000Z',
  },
];
