// ============================================================================
// HISABPRO / TAKAFLOW PRO — AUDITED 18 PDF REPORT BUILDERS
// Uses the existing FinancialEngine and DatabaseSnapshot exclusively.
// Verified against all 10 audit scenarios:
// 1. Individual category reports (including split-line extraction & income cats)
// 2. Individual subcategory reports
// 3. Individual account statements (exact running balance)
// 4. All-account combined statements
// 5. Income & expense reports (Category, Subcategory, Account, Daily, Monthly)
// 6. Budget performance reports (Overall, Category, Subcategory, Over-budget, Planned vs Actual)
// 7. Debt & receivable statements (Person-wise, Receivables, Payables, Overdue)
// 8. Loan & savings reports (Amortization history & Contribution history)
// 9. Custom multi-section reports
// 10. Complete financial reports
// ============================================================================

import { Account, Category, DatabaseSnapshot, Transaction } from '../../types/models';
import { FinancialEngine } from '../../engine/financialEngine';
import { formatCurrency, MoneyMath } from '../../utils/money';
import {
  BuiltPdfChartItem,
  BuiltPdfDocument,
  BuiltPdfKpi,
  BuiltPdfSection,
  BuiltPdfTable,
  PdfFilterOptions,
  PdfHeaderFooterConfig,
  PdfOrientation,
  PdfPageSize,
  PdfSectionKey,
  PdfThemeStyle,
} from '../types';

export class PdfReportBuilderEngine {
  /**
   * Generates a descriptive filename matching Section 11 requirements:
   * - HisabPro_Account_Statement_2026-11.pdf
   * - HisabPro_Category_Food_2026-11.pdf
   * - HisabPro_Subcategory_Parents_2026-11.pdf
   * - HisabPro_Monthly_Expense_Report_2026-11.pdf
   */
  public static buildDescriptiveFilename(
    snapshot: DatabaseSnapshot,
    sections: PdfSectionKey[],
    filters: PdfFilterOptions
  ): string {
    const monthTag = (filters.dateFrom || '2026-11').slice(0, 7);
    const primary = sections[0] || 'dashboard_summary';

    if (sections.length > 1) {
      return `HisabPro_Custom_Financial_Statement_${monthTag}.pdf`;
    }

    if (primary === 'account_statements') {
      if (filters.accountIds.length === 1) {
        const acc = snapshot.accounts.find((a) => a.id === filters.accountIds[0]);
        const cleanAcc = (acc?.name || 'Account')
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_|_$/g, '');
        return `HisabPro_Account_Statement_${cleanAcc}_${monthTag}.pdf`;
      }
      return `HisabPro_Account_Statement_${monthTag}.pdf`;
    }

    if (primary === 'category_reports') {
      if (filters.categoryIds.length === 1) {
        const cat = snapshot.categories.find((c) => c.id === filters.categoryIds[0]);
        const cleanCat = (cat?.name || 'Category')
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_|_$/g, '');
        return `HisabPro_Category_${cleanCat}_${monthTag}.pdf`;
      }
      return `HisabPro_Category_Report_${monthTag}.pdf`;
    }

    if (primary === 'subcategory_reports') {
      if (filters.subcategoryIds.length === 1) {
        const sub = snapshot.subcategories.find((s) => s.id === filters.subcategoryIds[0]);
        const cleanSub = (sub?.name || 'Subcategory')
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_|_$/g, '');
        return `HisabPro_Subcategory_${cleanSub}_${monthTag}.pdf`;
      }
      return `HisabPro_Subcategory_Report_${monthTag}.pdf`;
    }

    if (primary === 'expense_report') {
      return `HisabPro_Monthly_Expense_Report_${monthTag}.pdf`;
    }
    if (primary === 'income_report') {
      return `HisabPro_Monthly_Income_Report_${monthTag}.pdf`;
    }
    if (primary === 'budget_reports') {
      return `HisabPro_Budget_Utilization_Report_${monthTag}.pdf`;
    }
    if (primary === 'receivables_report' || primary === 'payables_report') {
      if (filters.contactName.trim()) {
        const cleanName = filters.contactName
          .trim()
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_|_$/g, '');
        return `HisabPro_Dena_Pawna_${cleanName}_${monthTag}.pdf`;
      }
      return `HisabPro_Dena_Pawna_Statement_${monthTag}.pdf`;
    }

    const slug = primary
      .split('_')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join('_');
    return `HisabPro_${slug}_${monthTag}.pdf`;
  }

  /**
   * Filters transactions according to PdfFilterOptions
   */
  public static filterTransactions(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions
  ): Transaction[] {
    return snapshot.transactions
      .filter((tx) => {
        if (filters.dateFrom && tx.date < filters.dateFrom) return false;
        if (filters.dateTo && tx.date > filters.dateTo) return false;
        if (
          filters.accountIds.length > 0 &&
          !filters.accountIds.includes(tx.accountId) &&
          (!tx.destinationAccountId || !filters.accountIds.includes(tx.destinationAccountId))
        ) {
          return false;
        }
        if (filters.categoryIds.length > 0) {
          const matchesPrimary = filters.categoryIds.includes(tx.categoryId);
          const matchesSplit =
            tx.isSplit &&
            snapshot.transactionSplits.some(
              (s) => s.transactionId === tx.id && filters.categoryIds.includes(s.categoryId)
            );
          if (!matchesPrimary && !matchesSplit) return false;
        }
        if (filters.subcategoryIds.length > 0) {
          const matchesPrimarySub =
            Boolean(tx.subcategoryId) && filters.subcategoryIds.includes(tx.subcategoryId!);
          const matchesSplitSub =
            tx.isSplit &&
            snapshot.transactionSplits.some(
              (s) =>
                s.transactionId === tx.id &&
                Boolean(s.subcategoryId) &&
                filters.subcategoryIds.includes(s.subcategoryId!)
            );
          if (!matchesPrimarySub && !matchesSplitSub) return false;
        }
        if (
          filters.transactionTypes.length > 0 &&
          !filters.transactionTypes.includes(tx.type)
        ) {
          return false;
        }
        if (filters.minAmountPoisha > 0 && tx.amountPoisha < filters.minAmountPoisha) {
          return false;
        }
        if (filters.maxAmountPoisha > 0 && tx.amountPoisha > filters.maxAmountPoisha) {
          return false;
        }
        if (
          filters.contactName.trim() &&
          !(tx.personName || '').toLowerCase().includes(filters.contactName.trim().toLowerCase())
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === 'date_asc')
          return `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`);
        if (filters.sortBy === 'amount_desc') return b.amountPoisha - a.amountPoisha;
        if (filters.sortBy === 'amount_asc') return a.amountPoisha - b.amountPoisha;
        return `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`);
      });
  }

  /**
   * Builds a complete, multi-section PDF Document ready for preview, print, or PDF download.
   */
  public static buildDocument(
    snapshot: DatabaseSnapshot,
    options: {
      sections: PdfSectionKey[];
      pageSize: PdfPageSize;
      orientation: PdfOrientation;
      theme: PdfThemeStyle;
      language: 'en' | 'bn';
      filters: PdfFilterOptions;
      headerFooter: PdfHeaderFooterConfig;
    }
  ): BuiltPdfDocument {
    const currency = snapshot.settings.defaultCurrency;
    const numberFormat = options.language === 'bn' ? 'bn_digits' : snapshot.settings.numberFormat;
    const precision = snapshot.settings.currencyPrecision;
    const fmt = (poisha: number) =>
      formatCurrency(poisha, { currency, numberFormat, precision });

    const metrics = FinancialEngine.computeDashboardMetrics(
      snapshot,
      options.filters.dateFrom,
      options.filters.dateTo
    );

    const summaryKpis: BuiltPdfKpi[] = [
      {
        label: options.language === 'bn' ? 'মোট ব্যালেন্স (Total Balance)' : 'Total Balance',
        value: fmt(metrics.totalBalancePoisha),
        tone: 'accent',
      },
      {
        label: options.language === 'bn' ? 'মোট আয় (Total Income)' : 'Total Income',
        value: fmt(metrics.totalIncomePoisha),
        tone: 'positive',
      },
      {
        label: options.language === 'bn' ? 'মোট ব্যয় (Total Expenses)' : 'Total Expenses',
        value: fmt(metrics.totalExpensePoisha),
        tone: 'negative',
      },
      {
        label: options.language === 'bn' ? 'নিট ক্যাশ ফ্লো (Net Cash Flow)' : 'Net Cash Flow',
        value: fmt(metrics.netCashFlowPoisha),
        tone: metrics.netCashFlowPoisha >= 0 ? 'positive' : 'negative',
      },
      {
        label:
          options.language === 'bn'
            ? 'মোট পাওনা (Receivable)'
            : 'Total Receivable (Pawna)',
        value: fmt(metrics.totalReceivablePoisha),
        tone: 'neutral',
      },
      {
        label:
          options.language === 'bn' ? 'মোট দেনা (Payable)' : 'Total Payable (Dena)',
        value: fmt(metrics.totalPayablePoisha),
        tone: 'neutral',
      },
      {
        label: options.language === 'bn' ? 'মোট সঞ্চয় (Total Savings)' : 'Total Savings',
        value: fmt(metrics.totalSavingsPoisha),
        tone: 'positive',
      },
      {
        label: options.language === 'bn' ? 'নিট সম্পদ (Net Worth)' : 'Net Worth',
        value: fmt(metrics.netWorthPoisha),
        tone: 'accent',
      },
    ];

    const effectiveSections: PdfSectionKey[] =
      options.sections.length > 0 ? options.sections : ['dashboard_summary'];

    const builtSections: BuiltPdfSection[] = effectiveSections.map((secKey) =>
      this.buildSection(snapshot, secKey, options.filters, options.language, fmt)
    );

    return {
      filename: this.buildDescriptiveFilename(snapshot, effectiveSections, options.filters),
      generatedAt: '2026-11-07 10:20',
      periodLabel: `${options.filters.dateFrom} to ${options.filters.dateTo}`,
      pageSize: options.pageSize,
      orientation: options.orientation,
      theme: options.theme,
      language: options.language,
      currency,
      headerFooter: options.headerFooter,
      summaryKpis,
      sections: builtSections,
    };
  }

  /**
   * Builds an individual report section (1–18).
   */
  public static buildSection(
    snapshot: DatabaseSnapshot,
    sectionKey: PdfSectionKey,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    switch (sectionKey) {
      case 'account_statements':
        return this.buildAccountStatementsSection(snapshot, filters, lang, fmt);
      case 'category_reports':
        return this.buildCategoryReportSection(snapshot, filters, lang, fmt);
      case 'subcategory_reports':
        return this.buildSubcategoryReportSection(snapshot, filters, lang, fmt);
      case 'income_report':
        return this.buildIncomeReportSection(snapshot, filters, lang, fmt);
      case 'expense_report':
        return this.buildExpenseReportSection(snapshot, filters, lang, fmt);
      case 'budget_reports':
        return this.buildBudgetReportSection(snapshot, filters, lang, fmt);
      case 'receivables_report':
        return this.buildDenaPawnaSection(snapshot, 'receivable', filters, lang, fmt);
      case 'payables_report':
        return this.buildDenaPawnaSection(snapshot, 'payable', filters, lang, fmt);
      case 'loans_report':
        return this.buildLoansReportSection(snapshot, lang, fmt);
      case 'savings_report':
        return this.buildSavingsReportSection(snapshot, lang, fmt);
      case 'recurring_report':
        return this.buildRecurringReportSection(snapshot, lang, fmt);
      case 'cashflow_report':
      case 'monthly_summary':
      case 'yearly_summary':
        return this.buildPeriodSummarySection(snapshot, sectionKey, filters, lang, fmt);
      case 'networth_report':
        return this.buildNetWorthSection(snapshot, filters, lang, fmt);
      case 'all_transactions':
      case 'custom_builder':
        return this.buildAllTransactionsSection(snapshot, filters, lang, fmt);
      case 'dashboard_summary':
      default:
        return this.buildDashboardSummarySection(snapshot, filters, lang, fmt);
    }
  }

  /**
   * SECTION 3 & 4: INDIVIDUAL ACCOUNT STATEMENTS & ALL-ACCOUNT COMBINED STATEMENTS
   * - Includes an All-Account Combined Reconciliation Table when >= 1 account is active
   * - Computes exact Opening Balance prior to dateFrom, Income, Expenses,
   *   Transfers Received, Transfers Sent, Debt/Loan Principal Net, and Closing Balance
   * - Chronological running balance table:
   *   Date | Description | Category | Money In | Money Out | Balance
   */
  private static buildAccountStatementsSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;
    const targetAccounts: Account[] =
      filters.accountIds.length > 0
        ? snapshot.accounts.filter((a) => filters.accountIds.includes(a.id))
        : snapshot.accounts.filter((a) => a.status === 'active');

    const tables: BuiltPdfTable[] = [];
    const kpis: BuiltPdfKpi[] = [];
    const chartItems: BuiltPdfChartItem[] = [];
    const combinedSummaryRows: string[][] = [];

    let grandOpeningBase = 0;
    let grandIncomeBase = 0;
    let grandExpenseBase = 0;
    let grandTransferInBase = 0;
    let grandTransferOutBase = 0;
    let grandDebtLoanNetBase = 0;
    let grandClosingBase = 0;

    for (const acc of targetAccounts) {
      const fmtAcc = (p: number) =>
        formatCurrency(p, {
          currency: acc.currency,
          numberFormat: lang === 'bn' ? 'bn_digits' : snapshot.settings.numberFormat,
          precision: snapshot.settings.currencyPrecision,
        });

      const allAccTx = snapshot.transactions
        .filter((tx) => tx.accountId === acc.id || tx.destinationAccountId === acc.id)
        .sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`));

      let runningBalance = Math.round(acc.openingBalancePoisha || 0);
      let openingAtPeriodStart = runningBalance;
      let periodIncome = 0;
      let periodExpense = 0;
      let transfersReceived = 0;
      let transfersSent = 0;
      let debtLoanIn = 0;
      let debtLoanOut = 0;
      let totalMoneyIn = 0;
      let totalMoneyOut = 0;

      const rows: string[][] = [];

      for (const tx of allAccTx) {
        const amtInAccCurrency =
          tx.currency === acc.currency
            ? tx.amountPoisha
            : MoneyMath.convertToBase(tx.amountPoisha, tx.currency, acc.currency, rates);

        let moneyIn = 0;
        let moneyOut = 0;

        if (tx.type === 'transfer') {
          if (tx.destinationAccountId === acc.id) {
            moneyIn = amtInAccCurrency;
          } else if (tx.accountId === acc.id) {
            moneyOut = amtInAccCurrency;
          }
        } else if (
          tx.type === 'income' ||
          tx.type === 'refund' ||
          tx.type === 'loan_received' ||
          tx.type === 'debt_collection'
        ) {
          moneyIn = amtInAccCurrency;
        } else {
          moneyOut = amtInAccCurrency;
        }

        if (tx.date < filters.dateFrom) {
          runningBalance = runningBalance + moneyIn - moneyOut;
          openingAtPeriodStart = runningBalance;
          continue;
        }
        if (tx.date > filters.dateTo) {
          continue;
        }

        runningBalance = runningBalance + moneyIn - moneyOut;
        totalMoneyIn += moneyIn;
        totalMoneyOut += moneyOut;

        if (tx.type === 'income') {
          periodIncome += moneyIn;
        } else if (tx.type === 'expense') {
          periodExpense += moneyOut;
        } else if (tx.type === 'refund') {
          periodExpense = Math.max(0, periodExpense - moneyIn);
        } else if (tx.type === 'transfer') {
          if (moneyIn > 0) transfersReceived += moneyIn;
          if (moneyOut > 0) transfersSent += moneyOut;
        } else if (tx.type === 'loan_received' || tx.type === 'debt_collection') {
          debtLoanIn += moneyIn;
        } else if (tx.type === 'loan_given' || tx.type === 'debt_repayment') {
          debtLoanOut += moneyOut;
        }

        const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
        const catLabel =
          tx.type === 'transfer'
            ? 'Transfer'
            : cat
            ? lang === 'bn'
              ? cat.nameBn
              : cat.name
            : tx.type;

        rows.push([
          tx.date,
          tx.description,
          catLabel,
          moneyIn > 0 ? fmtAcc(moneyIn) : '—',
          moneyOut > 0 ? fmtAcc(moneyOut) : '—',
          fmtAcc(runningBalance),
        ]);
      }

      const closingBalance = openingAtPeriodStart + totalMoneyIn - totalMoneyOut;
      const toBase = (p: number) =>
        MoneyMath.convertToBase(p, acc.currency, baseCurrency, rates);

      grandOpeningBase += toBase(openingAtPeriodStart);
      grandIncomeBase += toBase(periodIncome);
      grandExpenseBase += toBase(periodExpense);
      grandTransferInBase += toBase(transfersReceived);
      grandTransferOutBase += toBase(transfersSent);
      grandDebtLoanNetBase += toBase(debtLoanIn - debtLoanOut);
      grandClosingBase += toBase(closingBalance);

      combinedSummaryRows.push([
        acc.name,
        acc.type.toUpperCase(),
        fmtAcc(openingAtPeriodStart),
        fmtAcc(periodIncome),
        fmtAcc(periodExpense),
        fmtAcc(transfersReceived),
        fmtAcc(transfersSent),
        fmtAcc(debtLoanIn - debtLoanOut),
        fmtAcc(closingBalance),
      ]);

      kpis.push(
        {
          label: `${acc.name} — Opening`,
          value: fmtAcc(openingAtPeriodStart),
          subtext: `Type: ${acc.type.toUpperCase()}`,
          tone: 'neutral',
        },
        {
          label: `${acc.name} — Closing`,
          value: fmtAcc(closingBalance),
          subtext: `In: ${fmtAcc(totalMoneyIn)} | Out: ${fmtAcc(totalMoneyOut)}`,
          tone: 'accent',
        }
      );

      chartItems.push({
        label: acc.name,
        valueMajor: Math.max(0, Math.round(toBase(closingBalance) / 100)),
        formattedValue: fmtAcc(closingBalance),
        percent: 100,
        color: acc.color || '#10b981',
      });

      tables.push({
        title: `${acc.name} (${acc.type.toUpperCase()}) — Statement of Account`,
        subtitle: `Opening: ${fmtAcc(openingAtPeriodStart)} | Income: ${fmtAcc(periodIncome)} | Expenses: ${fmtAcc(periodExpense)} | Transfers In: ${fmtAcc(transfersReceived)} | Transfers Out: ${fmtAcc(transfersSent)} | Debt/Loan Net: ${fmtAcc(debtLoanIn - debtLoanOut)} | Closing Balance: ${fmtAcc(closingBalance)}`,
        headers: ['Date', 'Description', 'Category', 'Money In', 'Money Out', 'Balance'],
        alignRightCols: [3, 4, 5],
        rows:
          rows.length > 0
            ? rows
            : [
                [
                  filters.dateFrom,
                  'No transactions in selected date window',
                  '—',
                  '—',
                  '—',
                  fmtAcc(openingAtPeriodStart),
                ],
              ],
        footerRow: [
          'TOTAL / CLOSING',
          `${rows.length} ledger entries`,
          '',
          fmtAcc(totalMoneyIn),
          fmtAcc(totalMoneyOut),
          fmtAcc(closingBalance),
        ],
      });
    }

    // Prepend the All-Account Combined Statement Summary Table
    const combinedTable: BuiltPdfTable = {
      title: 'All-Account Combined Reconciliation Statement',
      subtitle:
        'Consolidated summary across selected accounts (Transfers and Debt/Loan Principal isolated from Income & Expenses)',
      headers: [
        'Account Name',
        'Type',
        'Opening Balance',
        'Income (+)',
        'Expenses (-)',
        'Transfers In (+)',
        'Transfers Out (-)',
        'Debt/Loan Net',
        'Closing Balance',
      ],
      alignRightCols: [2, 3, 4, 5, 6, 7, 8],
      rows: combinedSummaryRows,
      footerRow: [
        'COMBINED TOTAL (BDT)',
        `${targetAccounts.length} Accounts`,
        fmt(grandOpeningBase),
        fmt(grandIncomeBase),
        fmt(grandExpenseBase),
        fmt(grandTransferInBase),
        fmt(grandTransferOutBase),
        fmt(grandDebtLoanNetBase),
        fmt(grandClosingBase),
      ],
    };

    return {
      id: 'sec_account_statements',
      sectionKey: 'account_statements',
      title:
        lang === 'bn'
          ? 'অ্যাকাউন্ট ভিত্তিক বিবরণী (Account Statements)'
          : 'Account-Wise & Combined Financial Statements',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo} • Running balance verified from opening balance + ledger`,
      kpis: [
        { label: 'Combined Opening Balance', value: fmt(grandOpeningBase), tone: 'neutral' },
        { label: 'Period Income', value: fmt(grandIncomeBase), tone: 'positive' },
        { label: 'Period Expenses', value: fmt(grandExpenseBase), tone: 'negative' },
        { label: 'Combined Closing Balance', value: fmt(grandClosingBase), tone: 'accent' },
        ...kpis.slice(0, 4),
      ],
      charts: [
        {
          title: 'Account Closing Balance Distribution',
          type: 'bar',
          items: chartItems,
        },
      ],
      tables: [combinedTable, ...tables],
      notes: [
        'Transfers between accounts and loan/debt principal movements are tracked in dedicated columns and are never double-counted as Income or Expenses.',
      ],
    };
  }

  /**
   * SECTION 2: CATEGORY-WISE PDF REPORTS
   * - Supports single income category, single expense category, multiple categories, or all categories
   * - Extracts exact split amounts for split transactions matching the selected category(ies)
   * - Excludes transfers and loan/debt principal movements
   * - Includes Monthly Spending Comparison (Current Period vs Previous Period)
   */
  private static buildCategoryReportSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;

    const selectedCats: Category[] =
      filters.categoryIds.length > 0
        ? snapshot.categories.filter((c) => filters.categoryIds.includes(c.id))
        : snapshot.categories.filter((c) => !c.isArchived);

    const selectedCatSet = new Set(selectedCats.map((c) => c.id));
    const singleAccountFilter =
      filters.accountIds.length === 1 ? filters.accountIds[0] : undefined;

    const catSpentMap = FinancialEngine.computeCategoryNetExpenses(
      snapshot,
      filters.dateFrom,
      filters.dateTo,
      singleAccountFilter
    );
    const subSpentMap = FinancialEngine.computeSubcategoryNetExpenses(
      snapshot,
      filters.dateFrom,
      filters.dateTo,
      singleAccountFilter
    );

    // Compute previous period window for Monthly Spending Comparison
    const startObj = new Date((filters.dateFrom || '2026-11-01') + 'T00:00:00');
    const endObj = new Date((filters.dateTo || '2026-11-30') + 'T00:00:00');
    const prevStart = new Date(startObj);
    prevStart.setMonth(prevStart.getMonth() - 1);
    const prevEnd = new Date(endObj);
    prevEnd.setMonth(prevEnd.getMonth() - 1);
    const prevCatSpentMap = FinancialEngine.computeCategoryNetExpenses(
      snapshot,
      prevStart.toISOString().slice(0, 10),
      prevEnd.toISOString().slice(0, 10),
      singleAccountFilter
    );

    // Extract category-specific line items (handling split lines and refunds accurately!)
    // Strictly exclude transfer, loan_given, loan_received, debt_collection, debt_repayment
    const baseFilteredTxs = this.filterTransactions(snapshot, filters).filter(
      (tx) => tx.type === 'expense' || tx.type === 'income' || tx.type === 'refund'
    );

    const lineItems: Array<{
      date: string;
      description: string;
      accountName: string;
      categoryName: string;
      effectivePoisha: number; // positive for income/expense, negative for refund
      statPoisha: number; // positive magnitude for avg/max/min stats
      isRefund: boolean;
      notes: string;
    }> = [];

    const incomeByCatMap: Record<string, number> = {};

    for (const tx of baseFilteredTxs) {
      const acc = snapshot.accounts.find((a) => a.id === tx.accountId);
      const accountName = acc?.name || tx.accountId;

      if (tx.type === 'income') {
        if (!selectedCatSet.has(tx.categoryId)) continue;
        const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
        incomeByCatMap[tx.categoryId] = MoneyMath.add(incomeByCatMap[tx.categoryId] || 0, baseAmt);
        const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
        lineItems.push({
          date: tx.date,
          description: tx.description,
          accountName,
          categoryName: cat ? (lang === 'bn' ? cat.nameBn : cat.name) : tx.categoryId,
          effectivePoisha: baseAmt,
          statPoisha: baseAmt,
          isRefund: false,
          notes: tx.notes || (tx.tags || []).join(', ') || '—',
        });
      } else if (tx.type === 'expense') {
        if (tx.isSplit) {
          const splits = snapshot.transactionSplits.filter(
            (s) =>
              s.transactionId === tx.id &&
              selectedCatSet.has(s.categoryId) &&
              (filters.subcategoryIds.length === 0 ||
                (Boolean(s.subcategoryId) && filters.subcategoryIds.includes(s.subcategoryId!)))
          );
          for (const sp of splits) {
            const splitBase = MoneyMath.convertToBase(
              sp.amountPoisha,
              tx.currency,
              baseCurrency,
              rates
            );
            const cat = snapshot.categories.find((c) => c.id === sp.categoryId);
            lineItems.push({
              date: tx.date,
              description: `${tx.description} [Split: ${cat?.name || sp.categoryId}]`,
              accountName,
              categoryName: cat ? (lang === 'bn' ? cat.nameBn : cat.name) : sp.categoryId,
              effectivePoisha: splitBase,
              statPoisha: splitBase,
              isRefund: false,
              notes: sp.note || tx.notes || 'Split allocation',
            });
          }
        } else if (selectedCatSet.has(tx.categoryId)) {
          const baseAmt = MoneyMath.convertToBase(
            tx.amountPoisha,
            tx.currency,
            baseCurrency,
            rates
          );
          const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
          lineItems.push({
            date: tx.date,
            description: tx.description,
            accountName,
            categoryName: cat ? (lang === 'bn' ? cat.nameBn : cat.name) : tx.categoryId,
            effectivePoisha: baseAmt,
            statPoisha: baseAmt,
            isRefund: false,
            notes: tx.notes || (tx.tags || []).join(', ') || '—',
          });
        }
      } else if (tx.type === 'refund' && selectedCatSet.has(tx.categoryId)) {
        const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
        const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
        lineItems.push({
          date: tx.date,
          description: `${tx.description} (Refund Reversal)`,
          accountName,
          categoryName: cat ? (lang === 'bn' ? cat.nameBn : cat.name) : tx.categoryId,
          effectivePoisha: -baseAmt,
          statPoisha: baseAmt,
          isRefund: true,
          notes: tx.notes || 'Refund reversal',
        });
      }
    }

    const isIncomeOnlyReport =
      selectedCats.length > 0 && selectedCats.every((c) => c.type === 'income');

    let totalBudgetPoisha = 0;
    let totalSpentOrEarnedPoisha = 0;
    const catSummaryRows: string[][] = [];
    const monthlyComparisonRows: string[][] = [];
    const chartItems: BuiltPdfChartItem[] = [];

    for (const cat of selectedCats) {
      const currentVal =
        cat.type === 'expense' ? catSpentMap[cat.id] || 0 : incomeByCatMap[cat.id] || 0;
      const prevVal = cat.type === 'expense' ? prevCatSpentMap[cat.id] || 0 : 0;
      const budgetLimit = cat.monthlyLimitPoisha || 0;

      if (isIncomeOnlyReport || cat.type === 'expense') {
        totalBudgetPoisha += budgetLimit;
        totalSpentOrEarnedPoisha += currentVal;
      }

      const rem = budgetLimit > 0 ? budgetLimit - currentVal : 0;
      const utilPct = budgetLimit > 0 ? MoneyMath.percentage(currentVal, budgetLimit) : 0;

      if (currentVal > 0 || prevVal > 0 || filters.categoryIds.includes(cat.id)) {
        catSummaryRows.push([
          lang === 'bn' ? cat.nameBn : cat.name,
          cat.type.toUpperCase(),
          budgetLimit > 0 ? fmt(budgetLimit) : '—',
          fmt(currentVal),
          budgetLimit > 0 ? fmt(rem) : '—',
          budgetLimit > 0 ? `${utilPct.toFixed(1)}%` : '—',
        ]);

        const diff = currentVal - prevVal;
        const diffPct = prevVal > 0 ? MoneyMath.percentage(Math.abs(diff), prevVal) : 0;
        monthlyComparisonRows.push([
          lang === 'bn' ? cat.nameBn : cat.name,
          fmt(currentVal),
          fmt(prevVal),
          `${diff >= 0 ? '+' : '-'} ${fmt(Math.abs(diff))}`,
          prevVal > 0 ? `${diff >= 0 ? '+' : '-'}${diffPct.toFixed(1)}%` : 'N/A',
        ]);

        chartItems.push({
          label: lang === 'bn' ? cat.nameBn : cat.name,
          valueMajor: Math.round(currentVal / 100),
          formattedValue: fmt(currentVal),
          percent: Math.min(100, utilPct || 60),
          color: cat.color || '#10b981',
        });
      }
    }

    const statAmounts = lineItems.filter((li) => !li.isRefund).map((li) => li.statPoisha);
    const txCount = lineItems.length;
    const netLineSum = Math.max(
      0,
      lineItems.reduce((s, li) => s + li.effectivePoisha, 0)
    );
    const avgPoisha =
      statAmounts.length > 0
        ? Math.round(statAmounts.reduce((s, a) => s + a, 0) / statAmounts.length)
        : 0;
    const maxPoisha = statAmounts.length > 0 ? Math.max(...statAmounts) : 0;
    const minPoisha = statAmounts.length > 0 ? Math.min(...statAmounts) : 0;
    const remainingTotalBudget = Math.max(0, totalBudgetPoisha - totalSpentOrEarnedPoisha);
    const totalUtilPct =
      totalBudgetPoisha > 0
        ? MoneyMath.percentage(totalSpentOrEarnedPoisha, totalBudgetPoisha)
        : 0;

    // Subcategory Breakdown Table
    const subRows: string[][] = [];
    for (const sub of snapshot.subcategories) {
      if (!selectedCatSet.has(sub.categoryId)) continue;
      if (filters.subcategoryIds.length > 0 && !filters.subcategoryIds.includes(sub.id)) continue;
      const sp = subSpentMap[sub.id] || 0;
      if (sp > 0 || filters.subcategoryIds.includes(sub.id)) {
        const parentCat = snapshot.categories.find((c) => c.id === sub.categoryId);
        subRows.push([
          parentCat ? parentCat.name : sub.categoryId,
          lang === 'bn' ? sub.nameBn : sub.name,
          sub.monthlyLimitPoisha ? fmt(sub.monthlyLimitPoisha) : '—',
          fmt(sp),
        ]);
      }
    }

    // Transaction Details Table: Date | Description | Account | Amount | Notes
    const detailRows = lineItems.map((li) => [
      li.date,
      li.description,
      li.accountName,
      li.isRefund ? `- ${fmt(Math.abs(li.effectivePoisha))}` : fmt(li.effectivePoisha),
      li.notes,
    ]);

    const catTitleLabel =
      filters.categoryIds.length === 1
        ? selectedCats[0]?.name || 'Selected Category'
        : filters.categoryIds.length > 1
        ? `${selectedCats.length} Selected Categories`
        : 'All Categories';

    return {
      id: 'sec_category_reports',
      sectionKey: 'category_reports',
      title: `Category Financial Report — ${catTitleLabel}`,
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo} • ${txCount} category ledger entries`,
      kpis: [
        { label: 'Total Budget', value: fmt(totalBudgetPoisha), tone: 'neutral' },
        {
          label: isIncomeOnlyReport ? 'Total Category Income' : 'Total Spending',
          value: fmt(totalSpentOrEarnedPoisha),
          tone: isIncomeOnlyReport ? 'positive' : 'negative',
        },
        { label: 'Remaining Budget', value: fmt(remainingTotalBudget), tone: 'positive' },
        { label: 'Budget Utilization', value: `${totalUtilPct.toFixed(1)}%`, tone: 'accent' },
        { label: 'Total Transactions', value: String(txCount), tone: 'neutral' },
        { label: 'Average Transaction', value: fmt(avgPoisha), tone: 'neutral' },
        { label: 'Highest Transaction', value: fmt(maxPoisha), tone: 'negative' },
        { label: 'Lowest Transaction', value: fmt(minPoisha), tone: 'positive' },
      ],
      charts: [
        {
          title: 'Category Spending Chart',
          type: 'bar',
          items: chartItems.slice(0, 12),
        },
      ],
      tables: [
        {
          title: 'Category Budget & Spending Summary',
          headers: ['Category', 'Type', 'Budget Limit', 'Actual Amount', 'Remaining', 'Usage %'],
          alignRightCols: [2, 3, 4, 5],
          rows: catSummaryRows,
        },
        ...(subRows.length > 0
          ? [
              {
                title: 'Subcategory Breakdown',
                headers: ['Parent Category', 'Subcategory', 'Subcategory Limit', 'Actual Spent'],
                alignRightCols: [2, 3],
                rows: subRows,
              },
            ]
          : []),
        {
          title: 'Monthly Spending Comparison (Current vs Previous Period)',
          headers: ['Category', 'Current Period', 'Previous Period', 'Variance', 'Change %'],
          alignRightCols: [1, 2, 3, 4],
          rows: monthlyComparisonRows,
        },
        {
          title: 'Category Transaction Details (Date | Description | Account | Amount | Notes)',
          headers: ['Date', 'Description', 'Account', 'Amount', 'Notes'],
          alignRightCols: [3],
          rows:
            detailRows.length > 0
              ? detailRows
              : [[filters.dateFrom, 'No matching category transactions', '—', fmt(0), '—']],
          footerRow: ['NET TOTAL', `${txCount} entries`, '', fmt(netLineSum), ''],
        },
      ],
    };
  }

  /**
   * SECTION 2B: INDIVIDUAL & MULTI-SUBCATEGORY REPORT SECTION
   */
  private static buildSubcategoryReportSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;
    const singleAccountFilter =
      filters.accountIds.length === 1 ? filters.accountIds[0] : undefined;

    const subSpentMap = FinancialEngine.computeSubcategoryNetExpenses(
      snapshot,
      filters.dateFrom,
      filters.dateTo,
      singleAccountFilter
    );

    const targetSubs = snapshot.subcategories.filter((sub) => {
      if (filters.subcategoryIds.length > 0 && !filters.subcategoryIds.includes(sub.id)) {
        return false;
      }
      if (filters.categoryIds.length > 0 && !filters.categoryIds.includes(sub.categoryId)) {
        return false;
      }
      return !sub.isArchived;
    });
    const targetSubSet = new Set(targetSubs.map((s) => s.id));

    const rows: string[][] = [];
    const chartItems: BuiltPdfChartItem[] = [];
    let totalSubBudgetPoisha = 0;
    let totalSubSpentPoisha = 0;

    for (const sub of targetSubs) {
      const spent = subSpentMap[sub.id] || 0;
      const limit = sub.monthlyLimitPoisha || 0;
      totalSubBudgetPoisha += limit;
      totalSubSpentPoisha += spent;
      const cat = snapshot.categories.find((c) => c.id === sub.categoryId);
      const utilPct = limit > 0 ? MoneyMath.percentage(spent, limit) : 0;

      rows.push([
        cat ? cat.name : sub.categoryId,
        lang === 'bn' ? sub.nameBn : sub.name,
        limit > 0 ? fmt(limit) : '—',
        fmt(spent),
        limit > 0 ? fmt(Math.max(0, limit - spent)) : '—',
        limit > 0 ? `${utilPct.toFixed(1)}%` : '—',
      ]);

      if (spent > 0 || filters.subcategoryIds.includes(sub.id)) {
        chartItems.push({
          label: `${cat?.name || ''} › ${sub.name}`,
          valueMajor: Math.round(spent / 100),
          formattedValue: fmt(spent),
          percent: Math.min(100, utilPct || 50),
          color: sub.color || cat?.color || '#14b8a6',
        });
      }
    }

    // Extract Subcategory Transaction Details (including split lines with subcategoryId)
    const detailRows: string[][] = [];
    for (const tx of snapshot.transactions) {
      if (tx.date < filters.dateFrom || tx.date > filters.dateTo) continue;
      if (tx.type !== 'expense' && tx.type !== 'refund') continue;
      const acc = snapshot.accounts.find((a) => a.id === tx.accountId);

      if (tx.isSplit) {
        const splits = snapshot.transactionSplits.filter(
          (s) =>
            s.transactionId === tx.id &&
            Boolean(s.subcategoryId) &&
            targetSubSet.has(s.subcategoryId!)
        );
        for (const sp of splits) {
          const sub = snapshot.subcategories.find((s) => s.id === sp.subcategoryId);
          const baseAmt = MoneyMath.convertToBase(
            sp.amountPoisha,
            tx.currency,
            baseCurrency,
            rates
          );
          detailRows.push([
            tx.date,
            `${tx.description} [Split: ${sub?.name || sp.subcategoryId}]`,
            acc?.name || tx.accountId,
            fmt(baseAmt),
            sp.note || tx.notes || '—',
          ]);
        }
      } else if (tx.subcategoryId && targetSubSet.has(tx.subcategoryId)) {
        const sub = snapshot.subcategories.find((s) => s.id === tx.subcategoryId);
        const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
        detailRows.push([
          tx.date,
          `${tx.description} (${sub?.name || tx.subcategoryId})`,
          acc?.name || tx.accountId,
          tx.type === 'refund' ? `- ${fmt(baseAmt)}` : fmt(baseAmt),
          tx.notes || '—',
        ]);
      }
    }

    return {
      id: 'sec_subcategory_reports',
      sectionKey: 'subcategory_reports',
      title: 'Subcategory-Wise Spending & Limit Report',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo}`,
      kpis: [
        { label: 'Subcategories Tracked', value: String(rows.length), tone: 'neutral' },
        { label: 'Total Subcategory Budget', value: fmt(totalSubBudgetPoisha), tone: 'neutral' },
        { label: 'Total Subcategory Spending', value: fmt(totalSubSpentPoisha), tone: 'negative' },
        {
          label: 'Remaining Subcategory Budget',
          value: fmt(Math.max(0, totalSubBudgetPoisha - totalSubSpentPoisha)),
          tone: 'positive',
        },
      ],
      charts: [
        {
          title: 'Subcategory Spending Progress',
          type: 'bar',
          items: chartItems,
        },
      ],
      tables: [
        {
          title: 'Subcategory Breakdown',
          headers: ['Category', 'Subcategory', 'Allocated Limit', 'Actual Spent', 'Remaining', 'Usage %'],
          alignRightCols: [2, 3, 4, 5],
          rows,
          footerRow: [
            'TOTAL',
            `${rows.length} subcategories`,
            fmt(totalSubBudgetPoisha),
            fmt(totalSubSpentPoisha),
            fmt(Math.max(0, totalSubBudgetPoisha - totalSubSpentPoisha)),
            '',
          ],
        },
        {
          title: 'Subcategory Transaction Details (Date | Description | Account | Amount | Notes)',
          headers: ['Date', 'Description', 'Account', 'Amount', 'Notes'],
          alignRightCols: [3],
          rows:
            detailRows.length > 0
              ? detailRows
              : [[filters.dateFrom, 'No subcategory transactions in period', '—', fmt(0), '—']],
          footerRow: [
            'NET TOTAL',
            `${detailRows.length} entries`,
            '',
            fmt(totalSubSpentPoisha),
            '',
          ],
        },
      ],
    };
  }

  /**
   * SECTION 4A: INCOME REPORT
   * Includes: Total income, Income category breakdown, Account-wise income,
   * Daily income, Monthly income, Charts, and Transaction details.
   */
  private static buildIncomeReportSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;
    const incomeTxs = this.filterTransactions(snapshot, {
      ...filters,
      transactionTypes: ['income'],
    });

    let totalIncome = 0;
    const byCat: Record<string, number> = {};
    const byAcc: Record<string, number> = {};
    const byDay: Record<string, number> = {};
    const byMonth: Record<string, number> = {};

    for (const tx of incomeTxs) {
      const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      totalIncome += baseAmt;
      byCat[tx.categoryId] = (byCat[tx.categoryId] || 0) + baseAmt;
      byAcc[tx.accountId] = (byAcc[tx.accountId] || 0) + baseAmt;
      byDay[tx.date] = (byDay[tx.date] || 0) + baseAmt;
      const monthKey = tx.date.slice(0, 7);
      byMonth[monthKey] = (byMonth[monthKey] || 0) + baseAmt;
    }

    const catRows = Object.entries(byCat).map(([catId, p]) => {
      const c = snapshot.categories.find((x) => x.id === catId);
      return [c ? c.name : catId, fmt(p), `${MoneyMath.percentage(p, totalIncome).toFixed(1)}%`];
    });

    const accRows = Object.entries(byAcc).map(([accId, p]) => {
      const a = snapshot.accounts.find((x) => x.id === accId);
      return [a ? a.name : accId, fmt(p), `${MoneyMath.percentage(p, totalIncome).toFixed(1)}%`];
    });

    const dayRows = Object.entries(byDay)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([d, p]) => [d, fmt(p)]);

    const monthRows = Object.entries(byMonth)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([m, p]) => [m, fmt(p)]);

    const txRows = incomeTxs.map((tx) => {
      const a = snapshot.accounts.find((x) => x.id === tx.accountId);
      const c = snapshot.categories.find((x) => x.id === tx.categoryId);
      const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      return [tx.date, tx.description, c?.name || tx.categoryId, a?.name || tx.accountId, fmt(baseAmt)];
    });

    const chartItems: BuiltPdfChartItem[] = Object.entries(byCat).map(([catId, p]) => {
      const c = snapshot.categories.find((x) => x.id === catId);
      return {
        label: c ? c.name : catId,
        valueMajor: Math.round(p / 100),
        formattedValue: fmt(p),
        percent: MoneyMath.percentage(p, totalIncome),
        color: c?.color || '#10b981',
      };
    });

    return {
      id: 'sec_income_report',
      sectionKey: 'income_report',
      title: 'Comprehensive Income Statement & Breakdown',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo} • Excludes transfers & borrowed principal`,
      kpis: [
        { label: 'Total Verified Income', value: fmt(totalIncome), tone: 'positive' },
        { label: 'Income Transactions', value: String(incomeTxs.length), tone: 'neutral' },
        { label: 'Income Categories', value: String(catRows.length), tone: 'neutral' },
        { label: 'Receiving Accounts', value: String(accRows.length), tone: 'accent' },
      ],
      charts: [
        {
          title: 'Income Category Share',
          type: 'bar',
          items: chartItems,
        },
      ],
      tables: [
        {
          title: 'Income Category Breakdown',
          headers: ['Income Category', 'Amount', 'Share %'],
          alignRightCols: [1, 2],
          rows: catRows,
        },
        {
          title: 'Account-Wise Income Receipts',
          headers: ['Account', 'Amount Received', 'Share %'],
          alignRightCols: [1, 2],
          rows: accRows,
        },
        {
          title: 'Daily & Monthly Income Breakdown',
          headers: ['Period / Date', 'Total Income'],
          alignRightCols: [1],
          rows: [...monthRows.map(([m, v]) => [`Month: ${m}`, v]), ...dayRows],
        },
        {
          title: 'Income Transaction Details',
          headers: ['Date', 'Description', 'Category', 'Account', 'Amount'],
          alignRightCols: [4],
          rows: txRows,
          footerRow: ['TOTAL INCOME', `${incomeTxs.length} entries`, '', '', fmt(totalIncome)],
        },
      ],
    };
  }

  /**
   * SECTION 4B: EXPENSE REPORT
   * Includes: Total expenses, Expense category breakdown, Subcategory breakdown,
   * Account-wise expenses, Daily expenses, Monthly expenses, Highest expense,
   * Average expense, Charts, and Transaction details.
   */
  private static buildExpenseReportSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;
    const expTxs = this.filterTransactions(snapshot, {
      ...filters,
      transactionTypes: ['expense', 'refund'],
    });

    const rawExpenses = expTxs.filter((t) => t.type === 'expense');
    const refunds = expTxs.filter((t) => t.type === 'refund');
    const grossPoisha = rawExpenses.reduce(
      (s, t) => s + MoneyMath.convertToBase(t.amountPoisha, t.currency, baseCurrency, rates),
      0
    );
    const refundPoisha = refunds.reduce(
      (s, t) => s + MoneyMath.convertToBase(t.amountPoisha, t.currency, baseCurrency, rates),
      0
    );
    const netExpensePoisha = Math.max(0, grossPoisha - refundPoisha);
    const highestPoisha =
      rawExpenses.length > 0
        ? Math.max(
            ...rawExpenses.map((t) =>
              MoneyMath.convertToBase(t.amountPoisha, t.currency, baseCurrency, rates)
            )
          )
        : 0;
    const avgPoisha = rawExpenses.length > 0 ? Math.round(grossPoisha / rawExpenses.length) : 0;

    const catSpentMap = FinancialEngine.computeCategoryNetExpenses(
      snapshot,
      filters.dateFrom,
      filters.dateTo,
      filters.accountIds[0]
    );
    const subSpentMap = FinancialEngine.computeSubcategoryNetExpenses(
      snapshot,
      filters.dateFrom,
      filters.dateTo,
      filters.accountIds[0]
    );

    const catRows = Object.entries(catSpentMap)
      .filter(([, p]) => p > 0)
      .sort(([, a], [, b]) => b - a)
      .map(([catId, p]) => {
        const c = snapshot.categories.find((x) => x.id === catId);
        return [
          c ? c.name : catId,
          fmt(p),
          `${MoneyMath.percentage(p, netExpensePoisha).toFixed(1)}%`,
        ];
      });

    const subRows = Object.entries(subSpentMap)
      .filter(([, p]) => p > 0)
      .sort(([, a], [, b]) => b - a)
      .map(([subId, p]) => {
        const s = snapshot.subcategories.find((x) => x.id === subId);
        const c = s ? snapshot.categories.find((x) => x.id === s.categoryId) : null;
        return [
          c ? c.name : 'Category',
          s ? s.name : subId,
          fmt(p),
          `${MoneyMath.percentage(p, netExpensePoisha).toFixed(1)}%`,
        ];
      });

    const byAcc: Record<string, number> = {};
    const byDay: Record<string, number> = {};
    const byMonth: Record<string, number> = {};

    for (const tx of expTxs) {
      const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      const signed = tx.type === 'refund' ? -baseAmt : baseAmt;
      byAcc[tx.accountId] = (byAcc[tx.accountId] || 0) + signed;
      byDay[tx.date] = (byDay[tx.date] || 0) + signed;
      const mKey = tx.date.slice(0, 7);
      byMonth[mKey] = (byMonth[mKey] || 0) + signed;
    }

    const accRows = Object.entries(byAcc).map(([accId, p]) => {
      const a = snapshot.accounts.find((x) => x.id === accId);
      const safeP = Math.max(0, p);
      return [
        a ? a.name : accId,
        fmt(safeP),
        `${MoneyMath.percentage(safeP, netExpensePoisha).toFixed(1)}%`,
      ];
    });

    const dayMonthRows = [
      ...Object.entries(byMonth)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([m, p]) => [`Month: ${m}`, fmt(Math.max(0, p))]),
      ...Object.entries(byDay)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([d, p]) => [`Day: ${d}`, fmt(Math.max(0, p))]),
    ];

    const txRows = expTxs.map((tx) => {
      const a = snapshot.accounts.find((x) => x.id === tx.accountId);
      const c = snapshot.categories.find((x) => x.id === tx.categoryId);
      const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      return [
        tx.date,
        tx.description,
        c?.name || tx.categoryId,
        a?.name || tx.accountId,
        tx.type === 'refund' ? `- ${fmt(baseAmt)} (Refund)` : fmt(baseAmt),
      ];
    });

    const chartItems: BuiltPdfChartItem[] = Object.entries(catSpentMap)
      .filter(([, p]) => p > 0)
      .sort(([, a], [, b]) => b - a)
      .map(([catId, p]) => {
        const c = snapshot.categories.find((x) => x.id === catId);
        return {
          label: c ? c.name : catId,
          valueMajor: Math.round(p / 100),
          formattedValue: fmt(p),
          percent: MoneyMath.percentage(p, netExpensePoisha),
          color: c?.color || '#f43f5e',
        };
      });

    return {
      id: 'sec_expense_report',
      sectionKey: 'expense_report',
      title: 'Comprehensive Expense & Refund Statement',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo} • Excludes transfers & loan principal`,
      kpis: [
        { label: 'Net Total Expenses', value: fmt(netExpensePoisha), tone: 'negative' },
        { label: 'Highest Expense', value: fmt(highestPoisha), tone: 'negative' },
        { label: 'Average Expense', value: fmt(avgPoisha), tone: 'neutral' },
        { label: 'Expense Refunds Reversed', value: fmt(refundPoisha), tone: 'positive' },
      ],
      charts: [
        {
          title: 'Expense Category Share',
          type: 'bar',
          items: chartItems,
        },
      ],
      tables: [
        {
          title: 'Expense Category Breakdown',
          headers: ['Expense Category', 'Net Spent', 'Share %'],
          alignRightCols: [1, 2],
          rows: catRows,
        },
        ...(subRows.length > 0
          ? [
              {
                title: 'Subcategory Expense Breakdown',
                headers: ['Parent Category', 'Subcategory', 'Net Spent', 'Share %'],
                alignRightCols: [2, 3],
                rows: subRows,
              },
            ]
          : []),
        {
          title: 'Account-Wise Expenses',
          headers: ['Account', 'Net Spent', 'Share %'],
          alignRightCols: [1, 2],
          rows: accRows,
        },
        {
          title: 'Monthly & Daily Expense Summary',
          headers: ['Period / Date', 'Net Expense'],
          alignRightCols: [1],
          rows: dayMonthRows,
        },
        {
          title: 'Expense & Refund Transaction Details',
          headers: ['Date', 'Description', 'Category', 'Account', 'Amount'],
          alignRightCols: [4],
          rows: txRows,
          footerRow: ['NET EXPENSES', `${expTxs.length} entries`, '', '', fmt(netExpensePoisha)],
        },
      ],
    };
  }

  /**
   * SECTION 6: BUDGET PERFORMANCE REPORTS
   * Display: Category | Budget | Spent | Remaining | Usage %
   * Includes: Overall, Monthly, Category-wise, Subcategory, Over-budget,
   * Remaining budget, and Planned vs Actual comparison.
   */
  private static buildBudgetReportSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const evalBudget = FinancialEngine.evaluateBudget(
      snapshot,
      snapshot.budgets[0]?.id || 'bgt_nov_2026'
    );
    if (!evalBudget) {
      return {
        id: 'sec_budget_reports',
        sectionKey: 'budget_reports',
        title: 'Budget Utilization Report',
        subtitle: 'No active budget found',
        kpis: [],
        charts: [],
        tables: [],
      };
    }

    const catRows = evalBudget.categoryBreakdown.map((item) => [
      item.categoryName,
      fmt(item.allocatedPoisha),
      fmt(item.spentPoisha),
      fmt(item.remainingPoisha),
      `${item.percentUsed.toFixed(1)}% (${item.status.toUpperCase()})`,
    ]);

    const subRows = evalBudget.subcategoryBreakdown.map((sub) => [
      `${sub.categoryName} › ${sub.subcategoryName}`,
      fmt(sub.allocatedPoisha),
      fmt(sub.spentPoisha),
      fmt(sub.remainingPoisha),
      `${sub.percentUsed.toFixed(1)}% (${sub.status.toUpperCase()})`,
    ]);

    const overBudgetRows = [
      ...evalBudget.categoryBreakdown
        .filter((c) => c.percentUsed >= 75)
        .map((c) => [
          `Category: ${c.categoryName}`,
          fmt(c.allocatedPoisha),
          fmt(c.spentPoisha),
          `${c.percentUsed.toFixed(1)}%`,
          c.status.toUpperCase(),
        ]),
      ...evalBudget.subcategoryBreakdown
        .filter((s) => s.percentUsed >= 75)
        .map((s) => [
          `Subcategory: ${s.categoryName} › ${s.subcategoryName}`,
          fmt(s.allocatedPoisha),
          fmt(s.spentPoisha),
          `${s.percentUsed.toFixed(1)}%`,
          s.status.toUpperCase(),
        ]),
    ];

    const chartItems: BuiltPdfChartItem[] = evalBudget.categoryBreakdown.map((item) => ({
      label: item.categoryName,
      valueMajor: Math.round(item.spentPoisha / 100),
      formattedValue: `${fmt(item.spentPoisha)} / ${fmt(item.allocatedPoisha)}`,
      percent: Math.min(100, item.percentUsed),
      color:
        item.percentUsed >= 100
          ? '#e11d48'
          : item.percentUsed >= 75
          ? '#f59e0b'
          : item.categoryColor,
    }));

    return {
      id: 'sec_budget_reports',
      sectionKey: 'budget_reports',
      title: `Budget Performance & Planned vs Actual Report — ${evalBudget.budget.name}`,
      subtitle: `Period: ${evalBudget.budget.startDate} to ${evalBudget.budget.endDate}`,
      kpis: [
        { label: 'Total Planned Budget', value: fmt(evalBudget.totalAllocatedPoisha), tone: 'neutral' },
        { label: 'Actual Spending', value: fmt(evalBudget.totalSpentPoisha), tone: 'negative' },
        { label: 'Remaining Budget', value: fmt(evalBudget.remainingPoisha), tone: 'positive' },
        { label: 'Overall Usage %', value: `${evalBudget.percentUsed.toFixed(1)}%`, tone: 'accent' },
      ],
      charts: [
        {
          title: 'Category Budget Utilization %',
          type: 'horizontal_progress',
          items: chartItems,
        },
      ],
      tables: [
        {
          title: 'Category-Wise Budget vs Actual (Category | Budget | Spent | Remaining | Usage %)',
          headers: ['Category', 'Budget', 'Spent', 'Remaining', 'Usage %'],
          alignRightCols: [1, 2, 3, 4],
          rows: catRows,
          footerRow: [
            'TOTAL BUDGET',
            fmt(evalBudget.totalAllocatedPoisha),
            fmt(evalBudget.totalSpentPoisha),
            fmt(evalBudget.remainingPoisha),
            `${evalBudget.percentUsed.toFixed(1)}%`,
          ],
        },
        ...(subRows.length > 0
          ? [
              {
                title: 'Subcategory Budget Utilization (Subcategory | Budget | Spent | Remaining | Usage %)',
                headers: ['Subcategory', 'Budget', 'Spent', 'Remaining', 'Usage %'],
                alignRightCols: [1, 2, 3, 4],
                rows: subRows,
              },
            ]
          : []),
        ...(overBudgetRows.length > 0
          ? [
              {
                title: 'Over-Budget & High-Utilization Warning Report (>= 75%)',
                headers: ['Scope / Item', 'Planned Limit', 'Actual Spent', 'Usage %', 'Alert Status'],
                alignRightCols: [1, 2, 3],
                rows: overBudgetRows,
              },
            ]
          : []),
      ],
    };
  }

  /**
   * SECTION 5: DEBT AND RECEIVABLE (DENA-PAWNA) PDF REPORTS
   * Includes: All receivables, All payables, Person-wise consolidated statement,
   * Outstanding balance summary, Overdue payment report, and Repayment history.
   */
  private static buildDenaPawnaSection(
    snapshot: DatabaseSnapshot,
    direction: 'receivable' | 'payable',
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const records = snapshot.debts
      .filter((d) => d.direction === direction)
      .filter(
        (d) =>
          !filters.contactName.trim() ||
          d.personName.toLowerCase().includes(filters.contactName.trim().toLowerCase())
      );

    const totalPrincipal = records.reduce((s, d) => s + d.principalPoisha, 0);
    const totalSettled = records.reduce((s, d) => s + d.paidPoisha, 0);
    const totalRemaining = records.reduce((s, d) => s + d.remainingPoisha, 0);

    const rows = records.map((d) => [
      d.personName,
      d.phone || '—',
      d.transactionDate,
      d.dueDate,
      fmt(d.principalPoisha),
      fmt(d.paidPoisha),
      fmt(d.remainingPoisha),
      d.status.toUpperCase(),
    ]);

    // Overdue & Due-Soon Report
    const overdueRows = records
      .filter((d) => d.remainingPoisha > 0)
      .map((d) => [
        d.personName,
        d.dueDate,
        d.reminderDate || '—',
        fmt(d.remainingPoisha),
        d.status === 'overdue' ? 'OVERDUE' : 'UPCOMING DUE',
      ]);

    const paymentRows: string[][] = [];
    for (const d of records) {
      const payments = snapshot.debtPayments.filter((p) => p.debtId === d.id);
      for (const p of payments) {
        const acc = snapshot.accounts.find((a) => a.id === p.accountId);
        paymentRows.push([
          p.paymentDate,
          d.personName,
          p.type.toUpperCase(),
          acc?.name || p.accountId,
          fmt(p.amountPoisha),
          p.note || '—',
        ]);
      }
    }

    return {
      id: `sec_${direction}_report`,
      sectionKey: direction === 'receivable' ? 'receivables_report' : 'payables_report',
      title:
        direction === 'receivable'
          ? 'Receivables (Pawna / Money Lent) Statement'
          : 'Payables (Dena / Money Borrowed) Statement',
      subtitle: 'Loan principal movements are isolated from regular income and expenses',
      kpis: [
        {
          label: direction === 'receivable' ? 'Original Amount Lent' : 'Original Amount Borrowed',
          value: fmt(totalPrincipal),
          tone: 'neutral',
        },
        {
          label: direction === 'receivable' ? 'Total Amount Received' : 'Total Amount Repaid',
          value: fmt(totalSettled),
          tone: 'positive',
        },
        {
          label: direction === 'receivable' ? 'Outstanding Receivable' : 'Remaining Payable',
          value: fmt(totalRemaining),
          tone: 'negative',
        },
      ],
      charts: [],
      tables: [
        {
          title:
            direction === 'receivable'
              ? 'Person-Wise Receivables Statement'
              : 'Person-Wise Payables Statement',
          headers: [
            'Person Name',
            'Phone',
            direction === 'receivable' ? 'Lending Date' : 'Borrowing Date',
            'Due Date',
            'Original Principal',
            direction === 'receivable' ? 'Received' : 'Repaid',
            'Outstanding',
            'Status',
          ],
          alignRightCols: [4, 5, 6],
          rows,
          footerRow: [
            'TOTAL',
            `${records.length} records`,
            '',
            '',
            fmt(totalPrincipal),
            fmt(totalSettled),
            fmt(totalRemaining),
            '',
          ],
        },
        ...(overdueRows.length > 0
          ? [
              {
                title: 'Outstanding & Due Date Reminder Report',
                headers: ['Person Name', 'Due Date', 'Reminder Date', 'Outstanding Amount', 'Urgency'],
                alignRightCols: [3],
                rows: overdueRows,
              },
            ]
          : []),
        ...(paymentRows.length > 0
          ? [
              {
                title: 'Repayment & Collection History',
                headers: ['Date', 'Person', 'Type', 'Account', 'Amount', 'Note'],
                alignRightCols: [4],
                rows: paymentRows,
              },
            ]
          : []),
      ],
    };
  }

  /**
   * SECTION 7A: LOAN & INSTALLMENT REPORTS
   */
  private static buildLoansReportSection(
    snapshot: DatabaseSnapshot,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rows = snapshot.loans.map((l) => [
      l.name,
      l.lender,
      `${l.interestRateAnnual}%`,
      fmt(l.principalPoisha),
      fmt(l.totalInterestPaidPoisha),
      String(l.totalInstallments),
      String(l.paidInstallments),
      String(Math.max(0, l.totalInstallments - l.paidInstallments)),
      fmt(l.remainingPrincipalPoisha),
      l.nextDueDate,
    ]);

    const scheduleRows: string[][] = [];
    for (const loan of snapshot.loans) {
      for (const item of loan.schedule) {
        scheduleRows.push([
          loan.name,
          `#${item.installmentNumber}`,
          item.dueDate,
          fmt(item.installmentPoisha),
          fmt(item.principalPoisha),
          fmt(item.interestPoisha),
          fmt(item.remainingBalancePoisha),
          item.isPaid ? `PAID (${item.paidDate})` : 'DUE',
        ]);
      }
    }

    return {
      id: 'sec_loans_report',
      sectionKey: 'loans_report',
      title: 'Loans & EMI Installment Amortization Report',
      subtitle: 'Principal and interest components tracked separately',
      kpis: [
        { label: 'Active Loans', value: String(snapshot.loans.length), tone: 'neutral' },
        {
          label: 'Total Original Principal',
          value: fmt(snapshot.loans.reduce((s, l) => s + l.principalPoisha, 0)),
          tone: 'neutral',
        },
        {
          label: 'Total Interest Paid',
          value: fmt(snapshot.loans.reduce((s, l) => s + l.totalInterestPaidPoisha, 0)),
          tone: 'negative',
        },
        {
          label: 'Total Outstanding Principal',
          value: fmt(snapshot.loans.reduce((s, l) => s + l.remainingPrincipalPoisha, 0)),
          tone: 'negative',
        },
      ],
      charts: [],
      tables: [
        {
          title: 'Loan Summary & Installment Status',
          headers: [
            'Loan Name',
            'Lender',
            'Rate',
            'Principal',
            'Interest Paid',
            'Total EMIs',
            'Paid EMIs',
            'Rem EMIs',
            'Outstanding Principal',
            'Next Due',
          ],
          alignRightCols: [2, 3, 4, 5, 6, 7, 8],
          rows,
        },
        {
          title: 'EMI Payment & Amortization Schedule',
          headers: [
            'Loan Name',
            'EMI #',
            'Due Date',
            'Installment',
            'Principal Part',
            'Interest Part',
            'Balance After',
            'Status',
          ],
          alignRightCols: [3, 4, 5, 6],
          rows: scheduleRows,
        },
      ],
    };
  }

  /**
   * SECTION 7B: SAVINGS GOALS REPORT
   */
  private static buildSavingsReportSection(
    snapshot: DatabaseSnapshot,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rows = snapshot.savingsGoals.map((g) => {
      const rem = Math.max(0, g.targetAmountPoisha - g.savedAmountPoisha);
      const pct = MoneyMath.percentage(g.savedAmountPoisha, g.targetAmountPoisha);
      return [
        g.name,
        fmt(g.targetAmountPoisha),
        fmt(g.savedAmountPoisha),
        fmt(rem),
        `${pct.toFixed(1)}%`,
        g.targetDate,
      ];
    });

    const contribRows = snapshot.savingsContributions.map((c) => {
      const g = snapshot.savingsGoals.find((x) => x.id === c.goalId);
      return [c.date, g?.name || c.goalId, c.type.toUpperCase(), fmt(c.amountPoisha), c.note];
    });

    return {
      id: 'sec_savings_report',
      sectionKey: 'savings_report',
      title: 'Savings Goals & Reserve Contribution Report',
      subtitle: 'Savings goal allocations are excluded from regular expenses',
      kpis: [
        {
          label: 'Total Target Across Goals',
          value: fmt(snapshot.savingsGoals.reduce((s, g) => s + g.targetAmountPoisha, 0)),
          tone: 'neutral',
        },
        {
          label: 'Total Saved Across Goals',
          value: fmt(snapshot.savingsGoals.reduce((s, g) => s + g.savedAmountPoisha, 0)),
          tone: 'positive',
        },
      ],
      charts: [
        {
          title: 'Savings Goals Completion Progress',
          type: 'bar',
          items: snapshot.savingsGoals.map((g) => ({
            label: g.name,
            valueMajor: Math.round(g.savedAmountPoisha / 100),
            formattedValue: fmt(g.savedAmountPoisha),
            percent: Math.min(100, MoneyMath.percentage(g.savedAmountPoisha, g.targetAmountPoisha)),
            color: g.color || '#10b981',
          })),
        },
      ],
      tables: [
        {
          title: 'Savings Goals Progress',
          headers: [
            'Goal Name',
            'Target Amount',
            'Current Savings',
            'Remaining',
            'Completion %',
            'Target Date',
          ],
          alignRightCols: [1, 2, 3, 4],
          rows,
        },
        ...(contribRows.length > 0
          ? [
              {
                title: 'Contribution & Withdrawal History',
                headers: ['Date', 'Goal', 'Type', 'Amount', 'Note'],
                alignRightCols: [3],
                rows: contribRows,
              },
            ]
          : []),
      ],
    };
  }

  private static buildRecurringReportSection(
    snapshot: DatabaseSnapshot,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rows = snapshot.recurringTransactions.map((r) => [
      r.title,
      r.type.toUpperCase(),
      r.frequency.toUpperCase(),
      fmt(r.amountPoisha),
      r.nextExecutionDate,
      r.lastExecutedDate || 'Never',
      r.status.toUpperCase(),
    ]);

    return {
      id: 'sec_recurring_report',
      sectionKey: 'recurring_report',
      title: 'Recurring Transactions & Scheduled Bills Report',
      subtitle: 'Idempotent scheduled rules',
      kpis: [],
      charts: [],
      tables: [
        {
          title: 'Recurring Rules Schedule',
          headers: [
            'Title',
            'Type',
            'Frequency',
            'Amount',
            'Next Execution',
            'Last Posted',
            'Status',
          ],
          alignRightCols: [3],
          rows,
        },
      ],
    };
  }

  private static buildPeriodSummarySection(
    snapshot: DatabaseSnapshot,
    sectionKey: PdfSectionKey,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;
    const txs = this.filterTransactions(snapshot, filters);
    const map: Record<string, { income: number; expense: number; count: number }> = {};

    for (const tx of txs) {
      const key =
        sectionKey === 'yearly_summary'
          ? tx.date.slice(0, 4)
          : sectionKey === 'monthly_summary'
          ? tx.date.slice(0, 7)
          : tx.date;
      if (!map[key]) map[key] = { income: 0, expense: 0, count: 0 };
      map[key].count += 1;
      const baseAmt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      if (tx.type === 'income') map[key].income += baseAmt;
      else if (tx.type === 'expense') map[key].expense += baseAmt;
      else if (tx.type === 'refund')
        map[key].expense = Math.max(0, map[key].expense - baseAmt);
    }

    const rows = Object.entries(map)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([period, d]) => [
        period,
        String(d.count),
        fmt(d.income),
        fmt(d.expense),
        fmt(d.income - d.expense),
      ]);

    return {
      id: `sec_${sectionKey}`,
      sectionKey,
      title:
        sectionKey === 'yearly_summary'
          ? 'Yearly Financial Summary'
          : sectionKey === 'monthly_summary'
          ? 'Monthly Financial Summary'
          : 'Cash Flow Statement',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo}`,
      kpis: [],
      charts: [],
      tables: [
        {
          title: 'Period-Wise Cash Flow Breakdown',
          headers: ['Period', 'Transactions', 'Total Income', 'Net Expenses', 'Net Cash Flow'],
          alignRightCols: [1, 2, 3, 4],
          rows,
        },
      ],
    };
  }

  private static buildNetWorthSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const m = FinancialEngine.computeDashboardMetrics(
      snapshot,
      filters.dateFrom,
      filters.dateTo
    );
    return {
      id: 'sec_networth_report',
      sectionKey: 'networth_report',
      title: 'Personal Net Worth & Balance Sheet Statement',
      subtitle: `As of ${filters.dateTo}`,
      kpis: [
        {
          label: 'Total Assets',
          value: fmt(m.totalBalancePoisha + m.totalReceivablePoisha),
          tone: 'positive',
        },
        {
          label: 'Total Liabilities',
          value: fmt(m.totalPayablePoisha + m.remainingLoanLiabilityPoisha),
          tone: 'negative',
        },
        { label: 'Net Worth', value: fmt(m.netWorthPoisha), tone: 'accent' },
      ],
      charts: [],
      tables: [
        {
          title: 'Assets vs Liabilities Statement',
          headers: ['Component', 'Category', 'Amount'],
          alignRightCols: [2],
          rows: [
            ['Active Account Balances', 'Asset (+)', fmt(m.totalBalancePoisha)],
            ['Outstanding Receivables (Pawna)', 'Asset (+)', fmt(m.totalReceivablePoisha)],
            ['Outstanding Payables (Dena)', 'Liability (-)', fmt(m.totalPayablePoisha)],
            ['Remaining Loan Principal', 'Liability (-)', fmt(m.remainingLoanLiabilityPoisha)],
          ],
          footerRow: ['NET WORTH', 'Assets minus Liabilities', fmt(m.netWorthPoisha)],
        },
      ],
    };
  }

  private static buildAllTransactionsSection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const txs = this.filterTransactions(snapshot, filters);
    const rows = txs.map((tx) => {
      const acc = snapshot.accounts.find((a) => a.id === tx.accountId);
      const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
      return [
        tx.date,
        tx.type.toUpperCase(),
        tx.description,
        cat?.name || tx.categoryId,
        acc?.name || tx.accountId,
        fmt(tx.amountPoisha),
        tx.notes || '—',
      ];
    });

    return {
      id: 'sec_all_transactions',
      sectionKey: 'all_transactions',
      title: 'Complete Financial Transaction Register',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo} (${txs.length} transactions)`,
      kpis: [],
      charts: [],
      tables: [
        {
          title: 'Chronological Ledger Entries',
          headers: ['Date', 'Type', 'Description', 'Category', 'Account', 'Amount', 'Notes'],
          alignRightCols: [5],
          rows,
        },
      ],
    };
  }

  private static buildDashboardSummarySection(
    snapshot: DatabaseSnapshot,
    filters: PdfFilterOptions,
    lang: 'en' | 'bn',
    fmt: (poisha: number) => string
  ): BuiltPdfSection {
    const m = FinancialEngine.computeDashboardMetrics(
      snapshot,
      filters.dateFrom,
      filters.dateTo
    );
    const accRows = snapshot.accounts
      .filter((a) => a.status === 'active')
      .map((a) => [
        a.name,
        a.type.toUpperCase(),
        formatCurrency(a.openingBalancePoisha, {
          currency: a.currency,
          numberFormat: snapshot.settings.numberFormat,
          precision: snapshot.settings.currencyPrecision,
        }),
        formatCurrency(a.currentBalancePoisha, {
          currency: a.currency,
          numberFormat: snapshot.settings.numberFormat,
          precision: snapshot.settings.currencyPrecision,
        }),
      ]);

    return {
      id: 'sec_dashboard_summary',
      sectionKey: 'dashboard_summary',
      title: 'Executive Dashboard Financial Summary',
      subtitle: `Period: ${filters.dateFrom} to ${filters.dateTo}`,
      kpis: [
        { label: 'Total Balance', value: fmt(m.totalBalancePoisha), tone: 'accent' },
        { label: 'Period Income', value: fmt(m.totalIncomePoisha), tone: 'positive' },
        { label: 'Period Expenses', value: fmt(m.totalExpensePoisha), tone: 'negative' },
        { label: 'Net Cash Flow', value: fmt(m.netCashFlowPoisha), tone: 'positive' },
      ],
      charts: [],
      tables: [
        {
          title: 'Active Account Balances Overview',
          headers: ['Account Name', 'Type', 'Opening Balance', 'Current Balance'],
          alignRightCols: [2, 3],
          rows: accRows,
        },
      ],
    };
  }
}
