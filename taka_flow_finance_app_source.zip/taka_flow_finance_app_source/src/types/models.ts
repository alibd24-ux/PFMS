// ============================================================================
// PHASE 1: NORMALIZED & VERSIONED DATA MODELS (19 REQUIRED ENTITIES)
// All monetary values are stored in integer minor units (1 Taka = 100 Poisha)
// to guarantee zero floating-point rounding errors.
// ============================================================================

export type LanguageCode = 'en' | 'bn';
export type CurrencyCode = 'BDT' | 'USD' | 'EUR' | 'GBP' | 'INR';
export type NumberFormatStyle = 'bd_lakh' | 'intl' | 'bn_digits';
export type ThemeMode = 'light' | 'dark' | 'system';

export type TransactionType =
  | 'income'
  | 'expense'
  | 'transfer'
  | 'refund'
  | 'loan_received'
  | 'loan_given'
  | 'debt_repayment'
  | 'debt_collection';

export type AccountType =
  | 'cash'
  | 'bank'
  | 'savings'
  | 'credit_card'
  | 'mobile_wallet'
  | 'other';

export type BudgetPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
export type DebtDirection = 'payable' | 'receivable';
export type DebtStatus = 'active' | 'partial' | 'settled' | 'overdue';
export type LoanCategoryType = 'personal' | 'bank' | 'credit_card' | 'installment' | 'emi';
export type RecurrenceFrequency = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly' | 'custom';

// 1. AppSettings
export interface AppSettings {
  id: string;
  appName: string;
  language: LanguageCode;
  defaultCurrency: CurrencyCode;
  dateFormat: 'YYYY-MM-DD' | 'DD/MM/YYYY' | 'DD MMM YYYY';
  numberFormat: NumberFormatStyle;
  firstDayOfWeek: 'saturday' | 'sunday' | 'monday';
  financialMonthStartDay: number;
  theme: ThemeMode;
  accentColor: 'emerald' | 'indigo' | 'teal' | 'rose' | 'amber' | 'violet';
  fontSize: 'sm' | 'md' | 'lg';
  dashboardLayout: 'standard' | 'compact' | 'analytics_first';
  navigationLayout: 'bottom_bar' | 'rail';
  defaultAccountId: string;
  defaultTransactionType: TransactionType;
  defaultBudgetPeriod: BudgetPeriod;
  budgetWarningThresholds: number[]; // e.g., [50, 75, 90, 100]
  currencyPrecision: 0 | 2;
  exchangeRates: Record<CurrencyCode, number>; // units of BDT per 1 unit of currency
  notificationsConfig: {
    budgetAlerts: boolean;
    paymentReminders: boolean;
    recurringReminders: boolean;
    debtDueReminders: boolean;
    savingsReminders: boolean;
  };
  enabledModules: {
    budgets: boolean;
    debts: boolean;
    loans: boolean;
    savings: boolean;
    recurring: boolean;
    reports: boolean;
  };
  schemaVersion: number;
  updatedAt: string;
}

// 2. Accounts
export interface Account {
  id: string;
  name: string;
  nameBn?: string;
  type: AccountType;
  openingBalancePoisha: number; // Integer minor units (poisha)
  currentBalancePoisha: number; // Derived from openingBalancePoisha + ledger
  currency: CurrencyCode;
  icon: string;
  color: string;
  description: string;
  alertThresholdPoisha: number;
  status: 'active' | 'archived';
  createdAt: string;
  updatedAt: string;
}

// 3. Transactions
export interface Transaction {
  id: string;
  type: TransactionType;
  amountPoisha: number; // Always positive integer poisha
  currency: CurrencyCode;
  exchangeRateToBase: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  accountId: string;
  destinationAccountId?: string; // Used for 'transfer'
  categoryId: string;
  subcategoryId?: string;
  contactId?: string;
  personName?: string;
  description: string;
  notes: string;
  tags: string[];
  paymentMethod: string;
  attachmentId?: string;
  isSplit: boolean;
  linkedTransactionId?: string; // For refund referencing original expense
  debtId?: string;
  loanId?: string;
  loanPrincipalPoisha?: number;
  loanInterestPoisha?: number;
  recurringId?: string;
  fingerprint: string; // Dedup key
  createdAt: string;
  updatedAt: string;
}

// 4. TransactionSplits
export interface TransactionSplit {
  id: string;
  transactionId: string;
  categoryId: string;
  subcategoryId?: string;
  amountPoisha: number;
  note: string;
}

// 5. Categories
export interface Category {
  id: string;
  name: string;
  nameBn: string;
  type: 'income' | 'expense';
  groupName: string; // e.g., 'Family', 'Office', 'Personal', 'Essential', 'Financial', 'Income'
  icon: string;
  color: string;
  sortOrder: number;
  monthlyLimitPoisha: number;
  isEnabled: boolean;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
}

// 6. Subcategories
export interface Subcategory {
  id: string;
  categoryId: string;
  name: string;
  nameBn: string;
  icon: string;
  color: string;
  monthlyLimitPoisha?: number;
  isArchived: boolean;
  createdAt: string;
}

// 7. Budgets
export interface Budget {
  id: string;
  name: string;
  period: BudgetPeriod;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  totalLimitPoisha: number;
  accountId?: string; // Optional account-specific budget filter
  combinedCategoryIds?: string[]; // Optional combined multi-category filter
  warningThresholds: number[]; // [50, 75, 90, 100]
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// 8. BudgetCategories
export interface BudgetCategory {
  id: string;
  budgetId: string;
  categoryId: string;
  subcategoryId?: string;
  allocatedPoisha: number;
}

// 9. Contacts
export interface Contact {
  id: string;
  name: string;
  phone: string;
  email?: string;
  relation: string;
  notes: string;
  createdAt: string;
}

// 10. Debts (Dena-Pawna)
export interface DebtRecord {
  id: string;
  direction: DebtDirection; // 'payable' (Money I Owe) | 'receivable' (Money Others Owe Me)
  contactId?: string;
  personName: string;
  phone: string;
  principalPoisha: number;
  paidPoisha: number;
  remainingPoisha: number;
  transactionDate: string;
  dueDate: string;
  reminderDate?: string;
  accountId: string;
  purpose: string;
  description: string;
  notes: string;
  status: DebtStatus;
  initialTransactionId?: string;
  createdAt: string;
  updatedAt: string;
}

// 11. DebtPayments
export interface DebtPayment {
  id: string;
  debtId: string;
  transactionId: string;
  amountPoisha: number;
  paymentDate: string;
  accountId: string;
  type: 'repayment' | 'collection' | 'settlement';
  note: string;
  createdAt: string;
}

// 12. Loans & Installments
export interface LoanScheduleItem {
  installmentNumber: number;
  dueDate: string;
  installmentPoisha: number;
  principalPoisha: number;
  interestPoisha: number;
  remainingBalancePoisha: number;
  isPaid: boolean;
  paidDate?: string;
  paymentId?: string;
}

export interface LoanRecord {
  id: string;
  name: string;
  loanType: LoanCategoryType;
  lender: string;
  principalPoisha: number;
  interestRateAnnual: number; // Percentage, e.g. 9.5 or 0 for interest-free
  loanDate: string;
  totalInstallments: number;
  installmentAmountPoisha: number;
  nextDueDate: string;
  remainingPrincipalPoisha: number;
  totalInterestPaidPoisha: number;
  paidInstallments: number;
  accountId: string;
  status: 'active' | 'completed';
  schedule: LoanScheduleItem[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// 13. LoanPayments
export interface LoanPayment {
  id: string;
  loanId: string;
  transactionId: string;
  installmentNumber: number;
  totalAmountPoisha: number;
  principalComponentPoisha: number;
  interestComponentPoisha: number;
  paymentDate: string;
  accountId: string;
  note: string;
  createdAt: string;
}

// 14. SavingsGoals
export interface SavingsGoal {
  id: string;
  name: string;
  targetAmountPoisha: number;
  savedAmountPoisha: number;
  targetDate: string;
  accountId: string;
  icon: string;
  color: string;
  description: string;
  status: 'active' | 'completed';
  createdAt: string;
  updatedAt: string;
}

// 15. SavingsContributions
export interface SavingsContribution {
  id: string;
  goalId: string;
  type: 'deposit' | 'withdrawal';
  amountPoisha: number;
  date: string;
  accountId: string;
  note: string;
  createdAt: string;
}

// 16. RecurringTransactions
export interface RecurringTransaction {
  id: string;
  title: string;
  type: 'income' | 'expense' | 'transfer';
  amountPoisha: number;
  accountId: string;
  destinationAccountId?: string;
  categoryId: string;
  subcategoryId?: string;
  frequency: RecurrenceFrequency;
  customIntervalDays?: number;
  startDate: string;
  endDate?: string;
  nextExecutionDate: string;
  lastExecutedDate?: string;
  autoPost: boolean;
  status: 'active' | 'paused' | 'cancelled';
  description: string;
  createdAt: string;
  updatedAt: string;
}

// 17. Attachments
export interface Attachment {
  id: string;
  transactionId: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  dataUrl: string;
  createdAt: string;
}

// 18. Notifications
export interface AppNotification {
  id: string;
  type: 'budget_alert' | 'payment_reminder' | 'recurring_due' | 'debt_due' | 'savings_milestone' | 'account_low';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  relatedEntityId?: string;
  isRead: boolean;
  createdAt: string;
}

// 19. AuditLogs
export interface AuditLog {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  summary: string;
  detailsJson: string;
  timestamp: string;
}

// Complete Database State Snapshot (used by in-memory cache, IndexedDB sync, and JSON Backup/Restore)
export interface DatabaseSnapshot {
  schemaVersion: number;
  exportedAt: string;
  settings: AppSettings;
  accounts: Account[];
  transactions: Transaction[];
  transactionSplits: TransactionSplit[];
  categories: Category[];
  subcategories: Subcategory[];
  budgets: Budget[];
  budgetCategories: BudgetCategory[];
  contacts: Contact[];
  debts: DebtRecord[];
  debtPayments: DebtPayment[];
  loans: LoanRecord[];
  loanPayments: LoanPayment[];
  savingsGoals: SavingsGoal[];
  savingsContributions: SavingsContribution[];
  recurringTransactions: RecurringTransaction[];
  attachments: Attachment[];
  notifications: AppNotification[];
  auditLogs: AuditLog[];
}

export interface FilterPreset {
  id: string;
  name: string;
  searchQuery: string;
  type: TransactionType | 'all';
  accountId: string;
  categoryId: string;
  subcategoryId: string;
  person: string;
  tag: string;
  dateFrom: string;
  dateTo: string;
  minAmount: string;
  maxAmount: string;
}
