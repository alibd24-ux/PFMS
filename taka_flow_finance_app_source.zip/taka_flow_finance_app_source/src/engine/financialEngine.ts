// ============================================================================
// PHASE 3, 5, 6, 7, 8, 11 & 18: CENTRALIZED FINANCIAL CALCULATION ENGINE
// Audited & Verified Implementation enforcing all accounting invariants across:
// Dashboard, Transactions, Accounts, Categories, Subcategories, Budgets,
// Debts (Dena-Pawna), Loans & EMIs, Savings Goals, Recurring Rules, & Backups.
// ============================================================================

import {
  Account,
  AppNotification,
  AuditLog,
  Budget,
  BudgetCategory,
  Category,
  CurrencyCode,
  DatabaseSnapshot,
  DebtPayment,
  DebtRecord,
  LoanPayment,
  LoanRecord,
  RecurringTransaction,
  SavingsContribution,
  SavingsGoal,
  Subcategory,
  Transaction,
  TransactionSplit,
  TransactionType,
} from '../types/models';
import { CURRENT_SCHEMA_VERSION } from '../db/database';
import { MoneyMath, poishaToMajorString, toPoisha } from '../utils/money';

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export interface DashboardMetrics {
  totalBalancePoisha: number;
  totalIncomePoisha: number;
  totalExpensePoisha: number;
  netCashFlowPoisha: number;
  totalReceivablePoisha: number;
  totalPayablePoisha: number;
  totalSavingsPoisha: number;
  monthlyBudgetAllocatedPoisha: number;
  monthlyBudgetSpentPoisha: number;
  monthlyBudgetPercent: number;
  netWorthPoisha: number;
  remainingLoanLiabilityPoisha: number;
}

export interface SubcategoryBudgetRow {
  allocationId: string;
  subcategoryId: string;
  subcategoryName: string;
  categoryId: string;
  categoryName: string;
  categoryColor: string;
  allocatedPoisha: number;
  spentPoisha: number;
  previousSpentPoisha: number;
  remainingPoisha: number;
  percentUsed: number;
  status: 'safe' | 'warning_50' | 'warning_75' | 'warning_90' | 'exceeded';
}

export interface BudgetAlertItem {
  id: string;
  scope: 'overall' | 'category' | 'subcategory';
  name: string;
  allocatedPoisha: number;
  spentPoisha: number;
  percentUsed: number;
  status: 'warning_50' | 'warning_75' | 'warning_90' | 'exceeded';
}

export interface BudgetEvaluation {
  budget: Budget;
  totalAllocatedPoisha: number;
  totalSpentPoisha: number;
  remainingPoisha: number;
  percentUsed: number;
  previousMonthSpentPoisha: number;
  status: 'safe' | 'warning_50' | 'warning_75' | 'warning_90' | 'exceeded';
  categoryBreakdown: Array<{
    allocationId: string;
    categoryId: string;
    categoryName: string;
    categoryColor: string;
    allocatedPoisha: number;
    spentPoisha: number;
    previousSpentPoisha: number;
    remainingPoisha: number;
    percentUsed: number;
    status: 'safe' | 'warning_50' | 'warning_75' | 'warning_90' | 'exceeded';
  }>;
  subcategoryBreakdown: SubcategoryBudgetRow[];
  alerts: BudgetAlertItem[];
}

export class FinancialEngine {
  /**
   * Generates a deterministic deduplication fingerprint for a transaction.
   */
  public static computeTransactionFingerprint(tx: {
    type: TransactionType;
    accountId: string;
    destinationAccountId?: string;
    categoryId: string;
    amountPoisha: number;
    date: string;
    description: string;
  }): string {
    return [
      tx.type,
      tx.accountId,
      tx.destinationAccountId || '',
      tx.categoryId || '',
      Math.round(tx.amountPoisha),
      tx.date,
      (tx.description || '').trim().toLowerCase(),
    ].join('|');
  }

  /**
   * Recalculates all account balances strictly from openingBalancePoisha + ledger entries,
   * synchronizes debtPayments & loanPayments with ledger transactions, updates debt statuses,
   * reconciles loans and savings totals, and generates notifications.
   * NEVER modifies account balances independently of transaction records.
   */
  public static recalculateSnapshotIntegrity(snapshot: DatabaseSnapshot): DatabaseSnapshot {
    const rates = snapshot.settings.exchangeRates;

    // 1. Reset each account to its openingBalancePoisha
    const balanceMap: Record<string, number> = {};
    for (const acc of snapshot.accounts) {
      balanceMap[acc.id] = Math.round(acc.openingBalancePoisha || 0);
    }

    const txById = new Map<string, Transaction>();
    for (const tx of snapshot.transactions) {
      txById.set(tx.id, tx);
    }

    // 2. Apply every transaction according to strict accounting rules
    for (const tx of snapshot.transactions) {
      const amt = Math.round(tx.amountPoisha || 0);
      if (amt <= 0) continue;

      const sourceAcc = snapshot.accounts.find((a) => a.id === tx.accountId);
      if (!sourceAcc) continue;

      const amtInSourceCurrency =
        tx.currency === sourceAcc.currency
          ? amt
          : MoneyMath.convertToBase(amt, tx.currency, sourceAcc.currency, rates);

      switch (tx.type) {
        case 'income':
        case 'refund':
        case 'loan_received':
        case 'debt_collection':
          balanceMap[sourceAcc.id] = MoneyMath.add(balanceMap[sourceAcc.id], amtInSourceCurrency);
          break;

        case 'expense':
        case 'loan_given':
        case 'debt_repayment':
          balanceMap[sourceAcc.id] = MoneyMath.subtract(balanceMap[sourceAcc.id], amtInSourceCurrency);
          break;

        case 'transfer': {
          balanceMap[sourceAcc.id] = MoneyMath.subtract(balanceMap[sourceAcc.id], amtInSourceCurrency);
          if (tx.destinationAccountId) {
            const destAcc = snapshot.accounts.find((a) => a.id === tx.destinationAccountId);
            if (destAcc) {
              const amtInDestCurrency =
                tx.currency === destAcc.currency
                  ? amt
                  : MoneyMath.convertToBase(amt, tx.currency, destAcc.currency, rates);
              balanceMap[destAcc.id] = MoneyMath.add(balanceMap[destAcc.id], amtInDestCurrency);
            }
          }
          break;
        }
      }
    }

    const updatedAccounts: Account[] = snapshot.accounts.map((acc) => ({
      ...acc,
      currentBalancePoisha: balanceMap[acc.id] ?? acc.openingBalancePoisha,
    }));

    // 3. Synchronize DebtPayments with their underlying Transaction (in case a transaction was edited or deleted)
    const syncedDebtPayments: DebtPayment[] = snapshot.debtPayments
      .filter((dp) => txById.has(dp.transactionId))
      .map((dp) => {
        const linkedTx = txById.get(dp.transactionId)!;
        return {
          ...dp,
          amountPoisha: Math.round(linkedTx.amountPoisha),
          paymentDate: linkedTx.date,
          accountId: linkedTx.accountId,
        };
      });

    // 4. Reconcile Dena-Pawna (Debts) paid & remaining amounts from syncedDebtPayments
    const refTodayStr = '2026-11-06';
    const updatedDebts: DebtRecord[] = snapshot.debts.map((debt) => {
      const payments = syncedDebtPayments.filter((p) => p.debtId === debt.id);
      const paidPoisha = payments.reduce((sum, p) => sum + Math.round(p.amountPoisha || 0), 0);
      const remainingPoisha = Math.max(0, Math.round(debt.principalPoisha) - paidPoisha);
      let status: DebtRecord['status'] = 'active';
      if (remainingPoisha === 0) {
        status = 'settled';
      } else if (debt.dueDate && debt.dueDate < refTodayStr) {
        status = 'overdue';
      } else if (paidPoisha > 0) {
        status = 'partial';
      }
      return {
        ...debt,
        paidPoisha,
        remainingPoisha,
        status,
      };
    });

    // 5. Synchronize LoanPayments & Loan Schedules with active Transactions
    const syncedLoanPayments: LoanPayment[] = (snapshot.loanPayments || []).filter((lp) =>
      txById.has(lp.transactionId)
    );
    const updatedLoans: LoanRecord[] = snapshot.loans.map((loan) => {
      const loanPayMap = new Map<number, LoanPayment>();
      for (const lp of syncedLoanPayments) {
        if (lp.loanId === loan.id) {
          loanPayMap.set(lp.installmentNumber, lp);
        }
      }
      let principalPaid = 0;
      let interestPaid = 0;
      let paidCount = 0;
      const updatedSchedule = loan.schedule.map((item) => {
        const lp = loanPayMap.get(item.installmentNumber);
        if (lp) {
          principalPaid += item.principalPoisha;
          interestPaid += item.interestPoisha;
          paidCount += 1;
          return {
            ...item,
            isPaid: true,
            paidDate: lp.paymentDate,
            paymentId: lp.id,
          };
        }
        return {
          ...item,
          isPaid: false,
          paidDate: undefined,
          paymentId: undefined,
        };
      });
      const remainingPrincipalPoisha = Math.max(0, loan.principalPoisha - principalPaid);
      const nextUnpaid = updatedSchedule.find((s) => !s.isPaid);
      return {
        ...loan,
        schedule: updatedSchedule,
        remainingPrincipalPoisha,
        totalInterestPaidPoisha: interestPaid,
        paidInstallments: paidCount,
        nextDueDate: nextUnpaid ? nextUnpaid.dueDate : loan.nextDueDate,
        status: remainingPrincipalPoisha === 0 || !nextUnpaid ? 'completed' : 'active',
      };
    });

    // 6. Reconcile Savings Goals from SavingsContributions
    const updatedSavingsGoals: SavingsGoal[] = snapshot.savingsGoals.map((goal) => {
      const contribs = snapshot.savingsContributions.filter((c) => c.goalId === goal.id);
      const netSaved = contribs.reduce((sum, c) => {
        return c.type === 'deposit'
          ? sum + Math.round(c.amountPoisha || 0)
          : sum - Math.round(c.amountPoisha || 0);
      }, 0);
      const savedAmountPoisha = Math.max(0, netSaved);
      return {
        ...goal,
        savedAmountPoisha,
        status: savedAmountPoisha >= goal.targetAmountPoisha ? 'completed' : 'active',
      };
    });

    // 7. Generate low-balance and debt due notifications if enabled
    const notifications = [...snapshot.notifications];
    if (snapshot.settings.notificationsConfig.budgetAlerts) {
      for (const acc of updatedAccounts) {
        if (
          acc.status === 'active' &&
          acc.alertThresholdPoisha > 0 &&
          acc.currentBalancePoisha < acc.alertThresholdPoisha
        ) {
          const alertId = `notif_low_acc_${acc.id}`;
          if (!notifications.some((n) => n.id === alertId)) {
            notifications.unshift({
              id: alertId,
              type: 'account_low',
              severity: 'warning',
              title: `Low Balance Alert: ${acc.name}`,
              message: `${acc.name} balance is below your configured alert threshold.`,
              relatedEntityId: acc.id,
              isRead: false,
              createdAt: new Date().toISOString(),
            });
          }
        }
      }
    }

    if (snapshot.settings.notificationsConfig.debtDueReminders) {
      for (const debt of updatedDebts) {
        if (
          debt.remainingPoisha > 0 &&
          (debt.status === 'overdue' || (debt.reminderDate && debt.reminderDate <= refTodayStr))
        ) {
          const notifId = `notif_debt_${debt.id}_${debt.status}`;
          if (!notifications.some((n) => n.id === notifId)) {
            notifications.unshift({
              id: notifId,
              type: 'debt_due',
              severity: debt.status === 'overdue' ? 'critical' : 'warning',
              title: `${debt.status === 'overdue' ? 'Overdue' : 'Due Reminder'}: ${debt.personName}`,
              message: `${
                debt.direction === 'receivable' ? 'Receivable (Pawna)' : 'Payable (Dena)'
              } of ৳ ${poishaToMajorString(debt.remainingPoisha)} is due on ${debt.dueDate}.`,
              relatedEntityId: debt.id,
              isRead: false,
              createdAt: new Date().toISOString(),
            });
          }
        }
      }
    }

    return {
      ...snapshot,
      accounts: updatedAccounts,
      debts: updatedDebts,
      debtPayments: syncedDebtPayments,
      loans: updatedLoans,
      loanPayments: syncedLoanPayments,
      savingsGoals: updatedSavingsGoals,
      notifications: notifications.slice(0, 60),
    };
  }

  /**
   * Validates and adds or updates a transaction, enforcing all financial integrity rules.
   */
  public static upsertTransaction(
    snapshot: DatabaseSnapshot,
    txInput: Omit<Transaction, 'fingerprint' | 'createdAt' | 'updatedAt'> & {
      id?: string;
      splits?: Array<{ categoryId: string; subcategoryId?: string; amountPoisha: number; note: string }>;
      allowDuplicate?: boolean;
    }
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot; transaction?: Transaction } {
    if (!txInput.amountPoisha || txInput.amountPoisha <= 0) {
      return { ok: false, error: 'Transaction amount must be greater than zero.', snapshot };
    }
    if (!txInput.accountId || !snapshot.accounts.some((a) => a.id === txInput.accountId)) {
      return { ok: false, error: 'Please select a valid source account.', snapshot };
    }
    if (txInput.type === 'transfer') {
      if (!txInput.destinationAccountId || !snapshot.accounts.some((a) => a.id === txInput.destinationAccountId)) {
        return { ok: false, error: 'Please select a valid destination account for the transfer.', snapshot };
      }
      if (txInput.accountId === txInput.destinationAccountId) {
        return { ok: false, error: 'Source and destination accounts cannot be the same.', snapshot };
      }
    }
    if (txInput.isSplit && txInput.splits && txInput.splits.length > 0) {
      const splitSum = txInput.splits.reduce((s, item) => s + Math.round(item.amountPoisha || 0), 0);
      if (splitSum !== Math.round(txInput.amountPoisha)) {
        return {
          ok: false,
          error: `Split category amounts (${poishaToMajorString(splitSum)}) must equal the total transaction amount (${poishaToMajorString(txInput.amountPoisha)}).`,
          snapshot,
        };
      }
    }

    const fingerprint = this.computeTransactionFingerprint(txInput);
    const existingIndex = txInput.id
      ? snapshot.transactions.findIndex((t) => t.id === txInput.id)
      : -1;

    if (existingIndex === -1 && !txInput.allowDuplicate) {
      const duplicate = snapshot.transactions.find((t) => t.fingerprint === fingerprint);
      if (duplicate) {
        return {
          ok: false,
          error: 'Duplicate transaction detected with identical date, account, category, amount, and description. Use Duplicate if intentional.',
          snapshot,
        };
      }
    }

    const now = new Date().toISOString();
    const txId = txInput.id || `txn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const newTx: Transaction = {
      id: txId,
      type: txInput.type,
      amountPoisha: Math.round(txInput.amountPoisha),
      currency: txInput.currency || snapshot.settings.defaultCurrency,
      exchangeRateToBase: txInput.exchangeRateToBase || 1,
      date: txInput.date,
      time: txInput.time || '12:00',
      accountId: txInput.accountId,
      destinationAccountId: txInput.type === 'transfer' ? txInput.destinationAccountId : undefined,
      categoryId: txInput.categoryId || 'cat_others_exp',
      subcategoryId: txInput.subcategoryId,
      contactId: txInput.contactId,
      personName: txInput.personName,
      description: txInput.description.trim(),
      notes: txInput.notes || '',
      tags: txInput.tags || [],
      paymentMethod: txInput.paymentMethod || 'Cash',
      attachmentId: txInput.attachmentId,
      isSplit: Boolean(txInput.isSplit && txInput.splits && txInput.splits.length > 0),
      linkedTransactionId: txInput.linkedTransactionId,
      debtId: txInput.debtId,
      loanId: txInput.loanId,
      loanPrincipalPoisha: txInput.loanPrincipalPoisha,
      loanInterestPoisha: txInput.loanInterestPoisha,
      recurringId: txInput.recurringId,
      fingerprint,
      createdAt: existingIndex >= 0 ? snapshot.transactions[existingIndex].createdAt : now,
      updatedAt: now,
    };

    const nextTransactions =
      existingIndex >= 0
        ? snapshot.transactions.map((t, idx) => (idx === existingIndex ? newTx : t))
        : [newTx, ...snapshot.transactions];

    const filteredSplits = snapshot.transactionSplits.filter((s) => s.transactionId !== txId);
    const addedSplits: TransactionSplit[] =
      newTx.isSplit && txInput.splits
        ? txInput.splits.map((s, idx) => ({
            id: `splt_${txId}_${idx}`,
            transactionId: txId,
            categoryId: s.categoryId,
            subcategoryId: s.subcategoryId,
            amountPoisha: Math.round(s.amountPoisha),
            note: s.note || '',
          }))
        : [];

    const audit: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      action: existingIndex >= 0 ? 'UPDATE_TRANSACTION' : 'CREATE_TRANSACTION',
      entityType: 'Transaction',
      entityId: txId,
      summary: `${existingIndex >= 0 ? 'Updated' : 'Created'} ${newTx.type} transaction "${newTx.description}" (${poishaToMajorString(newTx.amountPoisha)})`,
      detailsJson: JSON.stringify({ type: newTx.type, amountPoisha: newTx.amountPoisha, accountId: newTx.accountId }),
      timestamp: now,
    };

    const recalculated = this.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      transactionSplits: [...filteredSplits, ...addedSplits],
      auditLogs: [audit, ...snapshot.auditLogs.slice(0, 199)],
    });

    return { ok: true, snapshot: recalculated, transaction: newTx };
  }

  /**
   * Deletes a transaction and reverses all financial impacts across accounts, debts, loans, and budgets.
   */
  public static deleteTransaction(snapshot: DatabaseSnapshot, transactionId: string): DatabaseSnapshot {
    const target = snapshot.transactions.find((t) => t.id === transactionId);
    if (!target) return snapshot;

    const now = new Date().toISOString();
    const nextTransactions = snapshot.transactions.filter((t) => t.id !== transactionId);
    const nextSplits = snapshot.transactionSplits.filter((s) => s.transactionId !== transactionId);
    const nextDebtPayments = snapshot.debtPayments.filter((dp) => dp.transactionId !== transactionId);
    const nextLoanPayments = (snapshot.loanPayments || []).filter(
      (lp) => lp.transactionId !== transactionId
    );
    // If the deleted transaction was the initial principal transaction of a Debt record, remove that Debt record cleanly
    const nextDebts = snapshot.debts.filter((d) => d.initialTransactionId !== transactionId);

    const audit: AuditLog = {
      id: `aud_del_${Date.now()}`,
      action: 'DELETE_TRANSACTION',
      entityType: 'Transaction',
      entityId: transactionId,
      summary: `Deleted ${target.type} transaction "${target.description}" and reversed its ledger impact`,
      detailsJson: JSON.stringify(target),
      timestamp: now,
    };

    return this.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      transactionSplits: nextSplits,
      debts: nextDebts,
      debtPayments: nextDebtPayments,
      loanPayments: nextLoanPayments,
      auditLogs: [audit, ...snapshot.auditLogs.slice(0, 199)],
    });
  }

  /**
   * Records a new Dena-Pawna (Receivable or Payable) entry along with its corresponding ledger transaction.
   */
  public static createDebtRecord(
    snapshot: DatabaseSnapshot,
    input: {
      direction: 'payable' | 'receivable';
      personName: string;
      phone: string;
      principalPoisha: number;
      transactionDate: string;
      dueDate: string;
      reminderDate?: string;
      accountId: string;
      purpose: string;
      description: string;
      notes?: string;
    }
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot; debt?: DebtRecord } {
    if (!input.personName.trim()) {
      return { ok: false, error: 'Person name is required.', snapshot };
    }
    if (!input.principalPoisha || input.principalPoisha <= 0) {
      return { ok: false, error: 'Debt principal amount must be greater than zero.', snapshot };
    }

    const now = new Date().toISOString();
    const debtId = `debt_${Date.now()}`;
    const txType: TransactionType = input.direction === 'receivable' ? 'loan_given' : 'loan_received';
    const txRes = this.upsertTransaction(snapshot, {
      type: txType,
      amountPoisha: Math.round(input.principalPoisha),
      currency: snapshot.settings.defaultCurrency,
      exchangeRateToBase: 1,
      date: input.transactionDate,
      time: '12:00',
      accountId: input.accountId,
      categoryId: input.direction === 'receivable' ? 'cat_others_exp' : 'cat_other_inc',
      personName: input.personName.trim(),
      description:
        input.description.trim() ||
        (input.direction === 'receivable'
          ? `Lent to ${input.personName.trim()}`
          : `Borrowed from ${input.personName.trim()}`),
      notes: input.notes || input.purpose,
      tags: [input.direction === 'receivable' ? 'pawna' : 'dena'],
      paymentMethod: 'Account Transfer',
      isSplit: false,
      debtId,
      allowDuplicate: true,
    });

    if (!txRes.ok || !txRes.transaction) {
      return { ok: false, error: txRes.error, snapshot };
    }

    const newDebt: DebtRecord = {
      id: debtId,
      direction: input.direction,
      personName: input.personName.trim(),
      phone: input.phone || '',
      principalPoisha: Math.round(input.principalPoisha),
      paidPoisha: 0,
      remainingPoisha: Math.round(input.principalPoisha),
      transactionDate: input.transactionDate,
      dueDate: input.dueDate,
      reminderDate: input.reminderDate,
      accountId: input.accountId,
      purpose: input.purpose || 'Personal',
      description: input.description || '',
      notes: input.notes || '',
      status: 'active',
      initialTransactionId: txRes.transaction.id,
      createdAt: now,
      updatedAt: now,
    };

    const finalSnapshot = this.recalculateSnapshotIntegrity({
      ...txRes.snapshot,
      debts: [newDebt, ...txRes.snapshot.debts],
    });

    return { ok: true, snapshot: finalSnapshot, debt: newDebt };
  }

  /**
   * Updates an existing Dena-Pawna record (and synchronizes its initial principal ledger transaction).
   */
  public static updateDebtRecord(
    snapshot: DatabaseSnapshot,
    debtId: string,
    patch: {
      personName: string;
      phone: string;
      principalPoisha: number;
      transactionDate: string;
      dueDate: string;
      reminderDate?: string;
      accountId: string;
      purpose: string;
      notes?: string;
    }
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot } {
    const existing = snapshot.debts.find((d) => d.id === debtId);
    if (!existing) return { ok: false, error: 'Debt record not found.', snapshot };
    if (!patch.personName.trim()) return { ok: false, error: 'Person name is required.', snapshot };
    const newPrincipal = Math.round(patch.principalPoisha || 0);
    if (newPrincipal < existing.paidPoisha || newPrincipal <= 0) {
      return {
        ok: false,
        error: `Principal (${poishaToMajorString(newPrincipal)}) cannot be less than already paid amount (${poishaToMajorString(existing.paidPoisha)}).`,
        snapshot,
      };
    }

    let nextTransactions = snapshot.transactions;
    if (existing.initialTransactionId) {
      nextTransactions = snapshot.transactions.map((tx) =>
        tx.id === existing.initialTransactionId
          ? {
              ...tx,
              amountPoisha: newPrincipal,
              accountId: patch.accountId,
              date: patch.transactionDate,
              personName: patch.personName.trim(),
              description:
                existing.direction === 'receivable'
                  ? `Lent to ${patch.personName.trim()} (${patch.purpose || 'Personal'})`
                  : `Borrowed from ${patch.personName.trim()} (${patch.purpose || 'Personal'})`,
              updatedAt: new Date().toISOString(),
            }
          : tx
      );
    }

    const nextDebts = snapshot.debts.map((d) =>
      d.id === debtId
        ? {
            ...d,
            personName: patch.personName.trim(),
            phone: patch.phone,
            principalPoisha: newPrincipal,
            transactionDate: patch.transactionDate,
            dueDate: patch.dueDate,
            reminderDate: patch.reminderDate,
            accountId: patch.accountId,
            purpose: patch.purpose,
            notes: patch.notes || '',
            updatedAt: new Date().toISOString(),
          }
        : d
    );

    return {
      ok: true,
      snapshot: this.recalculateSnapshotIntegrity({
        ...snapshot,
        transactions: nextTransactions,
        debts: nextDebts,
      }),
    };
  }

  /**
   * Deletes a Dena-Pawna record and reverses all associated ledger transactions.
   */
  public static deleteDebtRecord(snapshot: DatabaseSnapshot, debtId: string): DatabaseSnapshot {
    const target = snapshot.debts.find((d) => d.id === debtId);
    if (!target) return snapshot;

    const paymentTxIds = new Set(
      snapshot.debtPayments.filter((dp) => dp.debtId === debtId).map((dp) => dp.transactionId)
    );
    if (target.initialTransactionId) {
      paymentTxIds.add(target.initialTransactionId);
    }

    const nextTransactions = snapshot.transactions.filter(
      (tx) => tx.debtId !== debtId && !paymentTxIds.has(tx.id)
    );
    const nextDebtPayments = snapshot.debtPayments.filter((dp) => dp.debtId !== debtId);
    const nextDebts = snapshot.debts.filter((d) => d.id !== debtId);

    return this.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      debtPayments: nextDebtPayments,
      debts: nextDebts,
    });
  }

  /**
   * Records a partial or full repayment/collection against a Dena-Pawna record.
   */
  public static recordDebtPayment(
    snapshot: DatabaseSnapshot,
    input: {
      debtId: string;
      amountPoisha: number;
      paymentDate: string;
      accountId: string;
      note?: string;
    }
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot } {
    const debt = snapshot.debts.find((d) => d.id === input.debtId);
    if (!debt) {
      return { ok: false, error: 'Debt record not found.', snapshot };
    }
    const amt = Math.round(input.amountPoisha || 0);
    if (amt <= 0) {
      return { ok: false, error: 'Payment amount must be greater than zero.', snapshot };
    }
    if (amt > debt.remainingPoisha) {
      return {
        ok: false,
        error: `Payment amount (${poishaToMajorString(amt)}) cannot exceed remaining balance (${poishaToMajorString(debt.remainingPoisha)}).`,
        snapshot,
      };
    }

    const txType: TransactionType = debt.direction === 'receivable' ? 'debt_collection' : 'debt_repayment';
    const txRes = this.upsertTransaction(snapshot, {
      type: txType,
      amountPoisha: amt,
      currency: snapshot.settings.defaultCurrency,
      exchangeRateToBase: 1,
      date: input.paymentDate,
      time: '14:00',
      accountId: input.accountId,
      categoryId: debt.direction === 'receivable' ? 'cat_other_inc' : 'cat_others_exp',
      personName: debt.personName,
      description:
        debt.direction === 'receivable'
          ? `Debt Collection from ${debt.personName}`
          : `Debt Repayment to ${debt.personName}`,
      notes: input.note || '',
      tags: [debt.direction === 'receivable' ? 'collection' : 'repayment'],
      paymentMethod: 'Account Transfer',
      isSplit: false,
      debtId: debt.id,
      allowDuplicate: false,
    });

    if (!txRes.ok || !txRes.transaction) {
      return { ok: false, error: txRes.error, snapshot };
    }

    const payment: DebtPayment = {
      id: `dp_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      debtId: debt.id,
      transactionId: txRes.transaction.id,
      amountPoisha: amt,
      paymentDate: input.paymentDate,
      accountId: input.accountId,
      type: amt === debt.remainingPoisha ? 'settlement' : debt.direction === 'receivable' ? 'collection' : 'repayment',
      note: input.note || '',
      createdAt: new Date().toISOString(),
    };

    const finalSnapshot = this.recalculateSnapshotIntegrity({
      ...txRes.snapshot,
      debtPayments: [payment, ...txRes.snapshot.debtPayments],
    });

    return { ok: true, snapshot: finalSnapshot };
  }

  /**
   * Reverses/deletes a single partial debt payment or collection and restores the outstanding balance & account balance.
   */
  public static deleteDebtPayment(
    snapshot: DatabaseSnapshot,
    debtPaymentId: string
  ): DatabaseSnapshot {
    const dp = snapshot.debtPayments.find((p) => p.id === debtPaymentId);
    if (!dp) return snapshot;
    const nextTransactions = snapshot.transactions.filter((t) => t.id !== dp.transactionId);
    const nextDebtPayments = snapshot.debtPayments.filter((p) => p.id !== debtPaymentId);
    return this.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      debtPayments: nextDebtPayments,
    });
  }

  /**
   * Records a Loan / EMI installment payment, separating Principal and Interest components.
   */
  public static recordLoanInstallmentPayment(
    snapshot: DatabaseSnapshot,
    input: {
      loanId: string;
      installmentNumber?: number;
      accountId: string;
      paymentDate: string;
      note?: string;
    }
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot } {
    const loan = snapshot.loans.find((l) => l.id === input.loanId);
    if (!loan) return { ok: false, error: 'Loan record not found.', snapshot };

    const nextScheduleItem = input.installmentNumber
      ? loan.schedule.find((s) => s.installmentNumber === input.installmentNumber && !s.isPaid)
      : loan.schedule.find((s) => !s.isPaid);

    if (!nextScheduleItem) {
      return { ok: false, error: 'All installments for this loan are already paid.', snapshot };
    }

    const txRes = this.upsertTransaction(snapshot, {
      type: 'debt_repayment',
      amountPoisha: nextScheduleItem.installmentPoisha,
      currency: snapshot.settings.defaultCurrency,
      exchangeRateToBase: 1,
      date: input.paymentDate,
      time: '11:30',
      accountId: input.accountId,
      categoryId: 'cat_others_exp',
      personName: loan.lender,
      description: `${loan.name} - EMI #${nextScheduleItem.installmentNumber} (Principal: ${poishaToMajorString(nextScheduleItem.principalPoisha)}, Interest: ${poishaToMajorString(nextScheduleItem.interestPoisha)})`,
      notes: input.note || `Installment #${nextScheduleItem.installmentNumber}`,
      tags: ['emi', 'loan'],
      paymentMethod: 'Bank Transfer',
      isSplit: false,
      loanId: loan.id,
      loanPrincipalPoisha: nextScheduleItem.principalPoisha,
      loanInterestPoisha: nextScheduleItem.interestPoisha,
      allowDuplicate: true,
    });

    if (!txRes.ok || !txRes.transaction) {
      return { ok: false, error: txRes.error, snapshot };
    }

    const loanPayment: LoanPayment = {
      id: `lp_${Date.now()}_${nextScheduleItem.installmentNumber}`,
      loanId: loan.id,
      transactionId: txRes.transaction.id,
      installmentNumber: nextScheduleItem.installmentNumber,
      totalAmountPoisha: nextScheduleItem.installmentPoisha,
      principalComponentPoisha: nextScheduleItem.principalPoisha,
      interestComponentPoisha: nextScheduleItem.interestPoisha,
      paymentDate: input.paymentDate,
      accountId: input.accountId,
      note: input.note || '',
      createdAt: new Date().toISOString(),
    };

    return {
      ok: true,
      snapshot: this.recalculateSnapshotIntegrity({
        ...txRes.snapshot,
        loanPayments: [loanPayment, ...(txRes.snapshot.loanPayments || [])],
      }),
    };
  }

  /**
   * Reverses a paid Loan EMI installment, restoring the account balance and loan remaining principal.
   */
  public static reverseLoanInstallmentPayment(
    snapshot: DatabaseSnapshot,
    loanId: string,
    installmentNumber: number
  ): DatabaseSnapshot {
    const lp = (snapshot.loanPayments || []).find(
      (p) => p.loanId === loanId && p.installmentNumber === installmentNumber
    );
    if (!lp) return snapshot;
    const nextTransactions = snapshot.transactions.filter((t) => t.id !== lp.transactionId);
    const nextLoanPayments = (snapshot.loanPayments || []).filter((p) => p.id !== lp.id);
    return this.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      loanPayments: nextLoanPayments,
    });
  }

  /**
   * Merges sourceCategoryId into targetCategoryId without losing any historical transactions,
   * splits, subcategories, budgets (summing allocations if both exist in a budget), or recurring rules.
   */
  public static mergeCategories(
    snapshot: DatabaseSnapshot,
    sourceCategoryId: string,
    targetCategoryId: string
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot } {
    if (sourceCategoryId === targetCategoryId) {
      return { ok: false, error: 'Source and target categories must be different.', snapshot };
    }
    const sourceCat = snapshot.categories.find((c) => c.id === sourceCategoryId);
    const targetCat = snapshot.categories.find((c) => c.id === targetCategoryId);
    if (!sourceCat || !targetCat) {
      return { ok: false, error: 'Category not found.', snapshot };
    }
    if (sourceCat.type !== targetCat.type) {
      return { ok: false, error: 'Cannot merge an income category with an expense category.', snapshot };
    }

    const updatedTransactions = snapshot.transactions.map((tx) =>
      tx.categoryId === sourceCategoryId ? { ...tx, categoryId: targetCategoryId } : tx
    );
    const updatedSplits = snapshot.transactionSplits.map((sp) =>
      sp.categoryId === sourceCategoryId ? { ...sp, categoryId: targetCategoryId } : sp
    );
    const updatedSubcategories = snapshot.subcategories.map((sub) =>
      sub.categoryId === sourceCategoryId ? { ...sub, categoryId: targetCategoryId } : sub
    );
    const updatedRecurring = snapshot.recurringTransactions.map((rec) =>
      rec.categoryId === sourceCategoryId ? { ...rec, categoryId: targetCategoryId } : rec
    );

    // Merge BudgetCategories allocations without creating duplicate category rows per budget
    const mergedBCMap = new Map<string, BudgetCategory>();
    for (const bc of snapshot.budgetCategories) {
      const effectiveCatId = bc.categoryId === sourceCategoryId ? targetCategoryId : bc.categoryId;
      const key = `${bc.budgetId}|${effectiveCatId}|${bc.subcategoryId || ''}`;
      const existing = mergedBCMap.get(key);
      if (existing) {
        mergedBCMap.set(key, {
          ...existing,
          allocatedPoisha: existing.allocatedPoisha + bc.allocatedPoisha,
        });
      } else {
        mergedBCMap.set(key, {
          ...bc,
          categoryId: effectiveCatId,
        });
      }
    }

    const updatedCategories = snapshot.categories.map((c) =>
      c.id === sourceCategoryId ? { ...c, isArchived: true, isEnabled: false } : c
    );

    return {
      ok: true,
      snapshot: this.recalculateSnapshotIntegrity({
        ...snapshot,
        transactions: updatedTransactions,
        transactionSplits: updatedSplits,
        subcategories: updatedSubcategories,
        budgetCategories: Array.from(mergedBCMap.values()),
        recurringTransactions: updatedRecurring,
        categories: updatedCategories,
      }),
    };
  }

  /**
   * Executes due recurring transactions idempotently (never double-posts on app reopen).
   */
  public static executeRecurringRule(
    snapshot: DatabaseSnapshot,
    ruleId: string,
    executionDate?: string
  ): { ok: boolean; error?: string; snapshot: DatabaseSnapshot } {
    const rule = snapshot.recurringTransactions.find((r) => r.id === ruleId);
    if (!rule) return { ok: false, error: 'Recurring rule not found.', snapshot };
    if (rule.status !== 'active') return { ok: false, error: 'Recurring rule is not active.', snapshot };

    const execDate = executionDate || rule.nextExecutionDate;
    if (rule.lastExecutedDate === execDate) {
      return { ok: false, error: `Recurring rule was already posted for ${execDate}.`, snapshot };
    }

    const txRes = this.upsertTransaction(snapshot, {
      type: rule.type,
      amountPoisha: rule.amountPoisha,
      currency: snapshot.settings.defaultCurrency,
      exchangeRateToBase: 1,
      date: execDate,
      time: '09:00',
      accountId: rule.accountId,
      destinationAccountId: rule.destinationAccountId,
      categoryId: rule.categoryId,
      subcategoryId: rule.subcategoryId,
      description: `${rule.title} (Recurring)`,
      notes: rule.description || 'Auto-generated from recurring schedule',
      tags: ['recurring', rule.frequency],
      paymentMethod: 'Scheduled',
      isSplit: false,
      recurringId: rule.id,
      allowDuplicate: false,
    });

    if (!txRes.ok) return txRes;

    const nextDateObj = new Date(execDate + 'T00:00:00');
    switch (rule.frequency) {
      case 'daily':
        nextDateObj.setDate(nextDateObj.getDate() + 1);
        break;
      case 'weekly':
        nextDateObj.setDate(nextDateObj.getDate() + 7);
        break;
      case 'monthly':
        nextDateObj.setMonth(nextDateObj.getMonth() + 1);
        break;
      case 'quarterly':
        nextDateObj.setMonth(nextDateObj.getMonth() + 3);
        break;
      case 'yearly':
        nextDateObj.setFullYear(nextDateObj.getFullYear() + 1);
        break;
      case 'custom':
        nextDateObj.setDate(nextDateObj.getDate() + Math.max(1, rule.customIntervalDays || 30));
        break;
    }
    const nextExecutionDate = nextDateObj.toISOString().slice(0, 10);

    const updatedRecurring = txRes.snapshot.recurringTransactions.map((r) =>
      r.id === rule.id
        ? {
            ...r,
            lastExecutedDate: execDate,
            nextExecutionDate,
            status: r.endDate && nextExecutionDate > r.endDate ? ('cancelled' as const) : r.status,
            updatedAt: new Date().toISOString(),
          }
        : r
    );

    return {
      ok: true,
      snapshot: {
        ...txRes.snapshot,
        recurringTransactions: updatedRecurring,
      },
    };
  }

  /**
   * Computes category-wise net expense map for a given date range (and optional account filter).
   * Multi-currency split transactions are converted accurately to baseCurrency.
   */
  public static computeCategoryNetExpenses(
    snapshot: DatabaseSnapshot,
    dateFrom: string,
    dateTo: string,
    accountId?: string
  ): Record<string, number> {
    const rawSpent: Record<string, number> = {};
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;

    for (const tx of snapshot.transactions) {
      if (tx.date < dateFrom || tx.date > dateTo) continue;
      if (accountId && tx.accountId !== accountId) continue;

      const baseAmount = MoneyMath.convertToBase(
        tx.amountPoisha,
        tx.currency,
        baseCurrency,
        rates
      );

      if (tx.type === 'expense') {
        if (tx.isSplit) {
          const splits = snapshot.transactionSplits.filter((s) => s.transactionId === tx.id);
          if (splits.length > 0) {
            for (const sp of splits) {
              const splitBase = MoneyMath.convertToBase(
                sp.amountPoisha,
                tx.currency,
                baseCurrency,
                rates
              );
              rawSpent[sp.categoryId] = MoneyMath.add(rawSpent[sp.categoryId] || 0, splitBase);
            }
            continue;
          }
        }
        rawSpent[tx.categoryId] = MoneyMath.add(rawSpent[tx.categoryId] || 0, baseAmount);
      } else if (tx.type === 'refund') {
        rawSpent[tx.categoryId] = MoneyMath.subtract(rawSpent[tx.categoryId] || 0, baseAmount);
      }
    }

    const netSpent: Record<string, number> = {};
    for (const [catId, val] of Object.entries(rawSpent)) {
      netSpent[catId] = Math.max(0, val);
    }
    return netSpent;
  }

  /**
   * Computes subcategory-wise net expense map for a given date range (and optional account filter).
   */
  public static computeSubcategoryNetExpenses(
    snapshot: DatabaseSnapshot,
    dateFrom: string,
    dateTo: string,
    accountId?: string
  ): Record<string, number> {
    const rawSpent: Record<string, number> = {};
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;

    for (const tx of snapshot.transactions) {
      if (tx.date < dateFrom || tx.date > dateTo) continue;
      if (accountId && tx.accountId !== accountId) continue;

      const baseAmount = MoneyMath.convertToBase(
        tx.amountPoisha,
        tx.currency,
        baseCurrency,
        rates
      );

      if (tx.type === 'expense') {
        if (tx.isSplit) {
          const splits = snapshot.transactionSplits.filter((s) => s.transactionId === tx.id);
          if (splits.length > 0) {
            for (const sp of splits) {
              if (sp.subcategoryId) {
                const splitBase = MoneyMath.convertToBase(
                  sp.amountPoisha,
                  tx.currency,
                  baseCurrency,
                  rates
                );
                rawSpent[sp.subcategoryId] = MoneyMath.add(
                  rawSpent[sp.subcategoryId] || 0,
                  splitBase
                );
              }
            }
            continue;
          }
        }
        if (tx.subcategoryId) {
          rawSpent[tx.subcategoryId] = MoneyMath.add(rawSpent[tx.subcategoryId] || 0, baseAmount);
        }
      } else if (tx.type === 'refund' && tx.subcategoryId) {
        rawSpent[tx.subcategoryId] = MoneyMath.subtract(rawSpent[tx.subcategoryId] || 0, baseAmount);
      }
    }

    const netSpent: Record<string, number> = {};
    for (const [subId, val] of Object.entries(rawSpent)) {
      netSpent[subId] = Math.max(0, val);
    }
    return netSpent;
  }

  /**
   * Evaluates a Budget (Monthly, Weekly, Daily, Yearly, or Custom) with real-time progress,
   * Category Breakdown, Subcategory Breakdown, configurable warning thresholds (50%, 75%, 90%, 100%),
   * active Budget Alerts, and previous period comparison.
   */
  public static evaluateBudget(snapshot: DatabaseSnapshot, budgetId: string): BudgetEvaluation | null {
    const budget = snapshot.budgets.find((b) => b.id === budgetId);
    if (!budget) return null;

    const currentCategorySpent = this.computeCategoryNetExpenses(
      snapshot,
      budget.startDate,
      budget.endDate,
      budget.accountId
    );
    const currentSubcategorySpent = this.computeSubcategoryNetExpenses(
      snapshot,
      budget.startDate,
      budget.endDate,
      budget.accountId
    );

    const startObj = new Date(budget.startDate + 'T00:00:00');
    const endObj = new Date(budget.endDate + 'T00:00:00');
    const prevStart = new Date(startObj);
    prevStart.setMonth(prevStart.getMonth() - 1);
    const prevEnd = new Date(endObj);
    prevEnd.setMonth(prevEnd.getMonth() - 1);

    const prevCategorySpent = this.computeCategoryNetExpenses(
      snapshot,
      prevStart.toISOString().slice(0, 10),
      prevEnd.toISOString().slice(0, 10),
      budget.accountId
    );
    const prevSubcategorySpent = this.computeSubcategoryNetExpenses(
      snapshot,
      prevStart.toISOString().slice(0, 10),
      prevEnd.toISOString().slice(0, 10),
      budget.accountId
    );

    const allAllocations = snapshot.budgetCategories.filter((bc) => bc.budgetId === budget.id);
    const categoryAllocations = allAllocations.filter((bc) => !bc.subcategoryId);
    const subcategoryAllocations = allAllocations.filter((bc) => Boolean(bc.subcategoryId));

    const thresholds = budget.warningThresholds?.length ? budget.warningThresholds : [50, 75, 90, 100];

    const getStatus = (pct: number): BudgetEvaluation['status'] => {
      if (pct >= (thresholds[3] || 100)) return 'exceeded';
      if (pct >= (thresholds[2] || 90)) return 'warning_90';
      if (pct >= (thresholds[1] || 75)) return 'warning_75';
      if (pct >= (thresholds[0] || 50)) return 'warning_50';
      return 'safe';
    };

    const alerts: BudgetAlertItem[] = [];

    const categoryBreakdown = categoryAllocations.map((alloc) => {
      const cat = snapshot.categories.find((c) => c.id === alloc.categoryId);
      const spentPoisha = currentCategorySpent[alloc.categoryId] || 0;
      const previousSpentPoisha = prevCategorySpent[alloc.categoryId] || 0;
      const remainingPoisha = MoneyMath.subtract(alloc.allocatedPoisha, spentPoisha);
      const percentUsed = MoneyMath.percentage(spentPoisha, alloc.allocatedPoisha);
      const status = getStatus(percentUsed);
      const categoryName = cat ? cat.name : alloc.categoryId;

      if (status !== 'safe') {
        alerts.push({
          id: `alert_cat_${alloc.id}`,
          scope: 'category',
          name: categoryName,
          allocatedPoisha: alloc.allocatedPoisha,
          spentPoisha,
          percentUsed,
          status,
        });
      }

      return {
        allocationId: alloc.id,
        categoryId: alloc.categoryId,
        categoryName,
        categoryColor: cat ? cat.color : '#64748b',
        allocatedPoisha: alloc.allocatedPoisha,
        spentPoisha,
        previousSpentPoisha,
        remainingPoisha,
        percentUsed,
        status,
      };
    });

    const subcategoryBreakdown: SubcategoryBudgetRow[] = subcategoryAllocations.map((alloc) => {
      const subId = alloc.subcategoryId || '';
      const sub = snapshot.subcategories.find((s) => s.id === subId);
      const cat = snapshot.categories.find((c) => c.id === (sub?.categoryId || alloc.categoryId));
      const spentPoisha = currentSubcategorySpent[subId] || 0;
      const previousSpentPoisha = prevSubcategorySpent[subId] || 0;
      const remainingPoisha = MoneyMath.subtract(alloc.allocatedPoisha, spentPoisha);
      const percentUsed = MoneyMath.percentage(spentPoisha, alloc.allocatedPoisha);
      const status = getStatus(percentUsed);
      const subcategoryName = sub ? sub.name : subId;
      const categoryName = cat ? cat.name : alloc.categoryId;

      if (status !== 'safe') {
        alerts.push({
          id: `alert_sub_${alloc.id}`,
          scope: 'subcategory',
          name: `${categoryName} › ${subcategoryName}`,
          allocatedPoisha: alloc.allocatedPoisha,
          spentPoisha,
          percentUsed,
          status,
        });
      }

      return {
        allocationId: alloc.id,
        subcategoryId: subId,
        subcategoryName,
        categoryId: alloc.categoryId,
        categoryName,
        categoryColor: cat ? cat.color : '#14b8a6',
        allocatedPoisha: alloc.allocatedPoisha,
        spentPoisha,
        previousSpentPoisha,
        remainingPoisha,
        percentUsed,
        status,
      };
    });

    const totalSpentPoisha = Object.values(currentCategorySpent).reduce((s, v) => s + v, 0);
    const previousMonthSpentPoisha = Object.values(prevCategorySpent).reduce((s, v) => s + v, 0);
    const totalAllocatedPoisha =
      budget.totalLimitPoisha || categoryAllocations.reduce((s, a) => s + a.allocatedPoisha, 0);
    const remainingPoisha = MoneyMath.subtract(totalAllocatedPoisha, totalSpentPoisha);
    const percentUsed = MoneyMath.percentage(totalSpentPoisha, totalAllocatedPoisha);
    const overallStatus = getStatus(percentUsed);

    if (overallStatus !== 'safe') {
      alerts.unshift({
        id: `alert_overall_${budget.id}`,
        scope: 'overall',
        name: budget.name,
        allocatedPoisha: totalAllocatedPoisha,
        spentPoisha: totalSpentPoisha,
        percentUsed,
        status: overallStatus,
      });
    }

    return {
      budget,
      totalAllocatedPoisha,
      totalSpentPoisha,
      remainingPoisha,
      percentUsed,
      previousMonthSpentPoisha,
      status: overallStatus,
      categoryBreakdown,
      subcategoryBreakdown,
      alerts,
    };
  }

  /**
   * Computes all 8 Dashboard KPIs and Net Worth for any selected date range.
   */
  public static computeDashboardMetrics(
    snapshot: DatabaseSnapshot,
    dateFrom: string,
    dateTo: string
  ): DashboardMetrics {
    const rates = snapshot.settings.exchangeRates;
    const baseCurrency = snapshot.settings.defaultCurrency;

    const totalBalancePoisha = snapshot.accounts
      .filter((a) => a.status === 'active')
      .reduce(
        (sum, acc) =>
          sum + MoneyMath.convertToBase(acc.currentBalancePoisha, acc.currency, baseCurrency, rates),
        0
      );

    let totalIncomePoisha = 0;
    let rawExpensePoisha = 0;

    for (const tx of snapshot.transactions) {
      if (tx.date < dateFrom || tx.date > dateTo) continue;
      const amt = MoneyMath.convertToBase(tx.amountPoisha, tx.currency, baseCurrency, rates);
      if (tx.type === 'income') {
        totalIncomePoisha = MoneyMath.add(totalIncomePoisha, amt);
      } else if (tx.type === 'expense') {
        rawExpensePoisha = MoneyMath.add(rawExpensePoisha, amt);
      } else if (tx.type === 'refund') {
        rawExpensePoisha = MoneyMath.subtract(rawExpensePoisha, amt);
      }
    }

    const totalExpensePoisha = Math.max(0, rawExpensePoisha);
    const netCashFlowPoisha = MoneyMath.subtract(totalIncomePoisha, totalExpensePoisha);

    const totalReceivablePoisha = snapshot.debts
      .filter((d) => d.direction === 'receivable' && d.status !== 'settled')
      .reduce((sum, d) => sum + d.remainingPoisha, 0);

    const totalPayablePoisha = snapshot.debts
      .filter((d) => d.direction === 'payable' && d.status !== 'settled')
      .reduce((sum, d) => sum + d.remainingPoisha, 0);

    const totalSavingsPoisha = snapshot.savingsGoals.reduce(
      (sum, g) => sum + g.savedAmountPoisha,
      0
    );

    const remainingLoanLiabilityPoisha = snapshot.loans
      .filter((l) => l.status === 'active')
      .reduce((sum, l) => sum + l.remainingPrincipalPoisha, 0);

    const activeBudget = snapshot.budgets[0];
    const evalBudget = activeBudget ? this.evaluateBudget(snapshot, activeBudget.id) : null;

    const netWorthPoisha =
      totalBalancePoisha + totalReceivablePoisha - totalPayablePoisha - remainingLoanLiabilityPoisha;

    return {
      totalBalancePoisha,
      totalIncomePoisha,
      totalExpensePoisha,
      netCashFlowPoisha,
      totalReceivablePoisha,
      totalPayablePoisha,
      totalSavingsPoisha,
      monthlyBudgetAllocatedPoisha: evalBudget ? evalBudget.totalAllocatedPoisha : 0,
      monthlyBudgetSpentPoisha: evalBudget ? evalBudget.totalSpentPoisha : 0,
      monthlyBudgetPercent: evalBudget ? evalBudget.percentUsed : 0,
      netWorthPoisha,
      remainingLoanLiabilityPoisha,
    };
  }

  /**
   * Validates a JSON Backup file before restoration and computes an import preview & duplicate count.
   */
  public static validateBackupJson(rawJson: string, currentSnapshot: DatabaseSnapshot): {
    valid: boolean;
    error?: string;
    parsed?: DatabaseSnapshot;
    preview?: {
      schemaVersion: number;
      exportedAt: string;
      accountsCount: number;
      transactionsCount: number;
      duplicateTransactionsCount: number;
      categoriesCount: number;
      budgetsCount: number;
      debtsCount: number;
      loansCount: number;
      savingsGoalsCount: number;
      recurringCount: number;
    };
  } {
    try {
      const data = JSON.parse(rawJson) as DatabaseSnapshot;
      if (!data || typeof data !== 'object') {
        return { valid: false, error: 'Backup payload is not a valid JSON object.' };
      }
      if (!Array.isArray(data.accounts) || !Array.isArray(data.transactions) || !Array.isArray(data.categories)) {
        return {
          valid: false,
          error: 'Backup file is missing required financial arrays (accounts, transactions, or categories).',
        };
      }
      const existingFingerprints = new Set(currentSnapshot.transactions.map((t) => t.fingerprint));
      const existingIds = new Set(currentSnapshot.transactions.map((t) => t.id));
      const duplicateTransactionsCount = data.transactions.filter(
        (t) => existingIds.has(t.id) || (t.fingerprint && existingFingerprints.has(t.fingerprint))
      ).length;

      return {
        valid: true,
        parsed: data,
        preview: {
          schemaVersion: data.schemaVersion || 1,
          exportedAt: data.exportedAt || 'Unknown',
          accountsCount: data.accounts.length,
          transactionsCount: data.transactions.length,
          duplicateTransactionsCount,
          categoriesCount: data.categories.length,
          budgetsCount: (data.budgets || []).length,
          debtsCount: (data.debts || []).length,
          loansCount: (data.loans || []).length,
          savingsGoalsCount: (data.savingsGoals || []).length,
          recurringCount: (data.recurringTransactions || []).length,
        },
      };
    } catch (e: any) {
      return { valid: false, error: `Invalid JSON format: ${e?.message || 'Parse error'}` };
    }
  }

  /**
   * Restores a validated backup using either 'replace' or 'merge' mode with full v1/v2 backward compatibility.
   */
  public static restoreBackupSnapshot(
    currentSnapshot: DatabaseSnapshot,
    incoming: DatabaseSnapshot,
    mode: 'replace' | 'merge'
  ): DatabaseSnapshot {
    if (mode === 'replace') {
      return this.recalculateSnapshotIntegrity({
        ...currentSnapshot,
        ...incoming,
        settings: { ...currentSnapshot.settings, ...(incoming.settings || {}) },
        transactionSplits: incoming.transactionSplits || [],
        subcategories: incoming.subcategories || [],
        budgets: incoming.budgets || [],
        budgetCategories: incoming.budgetCategories || [],
        contacts: incoming.contacts || [],
        debts: incoming.debts || [],
        debtPayments: incoming.debtPayments || [],
        loans: incoming.loans || [],
        loanPayments: incoming.loanPayments || [],
        savingsGoals: incoming.savingsGoals || [],
        savingsContributions: incoming.savingsContributions || [],
        recurringTransactions: incoming.recurringTransactions || [],
        attachments: incoming.attachments || [],
        notifications: incoming.notifications || [],
        schemaVersion: CURRENT_SCHEMA_VERSION,
        auditLogs: [
          {
            id: `aud_restore_${Date.now()}`,
            action: 'RESTORE_REPLACE',
            entityType: 'Database',
            entityId: 'FullBackup',
            summary: `Restored full backup in REPLACE mode (${incoming.transactions.length} transactions)`,
            detailsJson: JSON.stringify({ mode: 'replace', exportedAt: incoming.exportedAt }),
            timestamp: new Date().toISOString(),
          },
          ...(incoming.auditLogs || []).slice(0, 100),
        ],
      });
    }

    const mergeById = <T extends { id: string }>(existing: T[], added: T[] = []): T[] => {
      const seen = new Set(existing.map((i) => i.id));
      const result = [...existing];
      for (const item of added) {
        if (!seen.has(item.id)) {
          seen.add(item.id);
          result.push(item);
        }
      }
      return result;
    };

    const seenTxIds = new Set(currentSnapshot.transactions.map((t) => t.id));
    const seenFingerprints = new Set(currentSnapshot.transactions.map((t) => t.fingerprint));
    const mergedTransactions = [...currentSnapshot.transactions];
    for (const tx of incoming.transactions || []) {
      if (!seenTxIds.has(tx.id) && (!tx.fingerprint || !seenFingerprints.has(tx.fingerprint))) {
        seenTxIds.add(tx.id);
        if (tx.fingerprint) seenFingerprints.add(tx.fingerprint);
        mergedTransactions.push(tx);
      }
    }

    return this.recalculateSnapshotIntegrity({
      ...currentSnapshot,
      accounts: mergeById(currentSnapshot.accounts, incoming.accounts),
      transactions: mergedTransactions,
      transactionSplits: mergeById(currentSnapshot.transactionSplits, incoming.transactionSplits),
      categories: mergeById(currentSnapshot.categories, incoming.categories),
      subcategories: mergeById(currentSnapshot.subcategories, incoming.subcategories),
      budgets: mergeById(currentSnapshot.budgets, incoming.budgets),
      budgetCategories: mergeById(currentSnapshot.budgetCategories, incoming.budgetCategories),
      contacts: mergeById(currentSnapshot.contacts, incoming.contacts),
      debts: mergeById(currentSnapshot.debts, incoming.debts),
      debtPayments: mergeById(currentSnapshot.debtPayments, incoming.debtPayments),
      loans: mergeById(currentSnapshot.loans, incoming.loans),
      loanPayments: mergeById(currentSnapshot.loanPayments, incoming.loanPayments),
      savingsGoals: mergeById(currentSnapshot.savingsGoals, incoming.savingsGoals),
      savingsContributions: mergeById(currentSnapshot.savingsContributions, incoming.savingsContributions),
      recurringTransactions: mergeById(currentSnapshot.recurringTransactions, incoming.recurringTransactions),
      auditLogs: [
        {
          id: `aud_merge_${Date.now()}`,
          action: 'RESTORE_MERGE',
          entityType: 'Database',
          entityId: 'MergeBackup',
          summary: `Merged backup records without overwriting existing data`,
          detailsJson: JSON.stringify({ mode: 'merge' }),
          timestamp: new Date().toISOString(),
        },
        ...currentSnapshot.auditLogs.slice(0, 100),
      ],
    });
  }

  /**
   * RFC-4180 Quote-Aware CSV Line Parser
   */
  public static parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    result.push(current.trim());
    return result;
  }

  /**
   * Imports transactions from either a 4-column CSV (`Date,Type,Amount,Description`)
   * or the full 15-column exported CSV (`ID,Date,Time,Type,Amount_BDT,Currency,Account,...`),
   * handling quoted commas and blocking duplicate entries.
   */
  public static importTransactionsFromCSV(
    snapshot: DatabaseSnapshot,
    csvText: string
  ): { importedCount: number; skippedDuplicates: number; snapshot: DatabaseSnapshot } {
    const lines = csvText
      .trim()
      .split(/\r?\n/)
      .filter((l) => l.trim().length > 0);
    if (lines.length < 2) {
      return { importedCount: 0, skippedDuplicates: 0, snapshot };
    }

    const headerCols = this.parseCSVLine(lines[0]).map((h) => h.toLowerCase());
    const isFullFormat = headerCols.includes('amount_bdt') || headerCols.length >= 10;

    let current = snapshot;
    let importedCount = 0;
    let skippedDuplicates = 0;

    for (let i = 1; i < lines.length; i++) {
      const cols = this.parseCSVLine(lines[i]);
      if (cols.length < 4) continue;

      let dateStr = '2026-11-06';
      let timeStr = '12:00';
      let typeStr: TransactionType = 'expense';
      let amountPoisha = 0;
      let accountId = current.settings.defaultAccountId || 'acc_cash';
      let categoryId = 'cat_others_exp';
      let description = 'CSV Imported Entry';
      let notes = 'Imported via CSV';

      if (isFullFormat) {
        dateStr = cols[1] || '2026-11-06';
        timeStr = cols[2] || '12:00';
        typeStr = (cols[3] as TransactionType) || 'expense';
        amountPoisha = toPoisha(cols[4] || '0');
        const accName = (cols[6] || '').toLowerCase();
        const matchedAcc = current.accounts.find((a) => a.name.toLowerCase() === accName);
        if (matchedAcc) accountId = matchedAcc.id;
        const catName = (cols[8] || '').toLowerCase();
        const matchedCat = current.categories.find((c) => c.name.toLowerCase() === catName);
        if (matchedCat) categoryId = matchedCat.id;
        description = cols[11] || 'CSV Imported Entry';
        notes = cols[12] || '';
      } else {
        dateStr = cols[0] || '2026-11-06';
        typeStr = (cols[1] as TransactionType) || 'expense';
        amountPoisha = toPoisha(cols[2] || '0');
        description = cols[3] || 'CSV Imported Entry';
        categoryId = typeStr === 'income' ? 'cat_salary' : 'cat_others_exp';
      }

      if (amountPoisha > 0) {
        const res = this.upsertTransaction(current, {
          type: typeStr,
          amountPoisha,
          currency: current.settings.defaultCurrency,
          exchangeRateToBase: 1,
          date: dateStr,
          time: timeStr,
          accountId,
          categoryId,
          description,
          notes,
          tags: ['csv-import'],
          paymentMethod: 'Cash',
          isSplit: false,
          allowDuplicate: false,
        });
        if (res.ok) {
          current = res.snapshot;
          importedCount++;
        } else {
          skippedDuplicates++;
        }
      }
    }

    return { importedCount, skippedDuplicates, snapshot: current };
  }

  /**
   * Exports transactions to RFC-4180 CSV string (Excel compatible).
   */
  public static exportTransactionsToCSV(snapshot: DatabaseSnapshot): string {
    const headers = [
      'ID',
      'Date',
      'Time',
      'Type',
      'Amount_BDT',
      'Currency',
      'Account',
      'Destination_Account',
      'Category',
      'Subcategory',
      'Person',
      'Description',
      'Notes',
      'Tags',
      'Payment_Method',
    ];
    const escapeCsv = (val: string) => `"${String(val ?? '').replace(/"/g, '""')}"`;

    const rows = snapshot.transactions.map((tx) => {
      const acc = snapshot.accounts.find((a) => a.id === tx.accountId)?.name || tx.accountId;
      const destAcc = tx.destinationAccountId
        ? snapshot.accounts.find((a) => a.id === tx.destinationAccountId)?.name || tx.destinationAccountId
        : '';
      const cat = snapshot.categories.find((c) => c.id === tx.categoryId)?.name || tx.categoryId;
      const sub = tx.subcategoryId
        ? snapshot.subcategories.find((s) => s.id === tx.subcategoryId)?.name || tx.subcategoryId
        : '';
      return [
        tx.id,
        tx.date,
        tx.time,
        tx.type,
        poishaToMajorString(tx.amountPoisha, 2),
        tx.currency,
        acc,
        destAcc,
        cat,
        sub,
        tx.personName || '',
        tx.description,
        tx.notes,
        (tx.tags || []).join(';'),
        tx.paymentMethod,
      ]
        .map(escapeCsv)
        .join(',');
    });

    return [headers.join(','), ...rows].join('\n');
  }
}
