// ============================================================================
// PHASE 6: COMPLETE DEBT & RECEIVABLE MANAGEMENT MODULE (DENA-PAWNA)
// Separate sections for:
// A. Money Others Owe Me (Receivables / পাওনা)
// B. Money I Owe (Payables / দেনা)
// C. Person-wise Balances
// D. Complete Repayment & Collection History + Due Date Reminders
// Supports full CRUD (Add, Edit, Delete with ledger reversal), Partial
// Collections/Repayments, Full Settlement, Payment Reversal, and Statements.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  Edit3,
  FileText,
  HandCoins,
  History,
  Phone,
  Plus,
  RotateCcw,
  Search,
  Trash2,
  UserCheck,
} from 'lucide-react';
import { DatabaseSnapshot, DebtDirection, DebtRecord } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from '../utils/money';

export interface DebtsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

export const DebtsModule: React.FC<DebtsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [activeTab, setActiveTab] = useState<'receivable' | 'payable' | 'contacts' | 'history'>('receivable');
  const [searchContact, setSearchContact] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingDebt, setEditingDebt] = useState<DebtRecord | null>(null);
  const [paymentModalDebt, setPaymentModalDebt] = useState<DebtRecord | null>(null);
  const [statementDebt, setStatementDebt] = useState<DebtRecord | null>(null);

  // Add / Edit Debt Form State
  const [direction, setDirection] = useState<DebtDirection>('receivable');
  const [personName, setPersonName] = useState('');
  const [phone, setPhone] = useState('');
  const [principalStr, setPrincipalStr] = useState('');
  const [transactionDate, setTransactionDate] = useState('2026-11-06');
  const [dueDate, setDueDate] = useState('2026-11-30');
  const [reminderDate, setReminderDate] = useState('2026-11-28');
  const [accountId, setAccountId] = useState(snapshot.settings.defaultAccountId || 'acc_bank');
  const [purpose, setPurpose] = useState('');
  const [notes, setNotes] = useState('');

  // Partial / Full Payment Form State
  const [payAmountStr, setPayAmountStr] = useState('');
  const [payDate, setPayDate] = useState('2026-11-06');
  const [payAccountId, setPayAccountId] = useState('acc_bkash');
  const [payNote, setPayNote] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const totalReceivable = useMemo(
    () =>
      snapshot.debts
        .filter((d) => d.direction === 'receivable')
        .reduce((s, d) => s + d.remainingPoisha, 0),
    [snapshot.debts]
  );

  const totalPayable = useMemo(
    () =>
      snapshot.debts
        .filter((d) => d.direction === 'payable')
        .reduce((s, d) => s + d.remainingPoisha, 0),
    [snapshot.debts]
  );

  // Due Date Reminders & Overdue Records
  const dueOrReminderDebts = useMemo(() => {
    const todayStr = '2026-11-06';
    return snapshot.debts.filter(
      (d) =>
        d.remainingPoisha > 0 &&
        (d.status === 'overdue' ||
          d.dueDate <= '2026-11-20' ||
          (d.reminderDate && d.reminderDate <= todayStr))
    );
  }, [snapshot.debts]);

  const filteredDebts = useMemo(() => {
    const q = searchContact.trim().toLowerCase();
    return snapshot.debts
      .filter((d) =>
        activeTab === 'contacts' || activeTab === 'history' ? true : d.direction === activeTab
      )
      .filter(
        (d) =>
          !q ||
          d.personName.toLowerCase().includes(q) ||
          (d.phone || '').toLowerCase().includes(q) ||
          (d.purpose || '').toLowerCase().includes(q)
      );
  }, [snapshot.debts, activeTab, searchContact]);

  // Person-wise aggregated summary
  const personBalances = useMemo(() => {
    const map: Record<
      string,
      { name: string; phone: string; receivablePoisha: number; payablePoisha: number }
    > = {};
    for (const d of snapshot.debts) {
      const key = d.personName.trim();
      if (!map[key]) {
        map[key] = { name: key, phone: d.phone, receivablePoisha: 0, payablePoisha: 0 };
      }
      if (d.direction === 'receivable') {
        map[key].receivablePoisha += d.remainingPoisha;
      } else {
        map[key].payablePoisha += d.remainingPoisha;
      }
    }
    return Object.values(map);
  }, [snapshot.debts]);

  const openCreateModal = (dir: DebtDirection) => {
    setEditingDebt(null);
    setDirection(dir);
    setPersonName('');
    setPhone('');
    setPrincipalStr('');
    setTransactionDate('2026-11-06');
    setDueDate('2026-11-30');
    setReminderDate('2026-11-25');
    setAccountId(snapshot.settings.defaultAccountId || 'acc_bank');
    setPurpose('');
    setNotes('');
    setFormError(null);
    setIsAddModalOpen(true);
  };

  const openEditDebtModal = (debt: DebtRecord) => {
    setEditingDebt(debt);
    setDirection(debt.direction);
    setPersonName(debt.personName);
    setPhone(debt.phone || '');
    setPrincipalStr(poishaToMajorString(debt.principalPoisha, 2));
    setTransactionDate(debt.transactionDate);
    setDueDate(debt.dueDate);
    setReminderDate(debt.reminderDate || '');
    setAccountId(debt.accountId);
    setPurpose(debt.purpose || '');
    setNotes(debt.notes || '');
    setFormError(null);
    setIsAddModalOpen(true);
  };

  const handleSaveDebt = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (editingDebt) {
      const res = FinancialEngine.updateDebtRecord(snapshot, editingDebt.id, {
        personName,
        phone,
        principalPoisha: toPoisha(principalStr),
        transactionDate,
        dueDate,
        reminderDate,
        accountId,
        purpose,
        notes,
      });
      if (!res.ok) {
        setFormError(res.error || 'Could not update debt record');
        return;
      }
      onUpdateSnapshot(
        res.snapshot,
        `Updated Dena-Pawna record for ${personName} and synchronized account balance.`
      );
      setIsAddModalOpen(false);
      setEditingDebt(null);
      return;
    }

    const res = FinancialEngine.createDebtRecord(snapshot, {
      direction,
      personName,
      phone,
      principalPoisha: toPoisha(principalStr),
      transactionDate,
      dueDate,
      reminderDate,
      accountId,
      purpose,
      description:
        direction === 'receivable'
          ? `Lent to ${personName.trim()} (${purpose || 'Personal'})`
          : `Borrowed from ${personName.trim()} (${purpose || 'Personal'})`,
      notes,
    });
    if (!res.ok) {
      setFormError(res.error || 'Could not create record');
      return;
    }
    onUpdateSnapshot(
      res.snapshot,
      `Recorded ${direction === 'receivable' ? 'Money Lent (Pawna)' : 'Money Borrowed (Dena)'} for ${personName}.`
    );
    setIsAddModalOpen(false);
  };

  const handleDeleteDebt = (debt: DebtRecord) => {
    const next = FinancialEngine.deleteDebtRecord(snapshot, debt.id);
    onUpdateSnapshot(
      next,
      `Deleted Dena-Pawna record for "${debt.personName}" and reversed ledger transactions.`
    );
  };

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModalDebt) return;
    setFormError(null);
    const res = FinancialEngine.recordDebtPayment(snapshot, {
      debtId: paymentModalDebt.id,
      amountPoisha: toPoisha(payAmountStr),
      paymentDate: payDate,
      accountId: payAccountId,
      note: payNote,
    });
    if (!res.ok) {
      setFormError(res.error || 'Payment failed');
      return;
    }
    onUpdateSnapshot(
      res.snapshot,
      `Recorded ${fmtMoney(toPoisha(payAmountStr))} ${
        paymentModalDebt.direction === 'receivable' ? 'collection' : 'repayment'
      } for ${paymentModalDebt.personName}.`
    );
    setPaymentModalDebt(null);
  };

  const handleReversePayment = (debtPaymentId: string) => {
    const next = FinancialEngine.deleteDebtPayment(snapshot, debtPaymentId);
    onUpdateSnapshot(next, 'Reversed repayment/collection and restored outstanding debt balance.');
    if (statementDebt) {
      const refreshed = next.debts.find((d) => d.id === statementDebt.id) || null;
      setStatementDebt(refreshed);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-sky-600 text-white rounded-2xl p-5 shadow-sm">
          <div className="text-xs font-medium text-sky-100">
            Money Others Owe Me (Total Receivable / পাওনা)
          </div>
          <div className="text-2xl font-bold mt-1">{fmtMoney(totalReceivable)}</div>
          <div className="text-[11px] text-sky-100 mt-1">
            Principal excluded from regular expenses
          </div>
        </div>

        <div className="bg-amber-600 text-white rounded-2xl p-5 shadow-sm">
          <div className="text-xs font-medium text-amber-100">
            Money I Owe (Total Payable / দেনা)
          </div>
          <div className="text-2xl font-bold mt-1">{fmtMoney(totalPayable)}</div>
          <div className="text-[11px] text-amber-100 mt-1">
            Principal excluded from regular income
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <div className="text-xs text-slate-400">Net Dena-Pawna Position</div>
            <div
              className={`text-xl font-bold mt-1 ${
                totalReceivable - totalPayable >= 0 ? 'text-emerald-600' : 'text-rose-600'
              }`}
            >
              {fmtMoney(totalReceivable - totalPayable)}
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <button
              type="button"
              onClick={() => openCreateModal('receivable')}
              className="flex-1 py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold"
            >
              + Lent Money (Pawna)
            </button>
            <button
              type="button"
              onClick={() => openCreateModal('payable')}
              className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold"
            >
              + Borrowed (Dena)
            </button>
          </div>
        </div>
      </div>

      {/* Due Date Reminders & Overdue Alerts Banner */}
      {dueOrReminderDebts.length > 0 && (
        <div className="bg-sky-50/90 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-900 rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-sky-900 dark:text-sky-200">
            <Bell className="w-4 h-4 text-sky-600" />
            <span>Active Due Date & Repayment Reminders ({dueOrReminderDebts.length})</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {dueOrReminderDebts.map((d) => (
              <div
                key={d.id}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-sky-100 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">
                    {d.personName} ({d.direction === 'receivable' ? 'Pawna' : 'Dena'})
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Due: <strong>{d.dueDate}</strong> • Reminder: {d.reminderDate || 'Set'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-rose-600">{fmtMoney(d.remainingPoisha)}</div>
                  <button
                    type="button"
                    onClick={() => openEditDebtModal(d)}
                    className="text-[10px] text-emerald-600 font-semibold hover:underline"
                  >
                    Update Reminder
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabs & Contact Search */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('receivable')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold ${
              activeTab === 'receivable'
                ? 'bg-sky-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Money Others Owe Me (Receivables)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('payable')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold ${
              activeTab === 'payable'
                ? 'bg-amber-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Money I Owe (Payables)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('contacts')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold ${
              activeTab === 'contacts'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Person-wise Balances ({personBalances.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold ${
              activeTab === 'history'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Payment History ({snapshot.debtPayments.length})
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchContact}
            onChange={(e) => setSearchContact(e.target.value)}
            placeholder="Search person, phone, purpose..."
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'contacts' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {personBalances.map((p) => (
            <div
              key={p.name}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-2"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">{p.name}</h4>
                <span className="text-xs text-slate-400">{p.phone}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
                <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/40">
                  <div className="text-[10px] text-sky-600">Owes Me (Pawna)</div>
                  <div className="font-bold text-sky-700 dark:text-sky-300">
                    {fmtMoney(p.receivablePoisha)}
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40">
                  <div className="text-[10px] text-amber-600">I Owe (Dena)</div>
                  <div className="font-bold text-amber-700 dark:text-amber-300">
                    {fmtMoney(p.payablePoisha)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : activeTab === 'history' ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
            Complete Repayment & Collection Ledger History
          </h4>
          {snapshot.debtPayments.length === 0 ? (
            <div className="text-xs text-slate-400 py-6 text-center">
              No debt repayments or collections recorded yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {snapshot.debtPayments.map((dp) => {
                const debt = snapshot.debts.find((d) => d.id === dp.debtId);
                const acc = snapshot.accounts.find((a) => a.id === dp.accountId);
                return (
                  <div key={dp.id} className="py-3 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">
                        {debt?.personName || 'Contact'} — {dp.type.toUpperCase()}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {dp.paymentDate} • Account: {acc?.name || dp.accountId} • {dp.note}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-emerald-600">
                        {fmtMoney(dp.amountPoisha)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleReversePayment(dp.id)}
                        className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/50 text-rose-600 text-[11px] font-semibold"
                      >
                        Reverse
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDebts.map((debt) => {
            const pctPaid = Math.min(
              100,
              Math.round((debt.paidPoisha / Math.max(1, debt.principalPoisha)) * 100)
            );
            const history = snapshot.debtPayments.filter((dp) => dp.debtId === debt.id);

            return (
              <div
                key={debt.id}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {debt.personName}
                      </h4>
                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-full ${
                          debt.status === 'settled'
                            ? 'bg-emerald-100 text-emerald-700'
                            : debt.status === 'overdue'
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-sky-100 text-sky-700'
                        }`}
                      >
                        {debt.status}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {debt.phone && <span>📞 {debt.phone} • </span>}
                      <span>Purpose: {debt.purpose}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setStatementDebt(debt)}
                      className="text-xs font-medium text-emerald-600 hover:underline flex items-center gap-1"
                    >
                      <FileText className="w-3.5 h-3.5" /> Statement ({history.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => openEditDebtModal(debt)}
                      title="Edit Debt Record"
                      className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteDebt(debt)}
                      title="Delete Debt Record"
                      className="p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Principal / Paid / Remaining Breakdown */}
                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                  <div>
                    <div className="text-[10px] text-slate-400">Original Principal</div>
                    <div className="font-bold text-slate-800 dark:text-slate-100">
                      {fmtMoney(debt.principalPoisha)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">
                      {debt.direction === 'receivable' ? 'Returned' : 'Paid'} ({pctPaid}%)
                    </div>
                    <div className="font-bold text-emerald-600">
                      {fmtMoney(debt.paidPoisha)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Outstanding</div>
                    <div className="font-bold text-rose-600">
                      {fmtMoney(debt.remainingPoisha)}
                    </div>
                  </div>
                </div>

                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all"
                    style={{ width: `${pctPaid}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>Date: {debt.transactionDate}</span>
                  <span>Due: {debt.dueDate}</span>
                  {debt.reminderDate && <span>🔔 Reminder: {debt.reminderDate}</span>}
                </div>

                {debt.remainingPoisha > 0 && (
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setPaymentModalDebt(debt);
                        setPayAmountStr(poishaToMajorString(Math.round(debt.remainingPoisha / 2), 2));
                        setPayAccountId(debt.accountId);
                        setPayNote('Partial installment');
                        setFormError(null);
                      }}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                    >
                      {debt.direction === 'receivable'
                        ? 'Record Partial Collection'
                        : 'Record Partial Repayment'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPaymentModalDebt(debt);
                        setPayAmountStr(poishaToMajorString(debt.remainingPoisha, 2));
                        setPayAccountId(debt.accountId);
                        setPayNote('Full settlement');
                        setFormError(null);
                      }}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
                    >
                      Full Settle
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit Debt / Receivable Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingDebt
                ? `Edit Dena-Pawna — ${editingDebt.personName}`
                : direction === 'receivable'
                ? 'Add Money Lent to Someone (Receivable / পাওনা)'
                : 'Add Money Borrowed (Payable / দেনা)'}
            </h3>
            {formError && (
              <div className="mb-3 p-2.5 rounded-xl bg-rose-50 text-rose-700 text-xs">
                {formError}
              </div>
            )}
            <form onSubmit={handleSaveDebt} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Person Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={personName}
                    onChange={(e) => setPersonName(e.target.value)}
                    placeholder="e.g., Tanvir Ahmed"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+88017..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Principal Amount (৳) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={principalStr}
                    onChange={(e) => setPrincipalStr(e.target.value)}
                    placeholder="10000"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Account Used
                  </label>
                  <select
                    value={accountId}
                    onChange={(e) => setAccountId(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {snapshot.accounts
                      .filter((a) => a.status === 'active')
                      .map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Given Date</label>
                  <input
                    type="date"
                    value={transactionDate}
                    onChange={(e) => setTransactionDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Due Date</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Reminder</label>
                  <input
                    type="date"
                    value={reminderDate}
                    onChange={(e) => setReminderDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Purpose / Description
                </label>
                <input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g., Emergency medical support, Business supply"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingDebt(null);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Save Dena-Pawna Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Repayment / Collection Modal */}
      {paymentModalDebt && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              {paymentModalDebt.direction === 'receivable'
                ? `Collect from ${paymentModalDebt.personName}`
                : `Repay to ${paymentModalDebt.personName}`}
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Outstanding Balance: <strong>{fmtMoney(paymentModalDebt.remainingPoisha)}</strong>
            </p>
            {formError && (
              <div className="mb-3 p-2.5 rounded-xl bg-rose-50 text-rose-700 text-xs">
                {formError}
              </div>
            )}
            <form onSubmit={handleRecordPayment} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Amount (৳) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={payAmountStr}
                  onChange={(e) => setPayAmountStr(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Receiving / Paying Account
                </label>
                <select
                  value={payAccountId}
                  onChange={(e) => setPayAccountId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {snapshot.accounts
                    .filter((a) => a.status === 'active')
                    .map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Payment Date
                </label>
                <input
                  type="date"
                  value={payDate}
                  onChange={(e) => setPayDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Note
                </label>
                <input
                  type="text"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPaymentModalDebt(null)}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Confirm & Update Balance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Individual Statement Modal */}
      {statementDebt && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Statement — {statementDebt.personName}
              </h3>
              <button
                type="button"
                onClick={() => setStatementDebt(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs space-y-1">
              <div>
                <strong>Original Principal:</strong> {fmtMoney(statementDebt.principalPoisha)} (
                {statementDebt.transactionDate})
              </div>
              <div>
                <strong>Total Settled:</strong> {fmtMoney(statementDebt.paidPoisha)}
              </div>
              <div>
                <strong>Remaining Due:</strong> {fmtMoney(statementDebt.remainingPoisha)}
              </div>
            </div>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              <div className="text-xs font-bold text-slate-500">Repayment / Collection History:</div>
              {snapshot.debtPayments
                .filter((dp) => dp.debtId === statementDebt.id)
                .map((dp) => (
                  <div
                    key={dp.id}
                    className="p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold">{dp.note || dp.type.toUpperCase()}</div>
                      <div className="text-[11px] text-slate-400">{dp.paymentDate}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-600">{fmtMoney(dp.amountPoisha)}</span>
                      <button
                        type="button"
                        onClick={() => handleReversePayment(dp.id)}
                        className="text-[10px] text-rose-500 hover:underline"
                      >
                        Reverse
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
