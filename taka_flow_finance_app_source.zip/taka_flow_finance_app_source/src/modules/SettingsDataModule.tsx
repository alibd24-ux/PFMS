// ============================================================================
// PHASE 10 & 11: SETTINGS, CUSTOMIZATION, BACKUP & RESTORE MODULES
// Supports Bengali/English localization, Light/Dark/System themes, Accent colors,
// Custom Exchange Rates, File Upload (.json / .csv) + Paste Backup/Restore,
// Backward Compatibility (v1/v2), Duplicate Detection, Merge/Replace, & Safety Backup.
// ============================================================================

import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Database,
  Download,
  Globe,
  Palette,
  RefreshCw,
  ShieldCheck,
  Sliders,
  Upload,
} from 'lucide-react';
import {
  AppSettings,
  CurrencyCode,
  DatabaseSnapshot,
  LanguageCode,
  NumberFormatStyle,
  ThemeMode,
} from '../types/models';
import { createInitialSeedSnapshot } from '../db/database';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from '../utils/money';

export interface SettingsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

export const SettingsModule: React.FC<SettingsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const s = snapshot.settings;

  const updateSettings = (patch: Partial<AppSettings>, msg = 'Updated application settings.') => {
    const nextSettings: AppSettings = {
      ...s,
      ...patch,
      updatedAt: new Date().toISOString(),
    };
    const next = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      settings: nextSettings,
    });
    onUpdateSnapshot(next, msg);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* General & Localization Settings */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-600" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            General, Localization & Currency Formatting
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Application Name
            </label>
            <input
              type="text"
              value={s.appName}
              onChange={(e) => updateSettings({ appName: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Interface Language (ভাষা)
            </label>
            <select
              value={s.language}
              onChange={(e) =>
                updateSettings(
                  { language: e.target.value as LanguageCode },
                  `Switched language to ${e.target.value === 'bn' ? 'বাংলা (Bengali)' : 'English'}.`
                )
              }
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
            >
              <option value="en">English (EN)</option>
              <option value="bn">বাংলা (Bengali)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Default Currency
            </label>
            <select
              value={s.defaultCurrency}
              onChange={(e) => updateSettings({ defaultCurrency: e.target.value as CurrencyCode })}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              <option value="BDT">Bangladeshi Taka (৳ BDT)</option>
              <option value="USD">US Dollar ($ USD)</option>
              <option value="EUR">Euro (€ EUR)</option>
              <option value="GBP">British Pound (£ GBP)</option>
              <option value="INR">Indian Rupee (₹ INR)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Number & Lakh Formatting
            </label>
            <select
              value={s.numberFormat}
              onChange={(e) =>
                updateSettings({ numberFormat: e.target.value as NumberFormatStyle })
              }
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              <option value="bd_lakh">Bangladeshi Lakh/Crore (৳ 1,25,000.00)</option>
              <option value="bn_digits">Bengali Digits (৳ ১,২৫,০০০.০০)</option>
              <option value="intl">International (৳ 125,000.00)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Currency Decimal Precision
            </label>
            <select
              value={s.currencyPrecision}
              onChange={(e) =>
                updateSettings({ currencyPrecision: Number(e.target.value) as 0 | 2 })
              }
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              <option value={2}>2 Decimal Places (৳ 1,25,000.00)</option>
              <option value={0}>Whole Taka Only (৳ 1,25,000)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              First Day of Week
            </label>
            <select
              value={s.firstDayOfWeek}
              onChange={(e) => updateSettings({ firstDayOfWeek: e.target.value as any })}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              <option value="saturday">Saturday (শনিবার)</option>
              <option value="sunday">Sunday (রবিবার)</option>
              <option value="monday">Monday (সোমবার)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Appearance & Material Design 3 Theme */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Appearance, Theme & Layout
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Theme Mode
            </label>
            <div className="flex gap-2">
              {(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => updateSettings({ theme: mode }, `Theme set to ${mode}.`)}
                  className={`flex-1 py-2 rounded-xl font-semibold capitalize ${
                    s.theme === mode
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Font Size Scale
            </label>
            <div className="flex gap-2">
              {(['sm', 'md', 'lg'] as const).map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => updateSettings({ fontSize: sz })}
                  className={`flex-1 py-2 rounded-xl font-semibold uppercase ${
                    s.fontSize === sz
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1">
              Default Account for Quick Add
            </label>
            <select
              value={s.defaultAccountId}
              onChange={(e) => updateSettings({ defaultAccountId: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              {snapshot.accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Accent Color & Custom Exchange Rates */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1.5">
              Accent Color Palette
            </label>
            <div className="flex flex-wrap gap-2">
              {(['emerald', 'indigo', 'teal', 'rose', 'amber', 'violet'] as const).map((ac) => (
                <button
                  key={ac}
                  type="button"
                  onClick={() => updateSettings({ accentColor: ac }, `Accent color set to ${ac}.`)}
                  className={`px-3 py-1.5 rounded-xl font-semibold capitalize ${
                    s.accentColor === ac
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {ac}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300 mb-1.5">
              Custom Exchange Rates (BDT per 1 Foreign Unit)
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['USD', 'EUR', 'GBP', 'INR'] as CurrencyCode[]).map((cur) => (
                <div key={cur}>
                  <span className="text-[10px] text-slate-400">{cur}</span>
                  <input
                    type="number"
                    step="0.01"
                    value={s.exchangeRates[cur]}
                    onChange={(e) =>
                      updateSettings({
                        exchangeRates: {
                          ...s.exchangeRates,
                          [cur]: parseFloat(e.target.value) || 1,
                        },
                      })
                    }
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Optional Modules & Notification Switches */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-teal-600" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Feature Flags, Optional Modules & Alerts
          </h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
          {(
            Object.keys(s.enabledModules) as Array<keyof AppSettings['enabledModules']>
          ).map((modKey) => (
            <label
              key={modKey}
              className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 cursor-pointer"
            >
              <span className="font-semibold capitalize">{modKey} Module</span>
              <input
                type="checkbox"
                checked={s.enabledModules[modKey]}
                onChange={(e) =>
                  updateSettings({
                    enabledModules: { ...s.enabledModules, [modKey]: e.target.checked },
                  })
                }
              />
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// DATA BACKUP, RESTORE & MIGRATION MODULE (Section 15)
// ============================================================================
export interface DataManagementModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
  onSavePreRestoreSafetyBackup: (snap: DatabaseSnapshot) => void;
  preRestoreBackup: DatabaseSnapshot | null;
}

export const DataManagementModule: React.FC<DataManagementModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
  onSavePreRestoreSafetyBackup,
  preRestoreBackup,
}) => {
  const [jsonInput, setJsonInput] = useState('');
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [validationResult, setValidationResult] = useState<ReturnType<
    typeof FinancialEngine.validateBackupJson
  > | null>(null);
  const [csvImportText, setCsvImportText] = useState('');

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    try {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      // Ignore
    }
  };

  const handleExportFullJson = () => {
    const payload: DatabaseSnapshot = {
      ...snapshot,
      exportedAt: new Date().toISOString(),
    };
    const jsonStr = JSON.stringify(payload, null, 2);
    setJsonInput(jsonStr);
    downloadFile(
      jsonStr,
      `takaflow_full_backup_${new Date().toISOString().slice(0, 10)}.json`,
      'application/json'
    );
  };

  const handleValidateJson = (raw: string) => {
    setJsonInput(raw);
    if (!raw.trim()) {
      setValidationResult(null);
      return;
    }
    const res = FinancialEngine.validateBackupJson(raw, snapshot);
    setValidationResult(res);
  };

  const handleJsonFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      handleValidateJson(text);
    };
    reader.readAsText(file);
  };

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      setCsvImportText(text);
    };
    reader.readAsText(file);
  };

  const handleExecuteRestore = () => {
    if (!validationResult || !validationResult.valid || !validationResult.parsed) return;
    onSavePreRestoreSafetyBackup(snapshot);
    const next = FinancialEngine.restoreBackupSnapshot(
      snapshot,
      validationResult.parsed,
      restoreMode
    );
    onUpdateSnapshot(
      next,
      `Successfully restored backup in ${restoreMode.toUpperCase()} mode (safety snapshot saved).`
    );
    setValidationResult(null);
  };

  const handleCSVImport = () => {
    if (!csvImportText.trim()) return;
    const res = FinancialEngine.importTransactionsFromCSV(snapshot, csvImportText);
    onUpdateSnapshot(
      res.snapshot,
      `Imported ${res.importedCount} transactions from CSV (${res.skippedDuplicates} duplicates skipped).`
    );
    setCsvImportText('');
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Export Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Full Data Ownership: Backup, Export & Restore
            </h3>
            <p className="text-xs text-slate-500">
              Schema v{snapshot.schemaVersion} • {snapshot.accounts.length} Accounts •{' '}
              {snapshot.transactions.length} Transactions • {snapshot.categories.length} Categories
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={handleExportFullJson}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
          >
            <Download className="w-3.5 h-3.5" /> Generate & Download Full JSON Backup
          </button>
          <button
            type="button"
            onClick={() =>
              downloadFile(
                FinancialEngine.exportTransactionsToCSV(snapshot),
                'takaflow_transactions.csv',
                'text/csv'
              )
            }
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
          >
            <Download className="w-3.5 h-3.5" /> Export Transactions CSV
          </button>
          <button
            type="button"
            onClick={() =>
              downloadFile(
                JSON.stringify(snapshot.accounts, null, 2),
                'takaflow_accounts.json',
                'application/json'
              )
            }
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
          >
            Export Accounts
          </button>
          <button
            type="button"
            onClick={() =>
              downloadFile(
                JSON.stringify(
                  { categories: snapshot.categories, subcategories: snapshot.subcategories },
                  null,
                  2
                ),
                'takaflow_categories.json',
                'application/json'
              )
            }
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
          >
            Export Categories
          </button>
        </div>
      </div>

      {/* Validated JSON Restore with File Upload, Preview & Merge/Replace */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
            Restore from JSON Backup (With Validation, Preview & Pre-Restore Safety Snapshot)
          </h4>
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200">
            <Upload className="w-3.5 h-3.5" /> Upload .JSON File
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleJsonFileUpload}
              className="hidden"
            />
          </label>
        </div>

        <textarea
          rows={5}
          value={jsonInput}
          onChange={(e) => handleValidateJson(e.target.value)}
          placeholder="Paste full JSON backup content here (or click 'Upload .JSON File' / 'Generate & Download Full JSON Backup' above)..."
          className="w-full p-3 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
        />

        {validationResult && (
          <div
            className={`p-4 rounded-xl text-xs space-y-2 ${
              validationResult.valid
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 border border-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border border-rose-200'
            }`}
          >
            {!validationResult.valid ? (
              <div className="font-bold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" /> Validation Failed: {validationResult.error}
              </div>
            ) : (
              validationResult.preview && (
                <>
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Valid Backup File Verified
                    (Schema v{validationResult.preview.schemaVersion})
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    <div>Accounts: <strong>{validationResult.preview.accountsCount}</strong></div>
                    <div>Transactions: <strong>{validationResult.preview.transactionsCount}</strong></div>
                    <div>Duplicates Detected: <strong>{validationResult.preview.duplicateTransactionsCount}</strong></div>
                    <div>Categories: <strong>{validationResult.preview.categoriesCount}</strong></div>
                    <div>Budgets: <strong>{validationResult.preview.budgetsCount}</strong></div>
                    <div>Dena-Pawna: <strong>{validationResult.preview.debtsCount}</strong></div>
                    <div>Loans: <strong>{validationResult.preview.loansCount}</strong></div>
                    <div>Savings Goals: <strong>{validationResult.preview.savingsGoalsCount}</strong></div>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3">
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 font-semibold cursor-pointer">
                        <input
                          type="radio"
                          checked={restoreMode === 'merge'}
                          onChange={() => setRestoreMode('merge')}
                        />
                        <span>Merge (Skip Duplicates, Preserve Existing)</span>
                      </label>
                      <label className="flex items-center gap-1.5 font-semibold cursor-pointer">
                        <input
                          type="radio"
                          checked={restoreMode === 'replace'}
                          onChange={() => setRestoreMode('replace')}
                        />
                        <span>Replace All (Auto-creates safety backup first)</span>
                      </label>
                    </div>
                    <button
                      type="button"
                      onClick={handleExecuteRestore}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                    >
                      Confirm & Restore Backup
                    </button>
                  </div>
                </>
              )
            )}
          </div>
        )}

        {preRestoreBackup && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 flex items-center justify-between text-xs">
            <span>
              Pre-restore safety backup available ({preRestoreBackup.transactions.length} transactions).
            </span>
            <button
              type="button"
              onClick={() =>
                onUpdateSnapshot(
                  FinancialEngine.recalculateSnapshotIntegrity(preRestoreBackup),
                  'Rolled back to pre-restore safety snapshot.'
                )
              }
              className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-semibold"
            >
              Undo Restore
            </button>
          </div>
        )}
      </div>

      {/* CSV Import Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Import Transactions from CSV
            </h4>
            <p className="text-xs text-slate-500">
              Format: <code>Date,Type,Amount,Description</code> (e.g.{' '}
              <code>2026-11-06,expense,450,Evening Snacks</code>)
            </p>
          </div>
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200">
            <Upload className="w-3.5 h-3.5" /> Upload .CSV File
            <input
              type="file"
              accept=".csv,text/csv"
              onChange={handleCsvFileUpload}
              className="hidden"
            />
          </label>
        </div>

        <textarea
          rows={3}
          value={csvImportText}
          onChange={(e) => setCsvImportText(e.target.value)}
          placeholder={'Date,Type,Amount,Description\n2026-11-06,expense,550,Rickshaw & Fruits'}
          className="w-full p-3 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
        />
        <div className="flex justify-between items-center">
          <button
            type="button"
            onClick={handleCSVImport}
            className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
          >
            Import CSV Rows
          </button>
          <button
            type="button"
            onClick={() => {
              onSavePreRestoreSafetyBackup(snapshot);
              const fresh = FinancialEngine.recalculateSnapshotIntegrity(
                createInitialSeedSnapshot()
              );
              onUpdateSnapshot(fresh, 'Reset database to default initial seed records (safety backup saved).');
            }}
            className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 text-xs font-semibold"
          >
            Reset to Default Seed Data
          </button>
        </div>
      </div>
    </div>
  );
};
