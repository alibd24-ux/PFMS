// ============================================================================
// PHASE 4: CUSTOM CATEGORY & SUBCATEGORY MANAGEMENT MODULE
// Supports unlimited Income & Expense categories, custom category groups
// (Family, Office, Personal, Essential, etc.), unlimited subcategories with
// full CRUD (Create, Edit/Rename, Reassign Parent Category, Spending Limit,
// Archive/Delete safely), category reordering, enable/disable, archive,
// safe category merging, and Category/Subcategory Transaction History modal.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  Edit3,
  FolderTree,
  GitMerge,
  History,
  Plus,
  Tag,
  ToggleLeft,
  ToggleRight,
  Trash2,
} from 'lucide-react';
import { Category, DatabaseSnapshot, Subcategory } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from '../utils/money';

export interface CategoriesModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

const CATEGORY_COLORS = [
  '#f97316',
  '#10b981',
  '#3b82f6',
  '#ec4899',
  '#6366f1',
  '#eab308',
  '#ef4444',
  '#06b6d4',
  '#f43f5e',
  '#8b5cf6',
  '#14b8a6',
  '#0284c7',
];

export const CategoriesModule: React.FC<CategoriesModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [activeType, setActiveType] = useState<'expense' | 'income'>('expense');
  const [groupFilter, setGroupFilter] = useState<string>('all');
  const [showArchived, setShowArchived] = useState(false);

  // Category Form Modal
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [catName, setCatName] = useState('');
  const [catNameBn, setCatNameBn] = useState('');
  const [catGroup, setCatGroup] = useState('Personal');
  const [catColor, setCatColor] = useState('#10b981');
  const [catLimitStr, setCatLimitStr] = useState('0');

  // Subcategory Create / Edit Modal (Full CRUD)
  const [subParentCat, setSubParentCat] = useState<Category | null>(null);
  const [editingSub, setEditingSub] = useState<Subcategory | null>(null);
  const [subTargetParentId, setSubTargetParentId] = useState<string>('');
  const [subName, setSubName] = useState('');
  const [subNameBn, setSubNameBn] = useState('');
  const [subLimitStr, setSubLimitStr] = useState('0');

  // Category History & Analytics Modal
  const [historyCat, setHistoryCat] = useState<Category | null>(null);

  // Merge Categories Modal
  const [isMergeOpen, setIsMergeOpen] = useState(false);
  const [mergeSourceId, setMergeSourceId] = useState('');
  const [mergeTargetId, setMergeTargetId] = useState('');

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const openNewCat = () => {
    setEditingCat(null);
    setCatName('');
    setCatNameBn('');
    setCatGroup(activeType === 'income' ? 'Income' : 'Personal');
    setCatColor('#10b981');
    setCatLimitStr('3000');
    setIsCatModalOpen(true);
  };

  const openEditCat = (cat: Category) => {
    setEditingCat(cat);
    setCatName(cat.name);
    setCatNameBn(cat.nameBn || '');
    setCatGroup(cat.groupName);
    setCatColor(cat.color);
    setCatLimitStr(poishaToMajorString(cat.monthlyLimitPoisha, 2));
    setIsCatModalOpen(true);
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) return;
    const now = new Date().toISOString();
    const monthlyLimitPoisha = Math.max(0, toPoisha(catLimitStr));

    if (editingCat) {
      const updated = snapshot.categories.map((c) =>
        c.id === editingCat.id
          ? {
              ...c,
              name: catName.trim(),
              nameBn: catNameBn.trim() || catName.trim(),
              groupName: catGroup.trim() || 'Personal',
              color: catColor,
              monthlyLimitPoisha,
              updatedAt: now,
            }
          : c
      );
      onUpdateSnapshot(
        { ...snapshot, categories: updated },
        `Updated category "${catName.trim()}" (all historical transactions preserved).`
      );
    } else {
      const maxOrder = snapshot.categories
        .filter((c) => c.type === activeType)
        .reduce((m, c) => Math.max(m, c.sortOrder), 0);
      const newCat: Category = {
        id: `cat_${Date.now()}`,
        name: catName.trim(),
        nameBn: catNameBn.trim() || catName.trim(),
        type: activeType,
        groupName: catGroup.trim() || 'Personal',
        icon: 'Tag',
        color: catColor,
        sortOrder: maxOrder + 1,
        monthlyLimitPoisha,
        isEnabled: true,
        isArchived: false,
        createdAt: now,
        updatedAt: now,
      };
      onUpdateSnapshot(
        { ...snapshot, categories: [...snapshot.categories, newCat] },
        `Created custom category "${newCat.name}".`
      );
    }
    setIsCatModalOpen(false);
  };

  const openAddSubModal = (cat: Category) => {
    setEditingSub(null);
    setSubParentCat(cat);
    setSubTargetParentId(cat.id);
    setSubName('');
    setSubNameBn('');
    setSubLimitStr('0');
  };

  const openEditSubModal = (cat: Category, sub: Subcategory) => {
    setEditingSub(sub);
    setSubParentCat(cat);
    setSubTargetParentId(sub.categoryId);
    setSubName(sub.name);
    setSubNameBn(sub.nameBn || '');
    setSubLimitStr(poishaToMajorString(sub.monthlyLimitPoisha || 0, 2));
  };

  const handleSaveSubcategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subParentCat || !subName.trim()) return;
    const limitPoisha = Math.max(0, toPoisha(subLimitStr));

    if (editingSub) {
      const updatedSubs = snapshot.subcategories.map((s) =>
        s.id === editingSub.id
          ? {
              ...s,
              categoryId: subTargetParentId || subParentCat.id,
              name: subName.trim(),
              nameBn: subNameBn.trim() || subName.trim(),
              monthlyLimitPoisha: limitPoisha,
            }
          : s
      );
      onUpdateSnapshot(
        { ...snapshot, subcategories: updatedSubs },
        `Updated subcategory "${subName.trim()}".`
      );
    } else {
      const newSub: Subcategory = {
        id: `sub_${Date.now()}`,
        categoryId: subTargetParentId || subParentCat.id,
        name: subName.trim(),
        nameBn: subNameBn.trim() || subName.trim(),
        icon: 'Tag',
        color: subParentCat.color,
        monthlyLimitPoisha: limitPoisha,
        isArchived: false,
        createdAt: new Date().toISOString(),
      };
      onUpdateSnapshot(
        { ...snapshot, subcategories: [...snapshot.subcategories, newSub] },
        `Added subcategory "${newSub.name}" under "${subParentCat.name}".`
      );
    }
    setSubName('');
    setSubNameBn('');
    setEditingSub(null);
    setSubParentCat(null);
  };

  const handleArchiveOrDeleteSubcategory = (sub: Subcategory) => {
    const updatedSubs = snapshot.subcategories.map((s) =>
      s.id === sub.id ? { ...s, isArchived: !s.isArchived } : s
    );
    onUpdateSnapshot(
      { ...snapshot, subcategories: updatedSubs },
      `Subcategory "${sub.name}" ${!sub.isArchived ? 'archived' : 'restored'} (history preserved).`
    );
    setEditingSub(null);
    setSubParentCat(null);
  };

  const handleReorder = (cat: Category, dir: -1 | 1) => {
    const list = snapshot.categories
      .filter((c) => c.type === cat.type && !c.isArchived)
      .sort((a, b) => a.sortOrder - b.sortOrder);
    const idx = list.findIndex((c) => c.id === cat.id);
    const swapIdx = idx + dir;
    if (idx < 0 || swapIdx < 0 || swapIdx >= list.length) return;
    const other = list[swapIdx];
    const updated = snapshot.categories.map((c) => {
      if (c.id === cat.id) return { ...c, sortOrder: other.sortOrder };
      if (c.id === other.id) return { ...c, sortOrder: cat.sortOrder };
      return c;
    });
    onUpdateSnapshot({ ...snapshot, categories: updated }, 'Updated category sort order.');
  };

  const handleMerge = (e: React.FormEvent) => {
    e.preventDefault();
    const res = FinancialEngine.mergeCategories(snapshot, mergeSourceId, mergeTargetId);
    if (res.ok) {
      onUpdateSnapshot(
        res.snapshot,
        'Merged categories and reassigned all historical transactions and subcategories.'
      );
      setIsMergeOpen(false);
    }
  };

  // Compute lifetime spending per category AND per subcategory
  const { categoryStats, subcategoryStats } = useMemo(() => {
    const catMap: Record<string, { totalPoisha: number; count: number }> = {};
    const subMap: Record<string, { totalPoisha: number; count: number }> = {};

    for (const tx of snapshot.transactions) {
      if (tx.type !== 'expense' && tx.type !== 'income') continue;
      if (tx.isSplit) {
        const splits = snapshot.transactionSplits.filter((s) => s.transactionId === tx.id);
        for (const sp of splits) {
          if (!catMap[sp.categoryId]) catMap[sp.categoryId] = { totalPoisha: 0, count: 0 };
          catMap[sp.categoryId].totalPoisha += sp.amountPoisha;
          catMap[sp.categoryId].count += 1;
          if (sp.subcategoryId) {
            if (!subMap[sp.subcategoryId]) subMap[sp.subcategoryId] = { totalPoisha: 0, count: 0 };
            subMap[sp.subcategoryId].totalPoisha += sp.amountPoisha;
            subMap[sp.subcategoryId].count += 1;
          }
        }
      } else {
        if (!catMap[tx.categoryId]) catMap[tx.categoryId] = { totalPoisha: 0, count: 0 };
        catMap[tx.categoryId].totalPoisha += tx.amountPoisha;
        catMap[tx.categoryId].count += 1;
        if (tx.subcategoryId) {
          if (!subMap[tx.subcategoryId]) subMap[tx.subcategoryId] = { totalPoisha: 0, count: 0 };
          subMap[tx.subcategoryId].totalPoisha += tx.amountPoisha;
          subMap[tx.subcategoryId].count += 1;
        }
      }
    }
    return { categoryStats: catMap, subcategoryStats: subMap };
  }, [snapshot.transactions, snapshot.transactionSplits]);

  const groups = useMemo(() => {
    const set = new Set(
      snapshot.categories.filter((c) => c.type === activeType).map((c) => c.groupName)
    );
    return Array.from(set);
  }, [snapshot.categories, activeType]);

  const filteredCategories = snapshot.categories
    .filter((c) => c.type === activeType)
    .filter((c) => (showArchived ? true : !c.isArchived))
    .filter((c) => (groupFilter === 'all' ? true : c.groupName === groupFilter))
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="space-y-6 pb-8">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Custom Category & Subcategory Architecture
            </h3>
            <p className="text-xs text-slate-500">
              Create unlimited groups (Family, Office, Personal), subcategories, and merge or archive safely
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={openNewCat}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" /> New Category
            </button>
            <button
              type="button"
              onClick={() => setIsMergeOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
            >
              <GitMerge className="w-3.5 h-3.5" /> Merge Categories
            </button>
            <button
              type="button"
              onClick={() => setShowArchived(!showArchived)}
              className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              {showArchived ? 'Hide Archived' : 'Show Archived'}
            </button>
          </div>
        </div>

        {/* Expense / Income Toggle + Group Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => {
                setActiveType('expense');
                setGroupFilter('all');
              }}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold ${
                activeType === 'expense'
                  ? 'bg-rose-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Expense Categories (
              {snapshot.categories.filter((c) => c.type === 'expense' && !c.isArchived).length})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveType('income');
                setGroupFilter('all');
              }}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold ${
                activeType === 'income'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Income Categories (
              {snapshot.categories.filter((c) => c.type === 'income' && !c.isArchived).length})
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setGroupFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                groupFilter === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              All Groups
            </button>
            {groups.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => setGroupFilter(g)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                  groupFilter === g
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Category Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCategories.map((cat) => {
          const subs = snapshot.subcategories.filter(
            (s) => s.categoryId === cat.id && (showArchived ? true : !s.isArchived)
          );
          const stat = categoryStats[cat.id] || { totalPoisha: 0, count: 0 };

          return (
            <div
              key={cat.id}
              className={`bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3 ${
                !cat.isEnabled || cat.isArchived ? 'opacity-60' : ''
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-xs"
                    style={{ backgroundColor: cat.color }}
                  >
                    {cat.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {cat.name}
                      </h4>
                      <span className="text-xs text-slate-400">({cat.nameBn})</span>
                      <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                        {cat.groupName}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {stat.count} transactions • Total: <strong>{fmtMoney(stat.totalPoisha)}</strong>
                      {cat.monthlyLimitPoisha > 0 && (
                        <span> • Limit: {fmtMoney(cat.monthlyLimitPoisha)}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Controls */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setHistoryCat(cat)}
                    title="Category History & Analytics"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-indigo-600"
                  >
                    <History className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReorder(cat, -1)}
                    title="Move Up"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReorder(cat, 1)}
                    title="Move Down"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => openEditCat(cat)}
                    title="Rename / Edit Category"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = snapshot.categories.map((c) =>
                        c.id === cat.id ? { ...c, isEnabled: !c.isEnabled } : c
                      );
                      onUpdateSnapshot(
                        { ...snapshot, categories: updated },
                        `Category "${cat.name}" ${!cat.isEnabled ? 'enabled' : 'disabled'}.`
                      );
                    }}
                    title="Enable / Disable Category"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-emerald-600"
                  >
                    {cat.isEnabled ? (
                      <ToggleRight className="w-4 h-4" />
                    ) : (
                      <ToggleLeft className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = snapshot.categories.map((c) =>
                        c.id === cat.id ? { ...c, isArchived: !c.isArchived } : c
                      );
                      onUpdateSnapshot(
                        { ...snapshot, categories: updated },
                        `Category "${cat.name}" ${!cat.isArchived ? 'archived' : 'unarchived'}.`
                      );
                    }}
                    title="Archive Category"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Archive className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Subcategories List (Full Interactive CRUD) */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Subcategories ({subs.length}) — Click to Edit
                  </span>
                  <button
                    type="button"
                    onClick={() => openAddSubModal(cat)}
                    className="text-[11px] font-semibold text-emerald-600 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" /> Add Subcategory
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {subs.length === 0 ? (
                    <span className="text-[11px] text-slate-400">No subcategories yet</span>
                  ) : (
                    subs.map((sub) => {
                      const sStat = subcategoryStats[sub.id];
                      return (
                        <button
                          key={sub.id}
                          type="button"
                          onClick={() => openEditSubModal(cat, sub)}
                          className={`px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-all ${
                            sub.isArchived ? 'opacity-50 line-through' : ''
                          }`}
                        >
                          <span
                            className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: cat.color }}
                          />
                          <span>{sub.name}</span>
                          {sub.nameBn && sub.nameBn !== sub.name && (
                            <span className="text-[10px] text-slate-400">({sub.nameBn})</span>
                          )}
                          {sStat && sStat.totalPoisha > 0 && (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                              • {fmtMoney(sStat.totalPoisha)}
                            </span>
                          )}
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Category Create/Edit Modal */}
      {isCatModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              {editingCat ? `Edit Category "${editingCat.name}"` : `Create ${activeType} Category`}
            </h3>
            <form onSubmit={handleSaveCategory} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Category Name (English) *
                </label>
                <input
                  type="text"
                  required
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  placeholder="e.g., Family, Office, Personal, Medical"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Category Name (বাংলা)
                </label>
                <input
                  type="text"
                  value={catNameBn}
                  onChange={(e) => setCatNameBn(e.target.value)}
                  placeholder="যেমন: পরিবার, অফিস, চিকিৎসা"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Custom Category Group
                  </label>
                  <input
                    type="text"
                    value={catGroup}
                    onChange={(e) => setCatGroup(e.target.value)}
                    placeholder="Family, Office, Personal..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Monthly Spending Limit (৳)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={catLimitStr}
                    onChange={(e) => setCatLimitStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Category Color
                </label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORY_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCatColor(c)}
                      className={`w-6 h-6 rounded-full border-2 ${
                        catColor === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCatModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Subcategory Modal (Full Subcategory CRUD) */}
      {subParentCat && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingSub
                ? `Edit Subcategory "${editingSub.name}"`
                : `Add Subcategory under "${subParentCat.name}"`}
            </h3>
            <form onSubmit={handleSaveSubcategory} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Parent Category
                </label>
                <select
                  value={subTargetParentId || subParentCat.id}
                  onChange={(e) => setSubTargetParentId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {snapshot.categories
                    .filter((c) => c.type === subParentCat.type && !c.isArchived)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.groupName})
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Subcategory Name (English) *
                </label>
                <input
                  type="text"
                  required
                  value={subName}
                  onChange={(e) => setSubName(e.target.value)}
                  placeholder="e.g., Wife, Children, Parents, Mobile Recharge"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Subcategory Name (বাংলা)
                </label>
                <input
                  type="text"
                  value={subNameBn}
                  onChange={(e) => setSubNameBn(e.target.value)}
                  placeholder="যেমন: স্ত্রী, সন্তান, বাবা-মা"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Optional Monthly Limit (৳)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={subLimitStr}
                  onChange={(e) => setSubLimitStr(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex items-center justify-between pt-2">
                {editingSub ? (
                  <button
                    type="button"
                    onClick={() => handleArchiveOrDeleteSubcategory(editingSub)}
                    className="px-3 py-2 rounded-xl text-xs font-semibold bg-rose-50 text-rose-600"
                  >
                    {editingSub.isArchived ? 'Unarchive' : 'Archive'}
                  </button>
                ) : (
                  <span />
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingSub(null);
                      setSubParentCat(null);
                    }}
                    className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                  >
                    Add Subcategory
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Transaction History & Analytics Modal */}
      {historyCat && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {historyCat.name} ({historyCat.nameBn}) — Ledger History
                </h3>
                <p className="text-xs text-slate-500">Group: {historyCat.groupName}</p>
              </div>
              <button
                type="button"
                onClick={() => setHistoryCat(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto text-xs">
              {snapshot.transactions
                .filter(
                  (t) =>
                    t.categoryId === historyCat.id ||
                    snapshot.transactionSplits.some(
                      (s) => s.transactionId === t.id && s.categoryId === historyCat.id
                    )
                )
                .map((tx) => (
                  <div key={tx.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-100">
                        {tx.description}
                      </div>
                      <div className="text-[11px] text-slate-400">{tx.date}</div>
                    </div>
                    <div className="font-bold">{fmtMoney(tx.amountPoisha)}</div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Merge Categories Modal */}
      {isMergeOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              Merge Categories Safely
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              All historical transactions, splits, subcategories, and recurring rules from the source
              category will be moved to the destination category without losing any history.
            </p>
            <form onSubmit={handleMerge} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Source Category (will be archived after merge)
                </label>
                <select
                  required
                  value={mergeSourceId}
                  onChange={(e) => setMergeSourceId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="">-- Select Source --</option>
                  {snapshot.categories
                    .filter((c) => c.type === activeType && !c.isArchived)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Target Category (receives all history)
                </label>
                <select
                  required
                  value={mergeTargetId}
                  onChange={(e) => setMergeTargetId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="">-- Select Target --</option>
                  {snapshot.categories
                    .filter((c) => c.type === activeType && !c.isArchived && c.id !== mergeSourceId)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsMergeOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 text-white"
                >
                  Merge & Preserve History
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
