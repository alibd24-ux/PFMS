// ============================================================================
// PHASE 9: FINANCIAL REPORTS & INTERACTIVE ANALYTICS MODULE (15 REPORTS + 8 CHARTS)
// Implements all 15 requested reports:
// 1. Monthly, 2. Daily, 3. Weekly, 4. Yearly, 5. Custom Date, 6. Income,
// 7. Expense, 8. Category-wise, 9. Subcategory-wise, 10. Account-wise,
// 11. Budget Utilization, 12. Debt (Dena-Pawna), 13. Savings, 14. Cash Flow,
// 15. Net Worth Statement.
// Includes Interactive Chart Selector (Donut, Pie, Bar, Line, Income vs Expense,
// Monthly Spending Trends, Category Comparison, Budget Utilization) + Exports.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  FileText,
  PieChart as PieIcon,
  Printer,
  TrendingUp,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DatabaseSnapshot } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency } from '../utils/money';
import { PdfReportCenterModule } from '../pdf/components/PdfReportCenterModule';

export type ReportTypeKey =
  | 'monthly'
  | 'daily'
  | 'weekly'
  | 'yearly'
  | 'custom'
  | 'income'
  | 'expense'
  | 'category'
  | 'subcategory'
  | 'account'
  | 'budget'
  | 'debt'
  | 'savings'
  | 'cashflow'
  | 'networth';

export type ChartViewMode =
  | 'donut'
  | 'pie'
  | 'bar'
  | 'line'
  | 'income_vs_expense'
  | 'monthly_trends'
  | 'category_comparison'
  | 'budget_utilization';

export interface ReportsModuleProps {
  snapshot: DatabaseSnapshot;
}

const REPORT_TABS: Array<{ key: ReportTypeKey; label: string }> = [
  { key: 'monthly', label: '1. Monthly Report' },
  { key: 'daily', label: '2. Daily Report' },
  { key: 'weekly', label: '3. Weekly Report' },
  { key: 'yearly', label: '4. Yearly Report' },
  { key: 'custom', label: '5. Custom Date Report' },
  { key: 'income', label: '6. Income Report' },
  { key: 'expense', label: '7. Expense Report' },
  { key: 'category', label: '8. Category-wise' },
  { key: 'subcategory', label: '9. Subcategory-wise' },
  { key: 'account', label: '10. Account-wise' },
  { key: 'budget', label: '11. Budget Utilization' },
  { key: 'debt', label: '12. Debt (Dena-Pawna)' },
  { key: 'savings', label: '13. Savings Report' },
  { key: 'cashflow', label: '14. Cash Flow Trends' },
  { key: 'networth', label: '15. Net Worth Statement' },
];

export const ReportsModule: React.FC<ReportsModuleProps> = ({ snapshot }) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [activeReport, setActiveReport] = useState<ReportTypeKey>('monthly');
  const [chartMode, setChartMode] = useState<ChartViewMode>('income_vs_expense');
  const [dateFrom, setDateFrom] = useState('2026-10-01');
  const [dateTo, setDateTo] = useState('2026-11-30');

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const metrics = useMemo(
    () => FinancialEngine.computeDashboardMetrics(snapshot, dateFrom, dateTo),
    [snapshot, dateFrom, dateTo]
  );

  const activeBudgetEval = useMemo(() => {
    const b = snapshot.budgets[0];
    return b ? FinancialEngine.evaluateBudget(snapshot, b.id) : null;
  }, [snapshot]);

  // Category Breakdown
  const categoryBreakdown = useMemo(() => {
    const expMap = FinancialEngine.computeCategoryNetExpenses(snapshot, dateFrom, dateTo);
    return Object.entries(expMap)
      .map(([catId, poisha]) => {
        const cat = snapshot.categories.find((c) => c.id === catId);
        return {
          id: catId,
          name: cat?.name || catId,
          group: cat?.groupName || 'General',
          color: cat?.color || '#10b981',
          poisha,
          major: Math.round(poisha / 100),
        };
      })
      .sort((a, b) => b.poisha - a.poisha);
  }, [snapshot, dateFrom, dateTo]);

  // Subcategory Breakdown
  const subcategoryBreakdown = useMemo(() => {
    const subMap = FinancialEngine.computeSubcategoryNetExpenses(snapshot, dateFrom, dateTo);
    return Object.entries(subMap)
      .map(([subId, poisha]) => {
        const sub = snapshot.subcategories.find((s) => s.id === subId);
        const cat = sub ? snapshot.categories.find((c) => c.id === sub.categoryId) : null;
        return {
          id: subId,
          name: sub ? `${cat?.name || ''} › ${sub.name}` : subId,
          poisha,
          major: Math.round(poisha / 100),
        };
      })
      .sort((a, b) => b.poisha - a.poisha);
  }, [snapshot, dateFrom, dateTo]);

  // Period-grouped Trend Data (Daily / Weekly / Monthly / Yearly)
  const trendData = useMemo(() => {
    const map: Record<
      string,
      { period: string; income: number; expense: number; net: number; count: number }
    > = {};
    for (const tx of snapshot.transactions) {
      if (tx.date < dateFrom || tx.date > dateTo) continue;
      let key = tx.date;
      if (activeReport === 'monthly' || chartMode === 'monthly_trends') {
        key = tx.date.slice(0, 7); // YYYY-MM
      } else if (activeReport === 'yearly') {
        key = tx.date.slice(0, 4); // YYYY
      } else if (activeReport === 'weekly') {
        key = `${tx.date.slice(0, 7)}-W${Math.ceil(parseInt(tx.date.slice(8, 10), 10) / 7)}`;
      }
      if (!map[key]) map[key] = { period: key, income: 0, expense: 0, net: 0, count: 0 };
      map[key].count += 1;
      if (tx.type === 'income') map[key].income += Math.round(tx.amountPoisha / 100);
      if (tx.type === 'expense') map[key].expense += Math.round(tx.amountPoisha / 100);
      if (tx.type === 'refund') {
        map[key].expense = Math.max(0, map[key].expense - Math.round(tx.amountPoisha / 100));
      }
      map[key].net = map[key].income - map[key].expense;
    }
    return Object.values(map).sort((a, b) => a.period.localeCompare(b.period));
  }, [snapshot.transactions, dateFrom, dateTo, activeReport, chartMode]);

  // Budget Utilization Chart Data
  const budgetChartData = useMemo(() => {
    if (!activeBudgetEval) return [];
    return activeBudgetEval.categoryBreakdown.map((item) => ({
      name: item.categoryName,
      Planned: Math.round(item.allocatedPoisha / 100),
      Spent: Math.round(item.spentPoisha / 100),
      PrevMonth: Math.round(item.previousSpentPoisha / 100),
    }));
  }, [activeBudgetEval]);

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    try {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      // Ignored
    }
  };

  const handleExportCSV = () => {
    const csv = FinancialEngine.exportTransactionsToCSV(snapshot);
    downloadFile(
      csv,
      `takaflow_report_${activeReport}_${dateFrom}_${dateTo}.csv`,
      'text/csv;charset=utf-8;'
    );
  };

  const handleExportExcelTSV = () => {
    const csv = FinancialEngine.exportTransactionsToCSV(snapshot);
    downloadFile(
      '\uFEFF' + csv,
      `takaflow_excel_export_${dateFrom}_${dateTo}.csv`,
      'application/vnd.ms-excel;charset=utf-8;'
    );
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Header & Export Toolbar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Comprehensive Financial Reports & Visual Analytics (15 Reports)
            </h3>
            <p className="text-xs text-slate-500">
              Live database aggregation with interactive charts and CSV / Excel / PDF exports
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
            >
              <Download className="w-3.5 h-3.5" /> Export CSV
            </button>
            <button
              type="button"
              onClick={handleExportExcelTSV}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel-Compatible
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
            >
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </button>
          </div>
        </div>

        {/* Date Window Selector */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-500">From:</label>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-500">To:</label>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />
          </div>
        </div>

        {/* 15 Report Selector Pills */}
        <div className="flex flex-wrap gap-1.5 pt-2">
          {REPORT_TABS.map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveReport(tab.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                activeReport === tab.key
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Executive Summary KPI Row for Selected Window */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400">Period Income</div>
          <div className="text-lg font-bold text-emerald-600 mt-1">
            {fmtMoney(metrics.totalIncomePoisha)}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400">Period Expenses</div>
          <div className="text-lg font-bold text-rose-600 mt-1">
            {fmtMoney(metrics.totalExpensePoisha)}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400">Net Cash Flow</div>
          <div className="text-lg font-bold text-indigo-600 mt-1">
            {fmtMoney(metrics.netCashFlowPoisha)}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400">Net Worth</div>
          <div className="text-lg font-bold text-teal-600 mt-1">
            {fmtMoney(metrics.netWorthPoisha)}
          </div>
        </div>
      </div>

      {/* Interactive Chart Mode Switcher (All 8 Requested Chart Types) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
            Interactive Chart Visualizer
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {(
              [
                ['income_vs_expense', 'Income vs Expense'],
                ['monthly_trends', 'Monthly Spending Trends'],
                ['category_comparison', 'Category Comparison'],
                ['budget_utilization', 'Budget Utilization'],
                ['donut', 'Donut Chart'],
                ['pie', 'Pie Chart'],
                ['bar', 'Bar Chart'],
                ['line', 'Line Chart'],
              ] as Array<[ChartViewMode, string]>
            ).map(([cKey, cLabel]) => (
              <button
                key={cKey}
                type="button"
                onClick={() => setChartMode(cKey)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold ${
                  chartMode === cKey
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cLabel}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Left Chart Panel */}
          <div className="relative h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              {chartMode === 'line' || chartMode === 'monthly_trends' ? (
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis dataKey="period" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" dataKey="income" name="Income (৳)" stroke="#10b981" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="expense" name="Expense (৳)" stroke="#f43f5e" strokeWidth={2.5} />
                  <Line type="monotone" dataKey="net" name="Net Cash Flow (৳)" stroke="#6366f1" strokeWidth={2} />
                </LineChart>
              ) : chartMode === 'budget_utilization' ? (
                <BarChart data={budgetChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="Planned" name="Planned (৳)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Spent" name="Actual Spent (৳)" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              ) : chartMode === 'category_comparison' ? (
                <BarChart data={categoryBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="major" name="Category Spent (৳)" fill="#f97316" radius={[4, 4, 0, 0]} />
                </BarChart>
              ) : (
                <BarChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis dataKey="period" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="income" name="Income (৳)" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expense" name="Expense (৳)" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>

          {/* Right Chart Panel (Pie / Donut Category Distribution) */}
          <div className="relative h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryBreakdown}
                  dataKey="major"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={chartMode === 'pie' ? 0 : 48}
                  outerRadius={82}
                  paddingAngle={chartMode === 'pie' ? 1 : 3}
                >
                  {categoryBreakdown.map((item, idx) => (
                    <Cell key={idx} fill={item.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Detailed Tabular Report Based on Active Report Selection (All 15 Reports) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
        <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
          Detailed Breakdown — {REPORT_TABS.find((t) => t.key === activeReport)?.label}
        </h4>

        {activeReport === 'networth' ? (
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 flex justify-between">
              <span className="font-semibold">Total Active Account Balances (Assets)</span>
              <span className="font-bold text-emerald-700 dark:text-emerald-300">
                + {fmtMoney(metrics.totalBalancePoisha)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-sky-50 dark:bg-sky-950/40 flex justify-between">
              <span className="font-semibold">Total Receivables / Pawna (Assets)</span>
              <span className="font-bold text-sky-700 dark:text-sky-300">
                + {fmtMoney(metrics.totalReceivablePoisha)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 flex justify-between">
              <span className="font-semibold">Total Payables / Dena (Liabilities)</span>
              <span className="font-bold text-amber-700 dark:text-amber-300">
                - {fmtMoney(metrics.totalPayablePoisha)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 flex justify-between">
              <span className="font-semibold">Remaining Loan & EMI Principal (Liabilities)</span>
              <span className="font-bold text-rose-700 dark:text-rose-300">
                - {fmtMoney(metrics.remainingLoanLiabilityPoisha)}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 text-white flex justify-between text-sm font-bold">
              <span>Net Worth</span>
              <span>{fmtMoney(metrics.netWorthPoisha)}</span>
            </div>
          </div>
        ) : activeReport === 'subcategory' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {subcategoryBreakdown.map((item) => (
              <div key={item.id} className="py-2.5 flex justify-between">
                <span className="font-medium">{item.name}</span>
                <span className="font-bold">{fmtMoney(item.poisha)}</span>
              </div>
            ))}
          </div>
        ) : activeReport === 'account' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {snapshot.accounts.map((acc) => (
              <div key={acc.id} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold">{acc.name}</span>{' '}
                  <span className="text-slate-400">
                    ({acc.type} • Opening:{' '}
                    {formatCurrency(acc.openingBalancePoisha, {
                      currency: acc.currency,
                      numberFormat,
                      precision,
                    })}
                    )
                  </span>
                </div>
                <div className="font-bold">
                  {formatCurrency(acc.currentBalancePoisha, {
                    currency: acc.currency,
                    numberFormat,
                    precision,
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : activeReport === 'debt' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {snapshot.debts.map((d) => (
              <div key={d.id} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold">{d.personName}</span>{' '}
                  <span className="uppercase text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                    {d.direction === 'receivable' ? 'Pawna (Receivable)' : 'Dena (Payable)'}
                  </span>
                  <div className="text-[11px] text-slate-400">
                    Principal: {fmtMoney(d.principalPoisha)} • Settled: {fmtMoney(d.paidPoisha)} • Due:{' '}
                    {d.dueDate}
                  </div>
                </div>
                <div className="font-bold text-rose-600">{fmtMoney(d.remainingPoisha)}</div>
              </div>
            ))}
          </div>
        ) : activeReport === 'savings' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {snapshot.savingsGoals.map((g) => (
              <div key={g.id} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold">{g.name}</span>
                  <div className="text-[11px] text-slate-400">
                    Target: {fmtMoney(g.targetAmountPoisha)} by {g.targetDate}
                  </div>
                </div>
                <div className="font-bold text-teal-600">{fmtMoney(g.savedAmountPoisha)}</div>
              </div>
            ))}
          </div>
        ) : activeReport === 'budget' && activeBudgetEval ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {activeBudgetEval.categoryBreakdown.map((b) => (
              <div key={b.categoryId} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold">{b.categoryName}</span>
                  <div className="text-[11px] text-slate-400">
                    Planned: {fmtMoney(b.allocatedPoisha)} • Remaining: {fmtMoney(b.remainingPoisha)}
                  </div>
                </div>
                <div className="font-bold">
                  {fmtMoney(b.spentPoisha)} ({b.percentUsed.toFixed(1)}%)
                </div>
              </div>
            ))}
          </div>
        ) : activeReport === 'income' || activeReport === 'expense' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {snapshot.transactions
              .filter(
                (tx) =>
                  tx.date >= dateFrom &&
                  tx.date <= dateTo &&
                  (activeReport === 'income'
                    ? tx.type === 'income'
                    : tx.type === 'expense' || tx.type === 'refund')
              )
              .map((tx) => (
                <div key={tx.id} className="py-2.5 flex justify-between items-center">
                  <div>
                    <span className="font-bold">{tx.description}</span>
                    <div className="text-[11px] text-slate-400">
                      {tx.date} • {tx.paymentMethod}
                    </div>
                  </div>
                  <div
                    className={`font-bold ${
                      tx.type === 'income' || tx.type === 'refund'
                        ? 'text-emerald-600'
                        : 'text-rose-600'
                    }`}
                  >
                    {fmtMoney(tx.amountPoisha)}
                  </div>
                </div>
              ))}
          </div>
        ) : activeReport === 'daily' ||
          activeReport === 'weekly' ||
          activeReport === 'monthly' ||
          activeReport === 'yearly' ||
          activeReport === 'cashflow' ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {trendData.map((row) => (
              <div key={row.period} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold">{row.period}</span>{' '}
                  <span className="text-slate-400">({row.count} entries)</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-emerald-600 font-semibold">
                    + {fmtMoney(row.income * 100)}
                  </span>
                  <span className="text-rose-600 font-semibold">
                    - {fmtMoney(row.expense * 100)}
                  </span>
                  <span className="font-bold">Net: {fmtMoney(row.net * 100)}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {categoryBreakdown.map((item) => (
              <div key={item.id} className="py-2.5 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="font-bold">{item.name}</span>
                  <span className="text-slate-400">({item.group})</span>
                </div>
                <div className="font-bold">{fmtMoney(item.poisha)}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* GLOBAL PDF REPORT CENTER & FINANCIAL STATEMENT SYSTEM */}
      <PdfReportCenterModule snapshot={snapshot} />
    </div>
  );
};
