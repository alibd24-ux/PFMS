// ============================================================================
// PHASE 3, 4, 5 & 13: TRANSACTION, INCOME, EXPENSE & MONEY TRANSFER MODULE
// Supports all 8 transaction types (Income, Expense, Transfer, Refund,
// Loan Received, Loan Given, Debt Repayment, Debt Collection), Dedicated
// Income Management, Expense Management (with 1-click Refund reversal & Splits),
// Money Transfer Ledger, Receipt attachments, Tags, Duplicate, Edit, Delete
// with confirmation, and Multi-filter Global Search with Saved Presets.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRightLeft,
  ArrowUpRight,
  Bookmark,
  Copy,
  Edit3,
  FileText,
  Filter,
  Paperclip,
  Plus,
  RotateCcw,
  Search,
  Split,
  Tag,
  Trash2,
} from 'lucide-react';
import {
  DatabaseSnapshot,
  FilterPreset,
  Transaction,
  TransactionType,
} from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, MoneyMath, poishaToMajorString, toPoisha } from '../utils/money';

export interface TransactionsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
  onOpenModalForEdit: (tx: Transaction) => void;
  onOpenNewTransactionModal: (defaultType?: TransactionType) => void;
}

export const TransactionsModule: React.FC<TransactionsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
  onOpenModalForEdit,
  onOpenNewTransactionModal,
}) => {
  const lang = snapshot.settings.language;
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  // Dedicated Sub-View Mode: All Ledger | Income Management | Expense Management | Money Transfer
  const [ledgerMode, setLedgerMode] = useState<'all' | 'income' | 'expense' | 'transfer'>('all');

  // Advanced Multi-Filter State (Section 13)
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<TransactionType | 'all'>('all');
  const [accountFilter, setAccountFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [subcategoryFilter, setSubcategoryFilter] = useState<string>('all');
  const [personFilter, setPersonFilter] = useState<string>('');
  const [tagFilter, setTagFilter] = useState<string>('');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [minAmount, setMinAmount] = useState<string>('');
  const [maxAmount, setMaxAmount] = useState<string>('');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc' | 'category'>('date_desc');

  // Saved Filter Presets
  const [presets, setPresets] = useState<FilterPreset[]>([
    {
      id: 'preset_nov_exp',
      name: 'Nov 2026 Expenses',
      searchQuery: '',
      type: 'expense',
      accountId: 'all',
      categoryId: 'all',
      subcategoryId: 'all',
      person: '',
      tag: '',
      dateFrom: '2026-11-01',
      dateTo: '2026-11-30',
      minAmount: '',
      maxAmount: '',
    },
    {
      id: 'preset_high_value',
      name: 'High Value (> ৳4,000)',
      searchQuery: '',
      type: 'all',
      accountId: 'all',
      categoryId: 'all',
      subcategoryId: 'all',
      person: '',
      tag: '',
      dateFrom: '',
      dateTo: '',
      minAmount: '4000',
      maxAmount: '',
    },
  ]);
  const [presetNameInput, setPresetNameInput] = useState('');
  const [confirmDeleteTx, setConfirmDeleteTx] = useState<Transaction | null>(null);
  const [detailTx, setDetailTx] = useState<Transaction | null>(null);

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const switchLedgerMode = (mode: 'all' | 'income' | 'expense' | 'transfer') => {
    setLedgerMode(mode);
    if (mode === 'all') setTypeFilter('all');
    if (mode === 'income') setTypeFilter('income');
    if (mode === 'expense') setTypeFilter('expense');
    if (mode === 'transfer') setTypeFilter('transfer');
  };

  const applyPreset = (p: FilterPreset) => {
    setLedgerMode('all');
    setSearchQuery(p.searchQuery);
    setTypeFilter(p.type);
    setAccountFilter(p.accountId);
    setCategoryFilter(p.categoryId);
    setSubcategoryFilter(p.subcategoryId);
    setPersonFilter(p.person);
    setTagFilter(p.tag);
    setDateFrom(p.dateFrom);
    setDateTo(p.dateTo);
    setMinAmount(p.minAmount);
    setMaxAmount(p.maxAmount);
  };

  const saveCurrentPreset = () => {
    if (!presetNameInput.trim()) return;
    const newPreset: FilterPreset = {
      id: `preset_${Date.now()}`,
      name: presetNameInput.trim(),
      searchQuery,
      type: typeFilter,
      accountId: accountFilter,
      categoryId: categoryFilter,
      subcategoryId: subcategoryFilter,
      person: personFilter,
      tag: tagFilter,
      dateFrom,
      dateTo,
      minAmount,
      maxAmount,
    };
    setPresets([...presets, newPreset]);
    setPresetNameInput('');
  };

  const resetFilters = () => {
    setLedgerMode('all');
    setSearchQuery('');
    setTypeFilter('all');
    setAccountFilter('all');
    setCategoryFilter('all');
    setSubcategoryFilter('all');
    setPersonFilter('');
    setTagFilter('');
    setDateFrom('');
    setDateTo('');
    setMinAmount('');
    setMaxAmount('');
  };

  const filteredTransactions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const minP = minAmount ? toPoisha(minAmount) : 0;
    const maxP = maxAmount ? toPoisha(maxAmount) : Number.MAX_SAFE_INTEGER;

    return snapshot.transactions
      .filter((tx) => {
        if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
        if (
          accountFilter !== 'all' &&
          tx.accountId !== accountFilter &&
          tx.destinationAccountId !== accountFilter
        ) {
          return false;
        }
        if (categoryFilter !== 'all' && tx.categoryId !== categoryFilter) {
          const hasSplitCat = snapshot.transactionSplits.some(
            (s) => s.transactionId === tx.id && s.categoryId === categoryFilter
          );
          if (!hasSplitCat) return false;
        }
        if (subcategoryFilter !== 'all' && tx.subcategoryId !== subcategoryFilter) return false;
        if (dateFrom && tx.date < dateFrom) return false;
        if (dateTo && tx.date > dateTo) return false;
        if (tx.amountPoisha < minP || tx.amountPoisha > maxP) return false;
        if (
          personFilter.trim() &&
          !(tx.personName || '').toLowerCase().includes(personFilter.trim().toLowerCase())
        ) {
          return false;
        }
        if (
          tagFilter.trim() &&
          !(tx.tags || []).some((t) => t.toLowerCase().includes(tagFilter.trim().toLowerCase()))
        ) {
          return false;
        }
        if (q) {
          const catName =
            snapshot.categories.find((c) => c.id === tx.categoryId)?.name.toLowerCase() || '';
          const accName =
            snapshot.accounts.find((a) => a.id === tx.accountId)?.name.toLowerCase() || '';
          const amtStr = poishaToMajorString(tx.amountPoisha, 2);
          const hay = [
            tx.description,
            tx.notes,
            tx.personName || '',
            ...(tx.tags || []),
            catName,
            accName,
            amtStr,
          ]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`);
        if (sortBy === 'date_asc') return `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`);
        if (sortBy === 'amount_desc') return b.amountPoisha - a.amountPoisha;
        if (sortBy === 'amount_asc') return a.amountPoisha - b.amountPoisha;
        return a.categoryId.localeCompare(b.categoryId);
      });
  }, [
    snapshot.transactions,
    snapshot.transactionSplits,
    snapshot.categories,
    snapshot.accounts,
    searchQuery,
    typeFilter,
    accountFilter,
    categoryFilter,
    subcategoryFilter,
    personFilter,
    tagFilter,
    dateFrom,
    dateTo,
    minAmount,
    maxAmount,
    sortBy,
  ]);

  // Filtered Summary Totals (Income, Expense, Transfer Volume)
  const filteredSummary = useMemo(() => {
    let incomePoisha = 0;
    let expensePoisha = 0;
    let refundPoisha = 0;
    let transferPoisha = 0;

    for (const tx of filteredTransactions) {
      if (tx.type === 'income') incomePoisha = MoneyMath.add(incomePoisha, tx.amountPoisha);
      else if (tx.type === 'expense') expensePoisha = MoneyMath.add(expensePoisha, tx.amountPoisha);
      else if (tx.type === 'refund') refundPoisha = MoneyMath.add(refundPoisha, tx.amountPoisha);
      else if (tx.type === 'transfer') transferPoisha = MoneyMath.add(transferPoisha, tx.amountPoisha);
    }

    const netExpensePoisha = Math.max(0, MoneyMath.subtract(expensePoisha, refundPoisha));
    return {
      incomePoisha,
      expensePoisha,
      refundPoisha,
      netExpensePoisha,
      transferPoisha,
      netFlowPoisha: MoneyMath.subtract(incomePoisha, netExpensePoisha),
    };
  }, [filteredTransactions]);

  const handleDuplicate = (tx: Transaction) => {
    const splits = snapshot.transactionSplits
      .filter((s) => s.transactionId === tx.id)
      .map((s) => ({
        categoryId: s.categoryId,
        subcategoryId: s.subcategoryId,
        amountPoisha: s.amountPoisha,
        note: s.note,
      }));
    const res = FinancialEngine.upsertTransaction(snapshot, {
      ...tx,
      id: undefined,
      description: `${tx.description} (Copy)`,
      splits,
      allowDuplicate: true,
    });
    if (res.ok) {
      onUpdateSnapshot(res.snapshot, `Duplicated transaction "${tx.description}".`);
    }
  };

  const handleQuickRefundExpense = (tx: Transaction) => {
    if (tx.type !== 'expense') return;
    const res = FinancialEngine.upsertTransaction(snapshot, {
      type: 'refund',
      amountPoisha: tx.amountPoisha,
      currency: tx.currency,
      exchangeRateToBase: tx.exchangeRateToBase,
      date: '2026-11-06',
      time: '15:30',
      accountId: tx.accountId,
      categoryId: tx.categoryId,
      subcategoryId: tx.subcategoryId,
      linkedTransactionId: tx.id,
      description: `Refund: ${tx.description}`,
      notes: `Reversed expense ${tx.id}`,
      tags: ['refund'],
      paymentMethod: tx.paymentMethod,
      isSplit: false,
      allowDuplicate: true,
    });
    if (res.ok) {
      onUpdateSnapshot(
        res.snapshot,
        `Recorded refund for "${tx.description}" and reversed expense impact.`
      );
    }
  };

  const handleConfirmDelete = () => {
    if (!confirmDeleteTx) return;
    const next = FinancialEngine.deleteTransaction(snapshot, confirmDeleteTx.id);
    onUpdateSnapshot(next, `Deleted "${confirmDeleteTx.description}" and reversed balance impact.`);
    setConfirmDeleteTx(null);
  };

  return (
    <div className="space-y-5 pb-8">
      {/* Dedicated Mode Selector: All Ledger | Income Management | Expense Management | Money Transfer */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => switchLedgerMode('all')}
          className={`text-left p-4 rounded-2xl border transition-all ${
            ledgerMode === 'all'
              ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 shadow-md'
              : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
          }`}
        >
          <div className="text-[11px] font-semibold uppercase opacity-75">All Ledger Entries</div>
          <div className="text-lg font-bold mt-1">{fmtMoney(filteredSummary.netFlowPoisha)}</div>
          <div className="text-[11px] opacity-70 mt-0.5">
            {filteredTransactions.length} matching records
          </div>
        </button>

        <button
          type="button"
          onClick={() => switchLedgerMode('income')}
          className={`text-left p-4 rounded-2xl border transition-all ${
            ledgerMode === 'income'
              ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
              : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase opacity-80">Income Management</span>
            <ArrowUpRight className="w-4 h-4" />
          </div>
          <div className="text-lg font-bold mt-1">{fmtMoney(filteredSummary.incomePoisha)}</div>
          <div className="text-[11px] opacity-75 mt-0.5">Click to manage incomes</div>
        </button>

        <button
          type="button"
          onClick={() => switchLedgerMode('expense')}
          className={`text-left p-4 rounded-2xl border transition-all ${
            ledgerMode === 'expense'
              ? 'bg-rose-600 text-white border-rose-600 shadow-md'
              : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase opacity-80">Expense Management</span>
            <ArrowDownRight className="w-4 h-4" />
          </div>
          <div className="text-lg font-bold mt-1">{fmtMoney(filteredSummary.netExpensePoisha)}</div>
          <div className="text-[11px] opacity-75 mt-0.5">
            Refunds deducted: {fmtMoney(filteredSummary.refundPoisha)}
          </div>
        </button>

        <button
          type="button"
          onClick={() => switchLedgerMode('transfer')}
          className={`text-left p-4 rounded-2xl border transition-all ${
            ledgerMode === 'transfer'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
              : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase opacity-80">Money Transfers</span>
            <ArrowRightLeft className="w-4 h-4" />
          </div>
          <div className="text-lg font-bold mt-1">{fmtMoney(filteredSummary.transferPoisha)}</div>
          <div className="text-[11px] opacity-75 mt-0.5">Excluded from Income/Expense</div>
        </button>
      </div>

      {/* Global Search & Multi-Filter Control Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Transaction Ledger & Advanced Search
            </h3>
            <p className="text-xs text-slate-500">
              Showing {filteredTransactions.length} of {snapshot.transactions.length} verified entries
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onOpenNewTransactionModal('income')}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" /> Add Income
            </button>
            <button
              type="button"
              onClick={() => onOpenNewTransactionModal('transfer')}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs font-semibold"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" /> New Transfer
            </button>
            <button
              type="button"
              onClick={() => onOpenNewTransactionModal('expense')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" /> Add Transaction
            </button>
            <button
              type="button"
              onClick={resetFilters}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Filters
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by description, notes, person, tags, category, account, or amount..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70"
          />
        </div>

        {/* Multi-Filter Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          <select
            value={typeFilter}
            onChange={(e) => {
              const v = e.target.value as any;
              setTypeFilter(v);
              if (v === 'income' || v === 'expense' || v === 'transfer' || v === 'all') {
                setLedgerMode(v);
              }
            }}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">All Types (8)</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
            <option value="transfer">Transfer</option>
            <option value="refund">Refund</option>
            <option value="loan_given">Loan Given (Pawna)</option>
            <option value="loan_received">Loan Received (Dena)</option>
            <option value="debt_collection">Debt Collection</option>
            <option value="debt_repayment">Debt Repayment</option>
          </select>

          <select
            value={accountFilter}
            onChange={(e) => setAccountFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">All Accounts</option>
            {snapshot.accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setSubcategoryFilter('all');
            }}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">All Categories</option>
            {snapshot.categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.type})
              </option>
            ))}
          </select>

          <select
            value={subcategoryFilter}
            onChange={(e) => setSubcategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">All Subcategories</option>
            {snapshot.subcategories
              .filter((s) => categoryFilter === 'all' || s.categoryId === categoryFilter)
              .map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
          </select>

          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            title="Start Date"
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />

          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            title="End Date"
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <input
            type="text"
            value={personFilter}
            onChange={(e) => setPersonFilter(e.target.value)}
            placeholder="Filter by Person/Contact..."
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />
          <input
            type="text"
            value={tagFilter}
            onChange={(e) => setTagFilter(e.target.value)}
            placeholder="Filter by #tag..."
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />
          <input
            type="number"
            value={minAmount}
            onChange={(e) => setMinAmount(e.target.value)}
            placeholder="Min Amount (৳)"
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />
          <input
            type="number"
            value={maxAmount}
            onChange={(e) => setMaxAmount(e.target.value)}
            placeholder="Max Amount (৳)"
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="date_desc">Sort: Newest First</option>
            <option value="date_asc">Sort: Oldest First</option>
            <option value="amount_desc">Sort: Highest Amount</option>
            <option value="amount_asc">Sort: Lowest Amount</option>
            <option value="category">Sort: By Category</option>
          </select>
        </div>

        {/* Saved Filter Presets Bar */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Bookmark className="w-3 h-3" /> Presets:
            </span>
            {presets.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => applyPreset(p)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 text-[11px] font-medium text-slate-700 dark:text-slate-300"
              >
                {p.name}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              value={presetNameInput}
              onChange={(e) => setPresetNameInput(e.target.value)}
              placeholder="Save filter preset name..."
              className="px-2.5 py-1 text-[11px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />
            <button
              type="button"
              onClick={saveCurrentPreset}
              className="px-2.5 py-1 rounded-lg bg-slate-800 text-white text-[11px] font-medium"
            >
              Save Preset
            </button>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
        {filteredTransactions.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            No transactions match the active filters.
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
            const sub = tx.subcategoryId
              ? snapshot.subcategories.find((s) => s.id === tx.subcategoryId)
              : null;
            const acc = snapshot.accounts.find((a) => a.id === tx.accountId);
            const destAcc = tx.destinationAccountId
              ? snapshot.accounts.find((a) => a.id === tx.destinationAccountId)
              : null;
            const splits = tx.isSplit
              ? snapshot.transactionSplits.filter((s) => s.transactionId === tx.id)
              : [];
            const attachment = tx.attachmentId
              ? snapshot.attachments.find((at) => at.id === tx.attachmentId)
              : null;
            const isPositive =
              tx.type === 'income' ||
              tx.type === 'refund' ||
              tx.type === 'loan_received' ||
              tx.type === 'debt_collection';

            return (
              <div
                key={tx.id}
                className="p-4 hover:bg-slate-50/70 dark:hover:bg-slate-800/30 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5"
                    style={{ backgroundColor: cat?.color || '#10b981' }}
                  >
                    {tx.type.slice(0, 3).toUpperCase()}
                  </div>
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span
                        onClick={() => setDetailTx(tx)}
                        className="cursor-pointer text-sm font-bold text-slate-900 dark:text-white hover:text-emerald-600"
                      >
                        {tx.description}
                      </span>
                      <span className="px-2 py-0.5 text-[10px] font-semibold uppercase rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                        {tx.type.replace('_', ' ')}
                      </span>
                      {tx.isSplit && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center gap-1">
                          <Split className="w-2.5 h-2.5" /> {splits.length} Splits
                        </span>
                      )}
                      {attachment && (
                        <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 flex items-center gap-1">
                          <Paperclip className="w-2.5 h-2.5" /> Receipt
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span>
                        {tx.date} at {tx.time}
                      </span>
                      <span>•</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {tx.type === 'transfer'
                          ? `${acc?.name || tx.accountId} → ${destAcc?.name || tx.destinationAccountId}`
                          : acc?.name || tx.accountId}
                      </span>
                      {tx.type !== 'transfer' && (
                        <>
                          <span>•</span>
                          <span>
                            {cat ? (lang === 'bn' ? cat.nameBn : cat.name) : tx.categoryId}
                            {sub ? ` › ${sub.name}` : ''}
                          </span>
                        </>
                      )}
                      {tx.personName && (
                        <>
                          <span>•</span>
                          <span className="text-sky-600 dark:text-sky-400 font-medium">
                            👤 {tx.personName}
                          </span>
                        </>
                      )}
                    </div>

                    {tx.tags && tx.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {tx.tags.map((tag) => (
                          <span
                            key={tag}
                            className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                  <div className="text-right">
                    <div
                      className={`text-sm font-bold ${
                        tx.type === 'transfer'
                          ? 'text-indigo-600 dark:text-indigo-400'
                          : isPositive
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {tx.type === 'transfer'
                        ? `⇄ ${formatCurrency(tx.amountPoisha, {
                            currency: tx.currency,
                            numberFormat,
                            precision,
                          })}`
                        : `${isPositive ? '+' : '-'} ${formatCurrency(tx.amountPoisha, {
                            currency: tx.currency,
                            numberFormat,
                            precision,
                          })}`}
                    </div>
                    <div className="text-[10px] text-slate-400">{tx.paymentMethod}</div>
                  </div>

                  <div className="flex items-center gap-1">
                    {tx.type === 'expense' && (
                      <button
                        type="button"
                        onClick={() => handleQuickRefundExpense(tx)}
                        title="Record Refund Reversal"
                        className="px-2 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 text-[10px] font-semibold"
                      >
                        Refund
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenModalForEdit(tx)}
                      title="Edit Transaction"
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDuplicate(tx)}
                      title="Duplicate Transaction"
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteTx(tx)}
                      title="Delete Transaction"
                      className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Transaction Details Modal */}
      {detailTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Transaction Audit Details
              </h3>
              <button
                type="button"
                onClick={() => setDetailTx(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>
            <div className="text-xs space-y-2 text-slate-600 dark:text-slate-300">
              <div>
                <strong>ID:</strong> {detailTx.id}
              </div>
              <div>
                <strong>Description:</strong> {detailTx.description}
              </div>
              <div>
                <strong>Type:</strong> {detailTx.type.toUpperCase()}
              </div>
              <div>
                <strong>Amount:</strong>{' '}
                {formatCurrency(detailTx.amountPoisha, {
                  currency: detailTx.currency,
                  numberFormat,
                  precision,
                })}
              </div>
              <div>
                <strong>Date & Time:</strong> {detailTx.date} {detailTx.time}
              </div>
              <div>
                <strong>Notes:</strong> {detailTx.notes || 'None'}
              </div>
              <div>
                <strong>Created:</strong> {detailTx.createdAt}
              </div>
              <div>
                <strong>Updated:</strong> {detailTx.updatedAt}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Delete Transaction?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Deleting <strong>"{confirmDeleteTx.description}"</strong> (
              {formatCurrency(confirmDeleteTx.amountPoisha, {
                currency: confirmDeleteTx.currency,
                numberFormat,
                precision,
              })}
              ) will automatically reverse its financial impact across your account balances and
              budgets.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteTx(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
