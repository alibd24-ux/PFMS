// ============================================================================
// PHASE 2 & 5: ACCOUNT MANAGEMENT MODULE
// Supports unlimited custom accounts, editing, archiving, opening balance,
// account-wise transaction history, inter-account transfers, balance alerts,
// multi-currency, and safe archival protection when transaction history exists.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  ArrowRightLeft,
  CheckCircle2,
  Edit3,
  History,
  Plus,
  RotateCcw,
  Trash2,
  Wallet,
} from 'lucide-react';
import { Account, AccountType, CurrencyCode, DatabaseSnapshot, Transaction } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, MoneyMath, poishaToMajorString, toPoisha } from '../utils/money';

export interface AccountsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
  onOpenTransferModal: (fromAccountId?: string) => void;
}

const ACCOUNT_COLORS = [
  '#10b981',
  '#3b82f6',
  '#0d9488',
  '#8b5cf6',
  '#e11d48',
  '#f97316',
  '#7c3aed',
  '#64748b',
];

export const AccountsModule: React.FC<AccountsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
  onOpenTransferModal,
}) => {
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;
  const baseCurrency = snapshot.settings.defaultCurrency;

  const [showArchived, setShowArchived] = useState(false);
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteDialogAcc, setDeleteDialogAcc] = useState<Account | null>(null);
  const [migrateTargetAccId, setMigrateTargetAccId] = useState<string>('');

  // Form state
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [type, setType] = useState<AccountType>('bank');
  const [openingBalanceStr, setOpeningBalanceStr] = useState('0');
  const [currency, setCurrency] = useState<CurrencyCode>('BDT');
  const [color, setColor] = useState('#10b981');
  const [alertThresholdStr, setAlertThresholdStr] = useState('1000');
  const [description, setDescription] = useState('');

  const openCreateModal = () => {
    setEditingAccount(null);
    setName('');
    setNameBn('');
    setType('bank');
    setOpeningBalanceStr('0');
    setCurrency(baseCurrency);
    setColor('#10b981');
    setAlertThresholdStr('1000');
    setDescription('');
    setIsModalOpen(true);
  };

  const openEditModal = (acc: Account) => {
    setEditingAccount(acc);
    setName(acc.name);
    setNameBn(acc.nameBn || '');
    setType(acc.type);
    setOpeningBalanceStr(poishaToMajorString(acc.openingBalancePoisha, 2));
    setCurrency(acc.currency);
    setColor(acc.color);
    setAlertThresholdStr(poishaToMajorString(acc.alertThresholdPoisha, 2));
    setDescription(acc.description || '');
    setIsModalOpen(true);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const now = new Date().toISOString();
    const openingBalancePoisha = toPoisha(openingBalanceStr);
    const alertThresholdPoisha = Math.max(0, toPoisha(alertThresholdStr));

    let nextAccounts: Account[];
    if (editingAccount) {
      nextAccounts = snapshot.accounts.map((a) =>
        a.id === editingAccount.id
          ? {
              ...a,
              name: name.trim(),
              nameBn: nameBn.trim() || name.trim(),
              type,
              openingBalancePoisha,
              currency,
              color,
              alertThresholdPoisha,
              description: description.trim(),
              updatedAt: now,
            }
          : a
      );
    } else {
      const newAcc: Account = {
        id: `acc_${Date.now()}`,
        name: name.trim(),
        nameBn: nameBn.trim() || name.trim(),
        type,
        openingBalancePoisha,
        currentBalancePoisha: openingBalancePoisha,
        currency,
        icon: 'Wallet',
        color,
        description: description.trim(),
        alertThresholdPoisha,
        status: 'active',
        createdAt: now,
        updatedAt: now,
      };
      nextAccounts = [...snapshot.accounts, newAcc];
    }

    const nextSnapshot = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      accounts: nextAccounts,
    });
    onUpdateSnapshot(
      nextSnapshot,
      editingAccount ? `Account "${name}" updated and balances recalculated.` : `Account "${name}" created.`
    );
    setIsModalOpen(false);
  };

  const toggleArchiveAccount = (acc: Account) => {
    const nextStatus = acc.status === 'active' ? 'archived' : 'active';
    const nextSnapshot = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      accounts: snapshot.accounts.map((a) =>
        a.id === acc.id ? { ...a, status: nextStatus, updatedAt: new Date().toISOString() } : a
      ),
    });
    onUpdateSnapshot(
      nextSnapshot,
      `Account "${acc.name}" ${nextStatus === 'archived' ? 'archived' : 'restored'}.`
    );
  };

  const handleConfirmDeleteOrMigrate = () => {
    if (!deleteDialogAcc) return;
    const txCount = snapshot.transactions.filter(
      (t) => t.accountId === deleteDialogAcc.id || t.destinationAccountId === deleteDialogAcc.id
    ).length;

    if (txCount > 0 && !migrateTargetAccId) {
      return;
    }

    const updatedTransactions =
      txCount > 0
        ? snapshot.transactions.map((t) => ({
            ...t,
            accountId: t.accountId === deleteDialogAcc.id ? migrateTargetAccId : t.accountId,
            destinationAccountId:
              t.destinationAccountId === deleteDialogAcc.id ? migrateTargetAccId : t.destinationAccountId,
          }))
        : snapshot.transactions;

    const nextSnapshot = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: updatedTransactions,
      accounts: snapshot.accounts.filter((a) => a.id !== deleteDialogAcc.id),
    });
    onUpdateSnapshot(
      nextSnapshot,
      txCount > 0
        ? `Migrated ${txCount} transactions and deleted "${deleteDialogAcc.name}".`
        : `Deleted account "${deleteDialogAcc.name}".`
    );
    setDeleteDialogAcc(null);
    setMigrateTargetAccId('');
  };

  const totalConvertedPoisha = useMemo(() => {
    return snapshot.accounts
      .filter((a) => a.status === 'active')
      .reduce(
        (sum, acc) =>
          sum +
          MoneyMath.convertToBase(
            acc.currentBalancePoisha,
            acc.currency,
            baseCurrency,
            snapshot.settings.exchangeRates
          ),
        0
      );
  }, [snapshot, baseCurrency]);

  const visibleAccounts = snapshot.accounts.filter((a) =>
    showArchived ? true : a.status === 'active'
  );

  const accountTransactions = useMemo(() => {
    if (!selectedAccountId) return [];
    return snapshot.transactions
      .filter(
        (t) => t.accountId === selectedAccountId || t.destinationAccountId === selectedAccountId
      )
      .sort((a, b) => `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`));
  }, [snapshot.transactions, selectedAccountId]);

  return (
    <div className="space-y-6 pb-8">
      {/* Header Summary Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Total Consolidated Balance ({baseCurrency})
          </span>
          <div className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            {formatCurrency(totalConvertedPoisha, {
              currency: baseCurrency,
              numberFormat,
              precision,
            })}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Calculated strictly from opening balances + verified ledger transactions
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onOpenTransferModal()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" /> Transfer Between Accounts
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5" /> Add Account
          </button>
          <button
            type="button"
            onClick={() => setShowArchived(!showArchived)}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300"
          >
            {showArchived ? 'Hide Archived' : 'Show Archived'}
          </button>
        </div>
      </div>

      {/* Account Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleAccounts.map((acc) => {
          const isLow =
            acc.alertThresholdPoisha > 0 && acc.currentBalancePoisha < acc.alertThresholdPoisha;
          const txCount = snapshot.transactions.filter(
            (t) => t.accountId === acc.id || t.destinationAccountId === acc.id
          ).length;

          return (
            <div
              key={acc.id}
              className={`bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border transition-all ${
                selectedAccountId === acc.id
                  ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                  : 'border-slate-200/80 dark:border-slate-800'
              } ${acc.status === 'archived' ? 'opacity-60' : ''}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm"
                    style={{ backgroundColor: acc.color }}
                  >
                    {acc.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>{acc.name}</span>
                      {acc.status === 'archived' && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                          Archived
                        </span>
                      )}
                    </h4>
                    <span className="text-[11px] uppercase tracking-wider text-slate-400">
                      {acc.type.replace('_', ' ')} • {acc.currency}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => openEditModal(acc)}
                    title="Edit Account"
                    className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleArchiveAccount(acc)}
                    title={acc.status === 'active' ? 'Archive Account' : 'Unarchive Account'}
                    className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Archive className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDeleteDialogAcc(acc);
                      setMigrateTargetAccId('');
                    }}
                    title="Delete or Migrate Account"
                    className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="mt-4">
                <div className="text-xs text-slate-400">Current Ledger Balance</div>
                <div className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
                  {formatCurrency(acc.currentBalancePoisha, {
                    currency: acc.currency,
                    numberFormat,
                    precision,
                  })}
                </div>
                <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                  <span>
                    Opening:{' '}
                    {formatCurrency(acc.openingBalancePoisha, {
                      currency: acc.currency,
                      numberFormat,
                      precision,
                    })}
                  </span>
                  <span>{txCount} txns</span>
                </div>
              </div>

              {isLow && (
                <div className="mt-3 px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 text-[11px] flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    Below alert threshold (
                    {formatCurrency(acc.alertThresholdPoisha, {
                      currency: acc.currency,
                      numberFormat,
                      precision,
                    })}
                    )
                  </span>
                </div>
              )}

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() =>
                    setSelectedAccountId(selectedAccountId === acc.id ? null : acc.id)
                  }
                  className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
                >
                  <History className="w-3.5 h-3.5" />
                  {selectedAccountId === acc.id ? 'Hide History' : 'View Statement'}
                </button>
                <button
                  type="button"
                  onClick={() => onOpenTransferModal(acc.id)}
                  className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Transfer ⇄
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Account-wise Transaction History Drawer/Section */}
      {selectedAccountId && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Account Ledger Statement —{' '}
              {snapshot.accounts.find((a) => a.id === selectedAccountId)?.name} (
              {accountTransactions.length} entries)
            </h3>
            <button
              type="button"
              onClick={() => setSelectedAccountId(null)}
              className="text-xs text-slate-500 hover:underline"
            >
              Close Statement
            </button>
          </div>
          {accountTransactions.length === 0 ? (
            <div className="text-xs text-slate-400 py-6 text-center">
              No transactions recorded for this account yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-80 overflow-y-auto">
              {accountTransactions.map((tx) => {
                const isInflow =
                  (tx.type === 'transfer' && tx.destinationAccountId === selectedAccountId) ||
                  tx.type === 'income' ||
                  tx.type === 'refund' ||
                  tx.type === 'loan_received' ||
                  tx.type === 'debt_collection';
                return (
                  <div key={tx.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-100">
                        {tx.description}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {tx.date} {tx.time} • {tx.type.toUpperCase()}
                      </div>
                    </div>
                    <div
                      className={`font-bold ${
                        isInflow ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {isInflow ? '+' : '-'}{' '}
                      {formatCurrency(tx.amountPoisha, {
                        currency: tx.currency,
                        numberFormat,
                        precision,
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Create / Edit Account Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              {editingAccount ? 'Edit Account' : 'Create New Account / Wallet'}
            </h3>
            <form onSubmit={handleSaveAccount} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Account Name (English) *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., BRAC Bank Salary, bKash Personal"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Account Name (বাংলা - Optional)
                </label>
                <input
                  type="text"
                  value={nameBn}
                  onChange={(e) => setNameBn(e.target.value)}
                  placeholder="যেমন: ব্র্যাক ব্যাংক, বিকাশ"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Account Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as AccountType)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="cash">Cash</option>
                    <option value="bank">Bank Account</option>
                    <option value="savings">Savings Account</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="mobile_wallet">Mobile Wallet (bKash/Nagad/Rocket)</option>
                    <option value="other">Other Wallet</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Currency
                  </label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="BDT">BDT (৳)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Opening Balance
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={openingBalanceStr}
                    onChange={(e) => setOpeningBalanceStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Low Balance Alert Limit
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={alertThresholdStr}
                    onChange={(e) => setAlertThresholdStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Account Color
                </label>
                <div className="flex items-center gap-2">
                  {ACCOUNT_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-6 h-6 rounded-full border-2 ${
                        color === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Description / Notes
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Optional notes"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safe Account Deletion / Migration Modal */}
      {deleteDialogAcc && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Delete or Migrate "{deleteDialogAcc.name}"
            </h3>
            {(() => {
              const count = snapshot.transactions.filter(
                (t) =>
                  t.accountId === deleteDialogAcc.id ||
                  t.destinationAccountId === deleteDialogAcc.id
              ).length;
              if (count > 0) {
                return (
                  <div className="space-y-3">
                    <p className="text-xs text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 p-3 rounded-xl">
                      This account has <strong>{count} historical transactions</strong>. To protect ledger
                      integrity, either <strong>Archive</strong> the account or select a target account
                      below to migrate its transactions before deleting.
                    </p>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                        Migrate {count} transactions to:
                      </label>
                      <select
                        value={migrateTargetAccId}
                        onChange={(e) => setMigrateTargetAccId(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="">-- Select replacement account --</option>
                        {snapshot.accounts
                          .filter((a) => a.id !== deleteDialogAcc.id)
                          .map((a) => (
                            <option key={a.id} value={a.id}>
                              {a.name} ({a.currency})
                            </option>
                          ))}
                      </select>
                    </div>
                  </div>
                );
              }
              return (
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  This account has no transactions and can be safely deleted.
                </p>
              );
            })()}
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteDialogAcc(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  toggleArchiveAccount(deleteDialogAcc);
                  setDeleteDialogAcc(null);
                }}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-600 text-white"
              >
                Archive Instead
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteOrMigrate}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
