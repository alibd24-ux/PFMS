// ============================================================================
// PHASE 5: COMPLETE CATEGORY & SUBCATEGORY BUDGET MANAGEMENT MODULE
// Supports:
// - Unlimited Category Budgets & Subcategory Budgets
// - Monthly, Weekly, Daily, Yearly & Custom Period Budgets (Full CRUD)
// - Configurable Budget Alerts Banner (50%, 75%, 90%, 100% Exceeded)
// - Actual vs Planned vs Previous Period Spending Chart & Comparison Table
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  Copy,
  Edit3,
  FolderTree,
  Plus,
  Sliders,
  Trash2,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Budget, BudgetCategory, BudgetPeriod, DatabaseSnapshot } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from '../utils/money';

export interface BudgetsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

export const BudgetsModule: React.FC<BudgetsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [periodTab, setPeriodTab] = useState<BudgetPeriod | 'all'>('all');
  const [selectedBudgetId, setSelectedBudgetId] = useState<string>(
    snapshot.budgets[0]?.id || ''
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubBudgetModalOpen, setIsSubBudgetModalOpen] = useState(false);

  // New/Edit Budget Form State
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [budgetName, setBudgetName] = useState('');
  const [period, setPeriod] = useState<BudgetPeriod>('monthly');
  const [startDate, setStartDate] = useState('2026-11-01');
  const [endDate, setEndDate] = useState('2026-11-30');
  const [accountFilterId, setAccountFilterId] = useState('');
  const [thresholdsStr, setThresholdsStr] = useState('50, 75, 90, 100');
  const [catAllocations, setCatAllocations] = useState<Record<string, string>>({});

  // Add Subcategory Budget Allocation Form State
  const [subAllocSubId, setSubAllocSubId] = useState(
    snapshot.subcategories[0]?.id || 'sub_fam_parents'
  );
  const [subAllocAmountStr, setSubAllocAmountStr] = useState('2000');

  // Quick edit allocation state for active budget
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingAmountStr, setEditingAmountStr] = useState<string>('');
  const [editingSubAllocId, setEditingSubAllocId] = useState<string | null>(null);
  const [editingSubAmountStr, setEditingSubAmountStr] = useState<string>('');

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const filteredBudgets = useMemo(() => {
    if (periodTab === 'all') return snapshot.budgets;
    return snapshot.budgets.filter((b) => b.period === periodTab);
  }, [snapshot.budgets, periodTab]);

  const activeEvaluation = useMemo(() => {
    const id =
      filteredBudgets.some((b) => b.id === selectedBudgetId)
        ? selectedBudgetId
        : filteredBudgets[0]?.id || snapshot.budgets[0]?.id;
    return id ? FinancialEngine.evaluateBudget(snapshot, id) : null;
  }, [snapshot, selectedBudgetId, filteredBudgets]);

  const openCreateBudgetModal = () => {
    setEditingBudget(null);
    setBudgetName('Custom Budget Plan');
    setPeriod('monthly');
    setStartDate('2026-11-01');
    setEndDate('2026-11-30');
    setAccountFilterId('');
    setThresholdsStr('50, 75, 90, 100');
    const initMap: Record<string, string> = {};
    snapshot.categories
      .filter((c) => c.type === 'expense' && !c.isArchived)
      .forEach((c) => {
        initMap[c.id] = poishaToMajorString(c.monthlyLimitPoisha || 200000, 0);
      });
    setCatAllocations(initMap);
    setIsModalOpen(true);
  };

  const openEditBudgetModal = (b: Budget) => {
    setEditingBudget(b);
    setBudgetName(b.name);
    setPeriod(b.period);
    setStartDate(b.startDate);
    setEndDate(b.endDate);
    setAccountFilterId(b.accountId || '');
    setThresholdsStr((b.warningThresholds || [50, 75, 90, 100]).join(', '));
    const initMap: Record<string, string> = {};
    snapshot.budgetCategories
      .filter((bc) => bc.budgetId === b.id && !bc.subcategoryId)
      .forEach((bc) => {
        initMap[bc.categoryId] = poishaToMajorString(bc.allocatedPoisha, 0);
      });
    setCatAllocations(initMap);
    setIsModalOpen(true);
  };

  const handleCreateOrUpdateBudget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!budgetName.trim()) return;
    const now = new Date().toISOString();
    const targetId = editingBudget ? editingBudget.id : `bgt_${Date.now()}`;
    const parsedThresholds = thresholdsStr
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => Number.isFinite(n) && n > 0);

    const newBudgetCategories: BudgetCategory[] = [];
    let totalPoisha = 0;

    Object.entries(catAllocations).forEach(([catId, valStr]) => {
      const p = toPoisha(valStr);
      if (p > 0) {
        totalPoisha += p;
        newBudgetCategories.push({
          id: `bc_${targetId}_${catId}`,
          budgetId: targetId,
          categoryId: catId,
          allocatedPoisha: p,
        });
      }
    });

    const newBudget: Budget = {
      id: targetId,
      name: budgetName.trim(),
      period,
      startDate,
      endDate,
      totalLimitPoisha: totalPoisha,
      accountId: accountFilterId || undefined,
      warningThresholds: parsedThresholds.length === 4 ? parsedThresholds : [50, 75, 90, 100],
      notes: `${period} budget`,
      createdAt: editingBudget ? editingBudget.createdAt : now,
      updatedAt: now,
    };

    // Preserve existing subcategory allocations if editing
    const retainedBC = snapshot.budgetCategories.filter(
      (bc) => bc.budgetId !== targetId || Boolean(bc.subcategoryId)
    );

    const nextBudgets = editingBudget
      ? snapshot.budgets.map((b) => (b.id === targetId ? newBudget : b))
      : [newBudget, ...snapshot.budgets];

    onUpdateSnapshot(
      {
        ...snapshot,
        budgets: nextBudgets,
        budgetCategories: [...retainedBC, ...newBudgetCategories],
      },
      `${editingBudget ? 'Updated' : 'Created'} budget "${newBudget.name}" (${fmtMoney(totalPoisha)}).`
    );
    setSelectedBudgetId(targetId);
    setIsModalOpen(false);
  };

  const handleDeleteBudget = (budgetId: string) => {
    if (snapshot.budgets.length <= 1) return;
    const nextBudgets = snapshot.budgets.filter((b) => b.id !== budgetId);
    const nextBC = snapshot.budgetCategories.filter((bc) => bc.budgetId !== budgetId);
    onUpdateSnapshot(
      { ...snapshot, budgets: nextBudgets, budgetCategories: nextBC },
      'Deleted budget plan.'
    );
    setSelectedBudgetId(nextBudgets[0]?.id || '');
  };

  const handleCopyPreviousBudget = () => {
    const sourceBudget = snapshot.budgets.find((b) => b.id === selectedBudgetId) || snapshot.budgets[0];
    if (!sourceBudget) return;
    const now = new Date().toISOString();
    const newId = `bgt_copy_${Date.now()}`;
    const sourceAllocs = snapshot.budgetCategories.filter((bc) => bc.budgetId === sourceBudget.id);
    const copiedAllocs: BudgetCategory[] = sourceAllocs.map((bc, idx) => ({
      ...bc,
      id: `bc_${newId}_${bc.categoryId}_${bc.subcategoryId || idx}`,
      budgetId: newId,
    }));
    const newBudget: Budget = {
      ...sourceBudget,
      id: newId,
      name: `${sourceBudget.name} (Copied Next Cycle)`,
      startDate: '2026-12-01',
      endDate: '2026-12-31',
      createdAt: now,
      updatedAt: now,
    };
    onUpdateSnapshot(
      {
        ...snapshot,
        budgets: [newBudget, ...snapshot.budgets],
        budgetCategories: [...snapshot.budgetCategories, ...copiedAllocs],
      },
      `Copied "${sourceBudget.name}" allocations into "${newBudget.name}".`
    );
    setSelectedBudgetId(newId);
  };

  const handleSaveCategoryAllocation = (categoryId: string) => {
    if (!activeEvaluation) return;
    const newPoisha = Math.max(0, toPoisha(editingAmountStr));
    const budgetId = activeEvaluation.budget.id;
    const existing = snapshot.budgetCategories.find(
      (bc) => bc.budgetId === budgetId && bc.categoryId === categoryId && !bc.subcategoryId
    );

    let nextBC: BudgetCategory[];
    if (existing) {
      nextBC = snapshot.budgetCategories.map((bc) =>
        bc.id === existing.id ? { ...bc, allocatedPoisha: newPoisha } : bc
      );
    } else {
      nextBC = [
        ...snapshot.budgetCategories,
        {
          id: `bc_${budgetId}_${categoryId}`,
          budgetId,
          categoryId,
          allocatedPoisha: newPoisha,
        },
      ];
    }

    const newTotal = nextBC
      .filter((bc) => bc.budgetId === budgetId && !bc.subcategoryId)
      .reduce((s, bc) => s + bc.allocatedPoisha, 0);

    const nextBudgets = snapshot.budgets.map((b) =>
      b.id === budgetId ? { ...b, totalLimitPoisha: newTotal, updatedAt: new Date().toISOString() } : b
    );

    onUpdateSnapshot(
      {
        ...snapshot,
        budgets: nextBudgets,
        budgetCategories: nextBC,
      },
      'Updated category budget limit and recalculated total budget.'
    );
    setEditingCatId(null);
  };

  const handleAddSubcategoryBudget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvaluation || !subAllocSubId) return;
    const sub = snapshot.subcategories.find((s) => s.id === subAllocSubId);
    if (!sub) return;
    const allocatedPoisha = Math.max(0, toPoisha(subAllocAmountStr));
    if (allocatedPoisha <= 0) return;

    const budgetId = activeEvaluation.budget.id;
    const existing = snapshot.budgetCategories.find(
      (bc) => bc.budgetId === budgetId && bc.subcategoryId === sub.id
    );

    let nextBC: BudgetCategory[];
    if (existing) {
      nextBC = snapshot.budgetCategories.map((bc) =>
        bc.id === existing.id ? { ...bc, allocatedPoisha } : bc
      );
    } else {
      nextBC = [
        ...snapshot.budgetCategories,
        {
          id: `bc_sub_${budgetId}_${sub.id}_${Date.now()}`,
          budgetId,
          categoryId: sub.categoryId,
          subcategoryId: sub.id,
          allocatedPoisha,
        },
      ];
    }

    onUpdateSnapshot(
      { ...snapshot, budgetCategories: nextBC },
      `Set subcategory budget for "${sub.name}" (${fmtMoney(allocatedPoisha)}).`
    );
    setIsSubBudgetModalOpen(false);
  };

  const handleSaveSubAllocationInline = (allocationId: string) => {
    const newPoisha = Math.max(0, toPoisha(editingSubAmountStr));
    const nextBC = snapshot.budgetCategories.map((bc) =>
      bc.id === allocationId ? { ...bc, allocatedPoisha: newPoisha } : bc
    );
    onUpdateSnapshot({ ...snapshot, budgetCategories: nextBC }, 'Updated subcategory budget limit.');
    setEditingSubAllocId(null);
  };

  const handleDeleteSubAllocation = (allocationId: string) => {
    const nextBC = snapshot.budgetCategories.filter((bc) => bc.id !== allocationId);
    onUpdateSnapshot({ ...snapshot, budgetCategories: nextBC }, 'Removed subcategory budget.');
  };

  const chartData = useMemo(() => {
    if (!activeEvaluation) return [];
    return activeEvaluation.categoryBreakdown.map((item) => ({
      category: item.categoryName,
      Planned: Math.round(item.allocatedPoisha / 100),
      Actual: Math.round(item.spentPoisha / 100),
      PrevMonth: Math.round(item.previousSpentPoisha / 100),
    }));
  }, [activeEvaluation]);

  return (
    <div className="space-y-6 pb-8">
      {/* Period Filter Pills: All | Monthly | Weekly | Yearly | Daily | Custom */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5">
            {(
              [
                ['all', 'All Budgets'],
                ['monthly', 'Monthly Budgets'],
                ['weekly', 'Weekly Budgets'],
                ['yearly', 'Yearly Budgets'],
                ['daily', 'Daily Budgets'],
                ['custom', 'Custom Period'],
              ] as Array<[BudgetPeriod | 'all', string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setPeriodTab(key);
                  const first = snapshot.budgets.find((b) => key === 'all' || b.period === key);
                  if (first) setSelectedBudgetId(first.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  periodTab === key
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setIsSubBudgetModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-xs font-semibold"
            >
              <FolderTree className="w-3.5 h-3.5" /> + Subcategory Budget
            </button>
            <button
              type="button"
              onClick={handleCopyPreviousBudget}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-xs font-semibold"
            >
              <Copy className="w-3.5 h-3.5" /> Copy Budget to Next Month
            </button>
            <button
              type="button"
              onClick={openCreateBudgetModal}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" /> Create Budget Plan
            </button>
          </div>
        </div>

        {/* Active Plan Selector + Edit/Delete Controls */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-slate-500">Selected Plan:</label>
            <select
              value={activeEvaluation?.budget.id || ''}
              onChange={(e) => setSelectedBudgetId(e.target.value)}
              className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            >
              {filteredBudgets.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.period.toUpperCase()} • {b.startDate} to {b.endDate})
                </option>
              ))}
            </select>
          </div>

          {activeEvaluation && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => openEditBudgetModal(activeEvaluation.budget)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" /> Edit Plan Settings
              </button>
              {snapshot.budgets.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleDeleteBudget(activeEvaluation.budget.id)}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-xs font-semibold text-rose-600 flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete Plan
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {activeEvaluation && (
        <>
          {/* Active Budget Alerts & Threshold Warnings Banner */}
          {activeEvaluation.alerts.length > 0 && (
            <div className="bg-amber-50/90 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-2xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                <Bell className="w-4 h-4 text-amber-600" />
                <span>
                  Active Budget Threshold Alerts ({activeEvaluation.alerts.length}) — Thresholds:{' '}
                  {activeEvaluation.budget.warningThresholds.join('% / ')}%
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {activeEvaluation.alerts.map((al) => (
                  <div
                    key={al.id}
                    className={`p-2.5 rounded-xl text-xs border flex items-center justify-between ${
                      al.status === 'exceeded'
                        ? 'bg-rose-100/80 dark:bg-rose-950/60 border-rose-300 text-rose-900 dark:text-rose-200'
                        : 'bg-white dark:bg-slate-900 border-amber-200 dark:border-amber-800 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <div className="truncate pr-2">
                      <div className="font-bold truncate">{al.name}</div>
                      <div className="text-[11px] opacity-80">
                        {fmtMoney(al.spentPoisha)} of {fmtMoney(al.allocatedPoisha)}
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold shrink-0 ${
                        al.status === 'exceeded'
                          ? 'bg-rose-600 text-white'
                          : 'bg-amber-500 text-white'
                      }`}
                    >
                      {al.percentUsed.toFixed(0)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Overall Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
              <span className="text-xs text-slate-500">Total Planned Budget</span>
              <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                {fmtMoney(activeEvaluation.totalAllocatedPoisha)}
              </div>
              <span className="text-[11px] text-slate-400">
                Period: {activeEvaluation.budget.period.toUpperCase()}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
              <span className="text-xs text-slate-500">Actual Spent</span>
              <div className="text-xl font-bold text-rose-600 dark:text-rose-400 mt-1">
                {fmtMoney(activeEvaluation.totalSpentPoisha)}
              </div>
              <span className="text-[11px] text-slate-400">
                {activeEvaluation.percentUsed.toFixed(1)}% utilized
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
              <span className="text-xs text-slate-500">Remaining Budget</span>
              <div
                className={`text-xl font-bold mt-1 ${
                  activeEvaluation.remainingPoisha >= 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {fmtMoney(activeEvaluation.remainingPoisha)}
              </div>
              <span className="text-[11px] text-slate-400">
                Thresholds: {activeEvaluation.budget.warningThresholds.join('% / ')}%
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
              <span className="text-xs text-slate-500">Previous Period Spent</span>
              <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                {fmtMoney(activeEvaluation.previousMonthSpentPoisha)}
              </div>
              <span className="text-[11px] text-slate-400">Historical benchmark</span>
            </div>
          </div>

          {/* Planned vs Actual vs Previous Month Chart */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
              Planned vs Actual vs Previous Period Spending Comparison
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Transfers and loan principal movements are automatically excluded from budget usage
            </p>
            <div className="relative h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis dataKey="category" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="Planned" name="Planned Budget (৳)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Actual" name="Actual Spent (৳)" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="PrevMonth" name="Prev Period (৳)" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Category-by-Category Budget Cards */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
              Category Budgets ({activeEvaluation.categoryBreakdown.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeEvaluation.categoryBreakdown.map((item) => (
                <div
                  key={item.categoryId}
                  className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-3.5 h-3.5 rounded-full"
                        style={{ backgroundColor: item.categoryColor }}
                      />
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {item.categoryName}
                      </h4>
                      {item.status === 'exceeded' && (
                        <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-100 text-rose-700">
                          100% Limit Reached
                        </span>
                      )}
                      {item.status === 'warning_90' && (
                        <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-50 text-rose-600">
                          90% Warning
                        </span>
                      )}
                      {item.status === 'warning_75' && (
                        <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 text-amber-700">
                          75% Warning
                        </span>
                      )}
                      {item.status === 'warning_50' && (
                        <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-sky-100 text-sky-700">
                          50% Passed
                        </span>
                      )}
                    </div>

                    {editingCatId === item.categoryId ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          value={editingAmountStr}
                          onChange={(e) => setEditingAmountStr(e.target.value)}
                          className="w-24 px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCategoryAllocation(item.categoryId)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingCatId(item.categoryId);
                          setEditingAmountStr(poishaToMajorString(item.allocatedPoisha, 0));
                        }}
                        className="text-xs text-slate-400 hover:text-emerald-600 flex items-center gap-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Adjust Limit
                      </button>
                    )}
                  </div>

                  <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        item.status === 'exceeded'
                          ? 'bg-rose-500'
                          : item.status === 'warning_90' || item.status === 'warning_75'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, item.percentUsed)}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                    <div>
                      <div className="text-[10px] text-slate-400">Planned Limit</div>
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        {fmtMoney(item.allocatedPoisha)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Actual Spent</div>
                      <div className="font-bold text-rose-600 dark:text-rose-400">
                        {fmtMoney(item.spentPoisha)} ({item.percentUsed.toFixed(0)}%)
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Remaining</div>
                      <div
                        className={`font-bold ${
                          item.remainingPoisha >= 0 ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {fmtMoney(item.remainingPoisha)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Subcategory Budgets Section */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Subcategory Budgets ({activeEvaluation.subcategoryBreakdown.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Independent spending limits for granular subcategories (e.g., Family › Parents, Food › Dining)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsSubBudgetModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Subcategory Budget
              </button>
            </div>

            {activeEvaluation.subcategoryBreakdown.length === 0 ? (
              <div className="text-xs text-slate-400 py-4 text-center">
                No subcategory budgets configured for this plan yet. Click "Add Subcategory Budget" above.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {activeEvaluation.subcategoryBreakdown.map((subItem) => (
                  <div
                    key={subItem.allocationId}
                    className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: subItem.categoryColor }}
                          />
                          <span>
                            {subItem.categoryName} › {subItem.subcategoryName}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {editingSubAllocId === subItem.allocationId ? (
                          <>
                            <input
                              type="number"
                              value={editingSubAmountStr}
                              onChange={(e) => setEditingSubAmountStr(e.target.value)}
                              className="w-20 px-2 py-0.5 text-xs rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                            <button
                              type="button"
                              onClick={() => handleSaveSubAllocationInline(subItem.allocationId)}
                              className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[11px] font-semibold"
                            >
                              Save
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingSubAllocId(subItem.allocationId);
                                setEditingSubAmountStr(
                                  poishaToMajorString(subItem.allocatedPoisha, 0)
                                );
                              }}
                              className="text-[11px] text-slate-400 hover:text-emerald-600"
                            >
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteSubAllocation(subItem.allocationId)}
                              className="text-[11px] text-rose-500 hover:underline"
                            >
                              Remove
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          subItem.status === 'exceeded'
                            ? 'bg-rose-500'
                            : subItem.status === 'warning_90' || subItem.status === 'warning_75'
                            ? 'bg-amber-500'
                            : 'bg-teal-500'
                        }`}
                        style={{ width: `${Math.min(100, subItem.percentUsed)}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>
                        Spent: <strong className="text-slate-800 dark:text-slate-100">{fmtMoney(subItem.spentPoisha)}</strong> ({subItem.percentUsed.toFixed(0)}%)
                      </span>
                      <span>Limit: {fmtMoney(subItem.allocatedPoisha)}</span>
                      <span>Rem: {fmtMoney(subItem.remainingPoisha)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Create / Edit Budget Plan Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              {editingBudget ? `Edit Budget Plan "${editingBudget.name}"` : 'Create Customizable Budget Plan'}
            </h3>
            <form onSubmit={handleCreateOrUpdateBudget} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Budget Name *
                </label>
                <input
                  type="text"
                  required
                  value={budgetName}
                  onChange={(e) => setBudgetName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Budget Period
                  </label>
                  <select
                    value={period}
                    onChange={(e) => setPeriod(e.target.value as BudgetPeriod)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="monthly">Monthly Budget</option>
                    <option value="weekly">Weekly Budget</option>
                    <option value="daily">Daily Budget</option>
                    <option value="yearly">Yearly Budget</option>
                    <option value="custom">Custom Period Budget</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Account Filter (Optional)
                  </label>
                  <select
                    value={accountFilterId}
                    onChange={(e) => setAccountFilterId(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="">All Accounts</option>
                    {snapshot.accounts.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Thresholds (%)</label>
                  <input
                    type="text"
                    value={thresholdsStr}
                    onChange={(e) => setThresholdsStr(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-2">
                  Category Allocations (৳)
                </label>
                <div className="grid grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                  {snapshot.categories
                    .filter((c) => c.type === 'expense' && !c.isArchived)
                    .map((cat) => (
                      <div key={cat.id} className="flex items-center justify-between gap-2 text-xs">
                        <span className="truncate">{cat.name}</span>
                        <input
                          type="number"
                          value={catAllocations[cat.id] || '0'}
                          onChange={(e) =>
                            setCatAllocations({ ...catAllocations, [cat.id]: e.target.value })
                          }
                          className="w-24 px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                    ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Save Budget Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Subcategory Budget Modal */}
      {isSubBudgetModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              Set Subcategory Budget Allocation
            </h3>
            <form onSubmit={handleAddSubcategoryBudget} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Subcategory *
                </label>
                <select
                  value={subAllocSubId}
                  onChange={(e) => setSubAllocSubId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {snapshot.subcategories
                    .filter((s) => !s.isArchived)
                    .map((s) => {
                      const parent = snapshot.categories.find((c) => c.id === s.categoryId);
                      return (
                        <option key={s.id} value={s.id}>
                          {parent?.name || ''} › {s.name} ({s.nameBn})
                        </option>
                      );
                    })}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Budget Limit (৳) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={subAllocAmountStr}
                  onChange={(e) => setSubAllocAmountStr(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSubBudgetModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-teal-600 text-white"
                >
                  Save Subcategory Limit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
