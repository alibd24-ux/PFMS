// ============================================================================
// PHASE 7 & 8: LOANS/INSTALLMENTS, SAVINGS GOALS & RECURRING TRANSACTIONS
// Complete CRUD, Amortization & Payment History, Reversals, Due Reminders,
// Savings Contribution History, and Idempotent Recurring Execution.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  Bell,
  Calendar,
  CheckCircle2,
  CreditCard,
  Edit3,
  History,
  Pause,
  PiggyBank,
  Play,
  Plus,
  RefreshCw,
  Trash2,
  XCircle,
} from 'lucide-react';
import {
  DatabaseSnapshot,
  LoanCategoryType,
  LoanRecord,
  RecurrenceFrequency,
  RecurringTransaction,
  SavingsContribution,
  SavingsGoal,
} from '../types/models';
import { generateLoanSchedule } from '../db/database';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from '../utils/money';

export interface LoansModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

export const LoansModule: React.FC<LoansModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [isAddLoanOpen, setIsAddLoanOpen] = useState(false);
  const [editingLoan, setEditingLoan] = useState<LoanRecord | null>(null);
  const [selectedScheduleLoan, setSelectedScheduleLoan] = useState<LoanRecord | null>(null);

  // Add / Edit Loan Form State
  const [name, setName] = useState('');
  const [loanType, setLoanType] = useState<LoanCategoryType>('bank');
  const [lender, setLender] = useState('');
  const [principalStr, setPrincipalStr] = useState('50000');
  const [interestRateStr, setInterestRateStr] = useState('9.0');
  const [totalInstallmentsStr, setTotalInstallmentsStr] = useState('12');
  const [loanDate, setLoanDate] = useState('2026-11-06');
  const [accountId, setAccountId] = useState('acc_bank');

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const openCreateLoanModal = () => {
    setEditingLoan(null);
    setName('');
    setLoanType('bank');
    setLender('');
    setPrincipalStr('50000');
    setInterestRateStr('9.0');
    setTotalInstallmentsStr('12');
    setLoanDate('2026-11-06');
    setAccountId('acc_bank');
    setIsAddLoanOpen(true);
  };

  const openEditLoanModal = (loan: LoanRecord) => {
    setEditingLoan(loan);
    setName(loan.name);
    setLoanType(loan.loanType);
    setLender(loan.lender);
    setPrincipalStr(poishaToMajorString(loan.principalPoisha, 0));
    setInterestRateStr(String(loan.interestRateAnnual));
    setTotalInstallmentsStr(String(loan.totalInstallments));
    setLoanDate(loan.loanDate);
    setAccountId(loan.accountId);
    setIsAddLoanOpen(true);
  };

  const handleSaveLoan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !lender.trim()) return;
    const principalPoisha = toPoisha(principalStr);
    const interestRateAnnual = parseFloat(interestRateStr) || 0;
    const totalInstallments = Math.max(1, parseInt(totalInstallmentsStr, 10) || 6);
    const now = new Date().toISOString();

    if (editingLoan) {
      // Update loan metadata; if no installments paid yet, regenerate schedule
      const canRegenerate = editingLoan.paidInstallments === 0;
      const regen = canRegenerate
        ? generateLoanSchedule(principalPoisha, interestRateAnnual, totalInstallments, loanDate)
        : null;

      const updatedLoans = snapshot.loans.map((l) =>
        l.id === editingLoan.id
          ? {
              ...l,
              name: name.trim(),
              loanType,
              lender: lender.trim(),
              accountId,
              principalPoisha: canRegenerate ? principalPoisha : l.principalPoisha,
              remainingPrincipalPoisha: canRegenerate
                ? principalPoisha
                : l.remainingPrincipalPoisha,
              interestRateAnnual: canRegenerate ? interestRateAnnual : l.interestRateAnnual,
              totalInstallments: canRegenerate ? totalInstallments : l.totalInstallments,
              installmentAmountPoisha: regen
                ? regen.installmentAmountPoisha
                : l.installmentAmountPoisha,
              schedule: regen ? regen.schedule : l.schedule,
              updatedAt: now,
            }
          : l
      );
      onUpdateSnapshot(
        { ...snapshot, loans: updatedLoans },
        `Updated loan "${name.trim()}".`
      );
      setIsAddLoanOpen(false);
      setEditingLoan(null);
      return;
    }

    const { installmentAmountPoisha, schedule } = generateLoanSchedule(
      principalPoisha,
      interestRateAnnual,
      totalInstallments,
      loanDate
    );

    const newLoan: LoanRecord = {
      id: `loan_${Date.now()}`,
      name: name.trim(),
      loanType,
      lender: lender.trim(),
      principalPoisha,
      interestRateAnnual,
      loanDate,
      totalInstallments,
      installmentAmountPoisha,
      nextDueDate: schedule[0]?.dueDate || loanDate,
      remainingPrincipalPoisha: principalPoisha,
      totalInterestPaidPoisha: 0,
      paidInstallments: 0,
      accountId,
      status: 'active',
      schedule,
      notes: `${interestRateAnnual}% p.a. (${totalInstallments} EMIs)`,
      createdAt: now,
      updatedAt: now,
    };

    onUpdateSnapshot(
      { ...snapshot, loans: [newLoan, ...snapshot.loans] },
      `Created loan "${newLoan.name}" with ${totalInstallments} scheduled installments.`
    );
    setIsAddLoanOpen(false);
  };

  const handleDeleteLoan = (loan: LoanRecord) => {
    const paymentTxIds = new Set(
      snapshot.loanPayments.filter((lp) => lp.loanId === loan.id).map((lp) => lp.transactionId)
    );
    const nextTransactions = snapshot.transactions.filter(
      (t) => t.loanId !== loan.id && !paymentTxIds.has(t.id)
    );
    const nextLoanPayments = snapshot.loanPayments.filter((lp) => lp.loanId !== loan.id);
    const nextLoans = snapshot.loans.filter((l) => l.id !== loan.id);
    const next = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      transactions: nextTransactions,
      loanPayments: nextLoanPayments,
      loans: nextLoans,
    });
    onUpdateSnapshot(next, `Deleted loan "${loan.name}" and reversed associated EMI ledger entries.`);
  };

  const handlePayNextInstallment = (loan: LoanRecord, installmentNumber?: number) => {
    const res = FinancialEngine.recordLoanInstallmentPayment(snapshot, {
      loanId: loan.id,
      installmentNumber,
      accountId: loan.accountId,
      paymentDate: '2026-11-06',
      note: 'Scheduled EMI payment',
    });
    if (res.ok) {
      onUpdateSnapshot(
        res.snapshot,
        `Recorded EMI installment for "${loan.name}" (Principal & Interest separated).`
      );
      if (selectedScheduleLoan && selectedScheduleLoan.id === loan.id) {
        const refreshed = res.snapshot.loans.find((l) => l.id === loan.id) || null;
        setSelectedScheduleLoan(refreshed);
      }
    }
  };

  const totalRemainingPrincipal = useMemo(
    () =>
      snapshot.loans
        .filter((l) => l.status === 'active')
        .reduce((s, l) => s + l.remainingPrincipalPoisha, 0),
    [snapshot.loans]
  );

  const totalInterestPaid = useMemo(
    () => snapshot.loans.reduce((s, l) => s + l.totalInterestPaidPoisha, 0),
    [snapshot.loans]
  );

  return (
    <div className="space-y-6 pb-8">
      {/* Header & Summary Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Loan & EMI Installment Management
          </h3>
          <p className="text-xs text-slate-500">
            Active Principal Liability: <strong>{fmtMoney(totalRemainingPrincipal)}</strong> • Total
            Interest Paid: <strong>{fmtMoney(totalInterestPaid)}</strong>
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateLoanModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
        >
          <Plus className="w-3.5 h-3.5" /> Add Loan / EMI Plan
        </button>
      </div>

      {/* Loan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {snapshot.loans.map((loan) => {
          const pct = Math.min(
            100,
            Math.round((loan.paidInstallments / Math.max(1, loan.totalInstallments)) * 100)
          );
          return (
            <div
              key={loan.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {loan.name}
                    </h4>
                    <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded-full bg-indigo-100 text-indigo-700">
                      {loan.interestRateAnnual > 0
                        ? `${loan.interestRateAnnual}% p.a.`
                        : '0% Interest-Free'}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Lender: <strong>{loan.lender}</strong> • Type: {loan.loanType.toUpperCase()}
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSelectedScheduleLoan(loan)}
                    className="text-xs font-semibold text-indigo-600 hover:underline"
                  >
                    Amortization Schedule
                  </button>
                  <button
                    type="button"
                    onClick={() => openEditLoanModal(loan)}
                    title="Edit Loan"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteLoan(loan)}
                    title="Delete Loan"
                    className="p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                <div>
                  <div className="text-[10px] text-slate-400">Original Principal</div>
                  <div className="font-bold">{fmtMoney(loan.principalPoisha)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">Remaining Principal</div>
                  <div className="font-bold text-rose-600">
                    {fmtMoney(loan.remainingPrincipalPoisha)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">Monthly EMI</div>
                  <div className="font-bold text-indigo-600">
                    {fmtMoney(loan.installmentAmountPoisha)}
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>
                    Installments Paid: {loan.paidInstallments} / {loan.totalInstallments}
                  </span>
                  <span>Interest Paid: {fmtMoney(loan.totalInterestPaidPoisha)}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-xs text-slate-500">Next Due: {loan.nextDueDate}</span>
                {loan.status === 'active' && (
                  <button
                    type="button"
                    onClick={() => handlePayNextInstallment(loan)}
                    className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                  >
                    Pay Next EMI ({fmtMoney(loan.installmentAmountPoisha)})
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Loan Amortization Schedule & Payment History Modal */}
      {selectedScheduleLoan && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  EMI Schedule — {selectedScheduleLoan.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Principal & Interest breakdown per installment
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedScheduleLoan(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                    <th className="py-2">#</th>
                    <th className="py-2">Due Date</th>
                    <th className="py-2 text-right">Total EMI</th>
                    <th className="py-2 text-right">Principal</th>
                    <th className="py-2 text-right">Interest</th>
                    <th className="py-2 text-right">Balance After</th>
                    <th className="py-2 text-center">Status / Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {selectedScheduleLoan.schedule.map((item) => (
                    <tr key={item.installmentNumber}>
                      <td className="py-2 font-bold">{item.installmentNumber}</td>
                      <td className="py-2">{item.dueDate}</td>
                      <td className="py-2 text-right font-semibold">
                        {fmtMoney(item.installmentPoisha)}
                      </td>
                      <td className="py-2 text-right text-emerald-600">
                        {fmtMoney(item.principalPoisha)}
                      </td>
                      <td className="py-2 text-right text-amber-600">
                        {fmtMoney(item.interestPoisha)}
                      </td>
                      <td className="py-2 text-right">
                        {fmtMoney(item.remainingBalancePoisha)}
                      </td>
                      <td className="py-2 text-center">
                        {item.isPaid ? (
                          <div className="inline-flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                              PAID ({item.paidDate})
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const next = FinancialEngine.reverseLoanInstallmentPayment(
                                  snapshot,
                                  selectedScheduleLoan.id,
                                  item.installmentNumber
                                );
                                onUpdateSnapshot(
                                  next,
                                  `Reversed EMI #${item.installmentNumber} and restored account & loan balances.`
                                );
                                setSelectedScheduleLoan(
                                  next.loans.find((l) => l.id === selectedScheduleLoan.id) || null
                                );
                              }}
                              className="text-[10px] text-rose-500 hover:underline"
                            >
                              Reverse
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              handlePayNextInstallment(
                                selectedScheduleLoan,
                                item.installmentNumber
                              )
                            }
                            className="px-2 py-0.5 rounded bg-indigo-600 text-white text-[10px] font-semibold"
                          >
                            Pay EMI #{item.installmentNumber}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Loan Modal */}
      {isAddLoanOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingLoan ? `Edit Loan "${editingLoan.name}"` : 'Add Loan / EMI Installment Plan'}
            </h3>
            <form onSubmit={handleSaveLoan} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Loan / Purchase Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Home Renovation Loan, iPhone 0% EMI"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Lender / Bank *
                  </label>
                  <input
                    type="text"
                    required
                    value={lender}
                    onChange={(e) => setLender(e.target.value)}
                    placeholder="City Bank / BRAC"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Loan Type
                  </label>
                  <select
                    value={loanType}
                    onChange={(e) => setLoanType(e.target.value as LoanCategoryType)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="bank">Bank Loan</option>
                    <option value="personal">Personal Loan</option>
                    <option value="credit_card">Credit Card Due</option>
                    <option value="installment">0% Installment Purchase</option>
                    <option value="emi">Monthly EMI</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Principal (৳)</label>
                  <input
                    type="number"
                    required
                    value={principalStr}
                    onChange={(e) => setPrincipalStr(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Interest % p.a.</label>
                  <input
                    type="number"
                    step="0.1"
                    value={interestRateStr}
                    onChange={(e) => setInterestRateStr(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Total EMIs</label>
                  <input
                    type="number"
                    required
                    value={totalInstallmentsStr}
                    onChange={(e) => setTotalInstallmentsStr(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={loanDate}
                    onChange={(e) => setLoanDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Debited Account</label>
                  <select
                    value={accountId}
                    onChange={(e) => setAccountId(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {snapshot.accounts
                      .filter((a) => a.status === 'active')
                      .map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddLoanOpen(false);
                    setEditingLoan(null);
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 text-white"
                >
                  Generate Schedule & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// SAVINGS GOALS MODULE (Section 10)
// ============================================================================
export interface SavingsModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

const GOAL_COLORS = ['#10b981', '#0ea5e9', '#8b5cf6', '#f97316', '#ec4899', '#14b8a6'];

export const SavingsModule: React.FC<SavingsModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [isAddGoalOpen, setIsAddGoalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<SavingsGoal | null>(null);
  const [historyGoal, setHistoryGoal] = useState<SavingsGoal | null>(null);

  const [goalName, setGoalName] = useState('');
  const [targetStr, setTargetStr] = useState('100000');
  const [targetDate, setTargetDate] = useState('2027-12-31');
  const [goalAccountId, setGoalAccountId] = useState('acc_savings');
  const [goalColor, setGoalColor] = useState('#10b981');
  const [goalDesc, setGoalDesc] = useState('');

  const [contribGoal, setContribGoal] = useState<SavingsGoal | null>(null);
  const [contribType, setContribType] = useState<'deposit' | 'withdrawal'>('deposit');
  const [contribAmountStr, setContribAmountStr] = useState('5000');
  const [contribNote, setContribNote] = useState('');

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const openCreateGoalModal = () => {
    setEditingGoal(null);
    setGoalName('');
    setTargetStr('100000');
    setTargetDate('2027-12-31');
    setGoalAccountId('acc_savings');
    setGoalColor('#10b981');
    setGoalDesc('');
    setIsAddGoalOpen(true);
  };

  const openEditGoalModal = (g: SavingsGoal) => {
    setEditingGoal(g);
    setGoalName(g.name);
    setTargetStr(poishaToMajorString(g.targetAmountPoisha, 0));
    setTargetDate(g.targetDate);
    setGoalAccountId(g.accountId);
    setGoalColor(g.color);
    setGoalDesc(g.description || '');
    setIsAddGoalOpen(true);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalName.trim()) return;
    const now = new Date().toISOString();
    const targetAmountPoisha = toPoisha(targetStr);

    if (editingGoal) {
      const updated = snapshot.savingsGoals.map((g) =>
        g.id === editingGoal.id
          ? {
              ...g,
              name: goalName.trim(),
              targetAmountPoisha,
              targetDate,
              accountId: goalAccountId,
              color: goalColor,
              description: goalDesc.trim(),
              updatedAt: now,
            }
          : g
      );
      onUpdateSnapshot(
        FinancialEngine.recalculateSnapshotIntegrity({ ...snapshot, savingsGoals: updated }),
        `Updated savings goal "${goalName.trim()}".`
      );
      setIsAddGoalOpen(false);
      setEditingGoal(null);
      return;
    }

    const newGoal: SavingsGoal = {
      id: `sav_${Date.now()}`,
      name: goalName.trim(),
      targetAmountPoisha,
      savedAmountPoisha: 0,
      targetDate,
      accountId: goalAccountId,
      icon: 'PiggyBank',
      color: goalColor,
      description: goalDesc.trim(),
      status: 'active',
      createdAt: now,
      updatedAt: now,
    };
    onUpdateSnapshot(
      { ...snapshot, savingsGoals: [...snapshot.savingsGoals, newGoal] },
      `Created savings goal "${newGoal.name}".`
    );
    setIsAddGoalOpen(false);
    setGoalName('');
  };

  const handleDeleteGoal = (goal: SavingsGoal) => {
    const nextGoals = snapshot.savingsGoals.filter((g) => g.id !== goal.id);
    const nextContribs = snapshot.savingsContributions.filter((c) => c.goalId !== goal.id);
    onUpdateSnapshot(
      { ...snapshot, savingsGoals: nextGoals, savingsContributions: nextContribs },
      `Deleted savings goal "${goal.name}".`
    );
  };

  const handleRecordContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contribGoal) return;
    const amt = toPoisha(contribAmountStr);
    if (amt <= 0) return;

    const newContrib: SavingsContribution = {
      id: `sc_${Date.now()}`,
      goalId: contribGoal.id,
      type: contribType,
      amountPoisha: amt,
      date: '2026-11-06',
      accountId: contribGoal.accountId,
      note: contribNote || (contribType === 'deposit' ? 'Goal deposit' : 'Goal withdrawal'),
      createdAt: new Date().toISOString(),
    };

    const next = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      savingsContributions: [newContrib, ...snapshot.savingsContributions],
    });
    onUpdateSnapshot(
      next,
      `${contribType === 'deposit' ? 'Added' : 'Withdrew'} ${fmtMoney(amt)} ${
        contribType === 'deposit' ? 'to' : 'from'
      } "${contribGoal.name}" (not double-counted as expense).`
    );
    setContribGoal(null);
  };

  const handleDeleteContribution = (contribId: string) => {
    const nextContribs = snapshot.savingsContributions.filter((c) => c.id !== contribId);
    const next = FinancialEngine.recalculateSnapshotIntegrity({
      ...snapshot,
      savingsContributions: nextContribs,
    });
    onUpdateSnapshot(next, 'Removed savings contribution entry and recalculated goal progress.');
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Savings Goals & Reserve Tracker
          </h3>
          <p className="text-xs text-slate-500">
            Savings transfers and goal allocations are never double-counted as expenses
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateGoalModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold"
        >
          <Plus className="w-3.5 h-3.5" /> Create Savings Goal
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {snapshot.savingsGoals.map((goal) => {
          const pct = Math.min(
            100,
            Math.round((goal.savedAmountPoisha / Math.max(1, goal.targetAmountPoisha)) * 100)
          );
          const remaining = Math.max(0, goal.targetAmountPoisha - goal.savedAmountPoisha);
          const contribCount = snapshot.savingsContributions.filter(
            (c) => c.goalId === goal.id
          ).length;

          return (
            <div
              key={goal.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {goal.name}
                  </h4>
                  <p className="text-xs text-slate-500">{goal.description}</p>
                </div>
                <div className="flex items-center gap-1">
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                    {pct}%
                  </span>
                  <button
                    type="button"
                    onClick={() => setHistoryGoal(goal)}
                    title="Savings History"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600"
                  >
                    <History className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => openEditGoalModal(goal)}
                    title="Edit Goal"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteGoal(goal)}
                    title="Delete Goal"
                    className="p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${pct}%`, backgroundColor: goal.color }}
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <div className="text-[10px] text-slate-400">Saved So Far</div>
                  <div className="font-bold text-teal-600">{fmtMoney(goal.savedAmountPoisha)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">Target ({goal.targetDate})</div>
                  <div className="font-bold">{fmtMoney(goal.targetAmountPoisha)}</div>
                </div>
              </div>
              <div className="text-[11px] text-slate-500 flex justify-between">
                <span>
                  Remaining: <strong>{fmtMoney(remaining)}</strong>
                </span>
                <span>{contribCount} entries</span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setContribGoal(goal);
                    setContribType('deposit');
                    setContribAmountStr('5000');
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
                >
                  + Deposit
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setContribGoal(goal);
                    setContribType('withdrawal');
                    setContribAmountStr('2000');
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold"
                >
                  - Withdraw
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create / Edit Goal Modal */}
      {isAddGoalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingGoal ? `Edit Savings Goal "${editingGoal.name}"` : 'New Savings Goal'}
            </h3>
            <form onSubmit={handleSaveGoal} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Goal Name *
                </label>
                <input
                  type="text"
                  required
                  value={goalName}
                  onChange={(e) => setGoalName(e.target.value)}
                  placeholder="e.g., Emergency Fund, New Phone, Hajj Fund"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Target Amount (৳) *
                  </label>
                  <input
                    type="number"
                    required
                    value={targetStr}
                    onChange={(e) => setTargetStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Target Date
                  </label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Associated Account
                  </label>
                  <select
                    value={goalAccountId}
                    onChange={(e) => setGoalAccountId(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {snapshot.accounts
                      .filter((a) => a.status === 'active')
                      .map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Color
                  </label>
                  <div className="flex items-center gap-1.5 pt-1">
                    {GOAL_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setGoalColor(c)}
                        className={`w-5 h-5 rounded-full border-2 ${
                          goalColor === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  value={goalDesc}
                  onChange={(e) => setGoalDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddGoalOpen(false);
                    setEditingGoal(null);
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-teal-600 text-white"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deposit / Withdraw Modal */}
      {contribGoal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {contribType === 'deposit' ? 'Add Money to' : 'Withdraw from'} "{contribGoal.name}"
            </h3>
            <form onSubmit={handleRecordContribution} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Amount (৳) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={contribAmountStr}
                  onChange={(e) => setContribAmountStr(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Note
                </label>
                <input
                  type="text"
                  value={contribNote}
                  onChange={(e) => setContribNote(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setContribGoal(null)}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Confirm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Savings Goal Contribution History Modal */}
      {historyGoal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Savings History — {historyGoal.name}
              </h3>
              <button
                type="button"
                onClick={() => setHistoryGoal(null)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Close
              </button>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-64 overflow-y-auto text-xs">
              {snapshot.savingsContributions
                .filter((c) => c.goalId === historyGoal.id)
                .map((c) => (
                  <div key={c.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-semibold">
                        {c.type.toUpperCase()} — {c.note}
                      </div>
                      <div className="text-[11px] text-slate-400">{c.date}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-bold ${
                          c.type === 'deposit' ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {c.type === 'deposit' ? '+' : '-'} {fmtMoney(c.amountPoisha)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeleteContribution(c.id)}
                        className="text-[10px] text-rose-500 hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// RECURRING TRANSACTIONS MODULE (Section 11)
// ============================================================================
export interface RecurringModuleProps {
  snapshot: DatabaseSnapshot;
  onUpdateSnapshot: (next: DatabaseSnapshot, message?: string) => void;
}

export const RecurringModule: React.FC<RecurringModuleProps> = ({
  snapshot,
  onUpdateSnapshot,
}) => {
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<RecurringTransaction | null>(null);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'income' | 'expense' | 'transfer'>('expense');
  const [amountStr, setAmountStr] = useState('1500');
  const [accountId, setAccountId] = useState('acc_bkash');
  const [categoryId, setCategoryId] = useState('cat_electricity');
  const [frequency, setFrequency] = useState<RecurrenceFrequency>('monthly');
  const [customIntervalStr, setCustomIntervalStr] = useState('15');
  const [startDate, setStartDate] = useState('2026-11-01');
  const [endDate, setEndDate] = useState('');
  const [nextDate, setNextDate] = useState('2026-11-15');
  const [autoPost, setAutoPost] = useState(false);

  const fmtMoney = (poisha: number) =>
    formatCurrency(poisha, { currency, numberFormat, precision });

  const openCreateRuleModal = () => {
    setEditingRule(null);
    setTitle('');
    setType('expense');
    setAmountStr('1500');
    setAccountId('acc_bkash');
    setCategoryId('cat_electricity');
    setFrequency('monthly');
    setCustomIntervalStr('15');
    setStartDate('2026-11-01');
    setEndDate('');
    setNextDate('2026-11-15');
    setAutoPost(false);
    setIsAddOpen(true);
  };

  const openEditRuleModal = (rule: RecurringTransaction) => {
    setEditingRule(rule);
    setTitle(rule.title);
    setType(rule.type);
    setAmountStr(poishaToMajorString(rule.amountPoisha, 0));
    setAccountId(rule.accountId);
    setCategoryId(rule.categoryId);
    setFrequency(rule.frequency);
    setCustomIntervalStr(String(rule.customIntervalDays || 15));
    setStartDate(rule.startDate);
    setEndDate(rule.endDate || '');
    setNextDate(rule.nextExecutionDate);
    setAutoPost(rule.autoPost);
    setIsAddOpen(true);
  };

  const handleSaveRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const now = new Date().toISOString();
    const customIntervalDays =
      frequency === 'custom' ? Math.max(1, parseInt(customIntervalStr, 10) || 15) : undefined;

    if (editingRule) {
      const updated = snapshot.recurringTransactions.map((r) =>
        r.id === editingRule.id
          ? {
              ...r,
              title: title.trim(),
              type,
              amountPoisha: toPoisha(amountStr),
              accountId,
              categoryId,
              frequency,
              customIntervalDays,
              startDate,
              endDate: endDate || undefined,
              nextExecutionDate: nextDate,
              autoPost,
              updatedAt: now,
            }
          : r
      );
      onUpdateSnapshot(
        { ...snapshot, recurringTransactions: updated },
        `Updated recurring rule "${title.trim()}".`
      );
      setIsAddOpen(false);
      setEditingRule(null);
      return;
    }

    const newRule: RecurringTransaction = {
      id: `rec_${Date.now()}`,
      title: title.trim(),
      type,
      amountPoisha: toPoisha(amountStr),
      accountId,
      categoryId,
      frequency,
      customIntervalDays,
      startDate,
      endDate: endDate || undefined,
      nextExecutionDate: nextDate,
      autoPost,
      status: 'active',
      description: `${frequency} scheduled ${type}`,
      createdAt: now,
      updatedAt: now,
    };
    onUpdateSnapshot(
      {
        ...snapshot,
        recurringTransactions: [newRule, ...snapshot.recurringTransactions],
      },
      `Created recurring rule "${newRule.title}".`
    );
    setIsAddOpen(false);
    setTitle('');
  };

  const handleDeleteRule = (ruleId: string) => {
    onUpdateSnapshot(
      {
        ...snapshot,
        recurringTransactions: snapshot.recurringTransactions.filter((r) => r.id !== ruleId),
      },
      'Deleted recurring rule.'
    );
  };

  const handleExecuteNow = (ruleId: string) => {
    const res = FinancialEngine.executeRecurringRule(snapshot, ruleId);
    if (res.ok) {
      onUpdateSnapshot(
        res.snapshot,
        'Posted recurring transaction and advanced next execution date (duplicate-protected).'
      );
    } else {
      onUpdateSnapshot(snapshot, res.error || 'Already posted for this cycle.');
    }
  };

  const handleStatusChange = (ruleId: string, status: RecurringTransaction['status']) => {
    const updated = snapshot.recurringTransactions.map((r) =>
      r.id === ruleId ? { ...r, status, updatedAt: new Date().toISOString() } : r
    );
    onUpdateSnapshot({ ...snapshot, recurringTransactions: updated }, `Updated recurring status to ${status}.`);
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Recurring Transactions & Bill Automation
          </h3>
          <p className="text-xs text-slate-500">
            Daily, Weekly, Monthly, Quarterly, Yearly & Custom intervals with idempotent duplicate protection
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateRuleModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
        >
          <Plus className="w-3.5 h-3.5" /> Add Recurring Rule
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {snapshot.recurringTransactions.map((rule) => {
          const postedCount = snapshot.transactions.filter(
            (t) => t.recurringId === rule.id
          ).length;
          return (
            <div
              key={rule.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {rule.title}
                    </h4>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-full ${
                        rule.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700'
                          : rule.status === 'paused'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {rule.status}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Frequency:{' '}
                    <strong>
                      {rule.frequency === 'custom'
                        ? `Every ${rule.customIntervalDays || 15} Days`
                        : rule.frequency.toUpperCase()}
                    </strong>{' '}
                    • {rule.autoPost ? 'Auto-Post' : 'Confirmation-based'} • {postedCount} posted
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">
                    {fmtMoney(rule.amountPoisha)}
                  </span>
                  <button
                    type="button"
                    onClick={() => openEditRuleModal(rule)}
                    title="Edit Recurring Rule"
                    className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteRule(rule.id)}
                    title="Delete Rule"
                    className="p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="text-xs text-slate-500 flex justify-between">
                <span>Next Execution: {rule.nextExecutionDate}</span>
                <span>Last Posted: {rule.lastExecutedDate || 'Never'}</span>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                {rule.status === 'active' && (
                  <button
                    type="button"
                    onClick={() => handleExecuteNow(rule.id)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold"
                  >
                    Execute Now
                  </button>
                )}
                {rule.status === 'active' ? (
                  <button
                    type="button"
                    onClick={() => handleStatusChange(rule.id, 'paused')}
                    className="px-3 py-1.5 rounded-xl bg-amber-100 text-amber-800 text-xs font-semibold flex items-center gap-1"
                  >
                    <Pause className="w-3 h-3" /> Pause
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleStatusChange(rule.id, 'active')}
                    className="px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center gap-1"
                  >
                    <Play className="w-3 h-3" /> Resume
                  </button>
                )}
                {rule.status !== 'cancelled' && (
                  <button
                    type="button"
                    onClick={() => handleStatusChange(rule.id, 'cancelled')}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold flex items-center gap-1"
                  >
                    <XCircle className="w-3 h-3" /> Cancel
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              {editingRule
                ? `Edit Recurring Rule "${editingRule.title}"`
                : 'Create Recurring Transaction Rule'}
            </h3>
            <form onSubmit={handleSaveRule} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., House Rent, Netflix, Monthly Salary"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                    <option value="transfer">Transfer</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Amount (৳) *
                  </label>
                  <input
                    type="number"
                    required
                    value={amountStr}
                    onChange={(e) => setAmountStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Frequency
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as RecurrenceFrequency)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="yearly">Yearly</option>
                    <option value="custom">Custom Interval (Days)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Next Execution Date
                  </label>
                  <input
                    type="date"
                    value={nextDate}
                    onChange={(e) => setNextDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              {frequency === 'custom' && (
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Custom Interval (Days)
                  </label>
                  <input
                    type="number"
                    value={customIntervalStr}
                    onChange={(e) => setCustomIntervalStr(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    End Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 pt-1">
                <input
                  type="checkbox"
                  checked={autoPost}
                  onChange={(e) => setAutoPost(e.target.checked)}
                />
                <span>Automatically post on due date without manual confirmation</span>
              </label>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddOpen(false);
                    setEditingRule(null);
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 text-white"
                >
                  Save Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
