// ============================================================================
// PHASE 2: DASHBOARD MODULE
// Displays all 8 live KPIs, 7 Date Range Filters, Income vs Expense Chart,
// Category-wise Spending Donut Chart, Account Balance Overview, Budget Progress
// Cards, Upcoming Recurring Bills & Loan EMIs, Recent Debt Activities, Savings
// Goal Progress, and Recent Transactions.
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRightLeft,
  ArrowUpRight,
  Calendar,
  CheckCircle2,
  Clock,
  CreditCard,
  Eye,
  Flame,
  HandCoins,
  Landmark,
  PiggyBank,
  Plus,
  RefreshCw,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DatabaseSnapshot, Transaction } from '../types/models';
import { FinancialEngine } from '../engine/financialEngine';
import { formatCurrency } from '../utils/money';
import { t } from '../i18n/translations';

export type DashboardDateFilter =
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'this_month'
  | 'last_month'
  | 'this_year'
  | 'custom';

export interface DashboardModuleProps {
  snapshot: DatabaseSnapshot;
  onNavigate: (tab: string) => void;
  onOpenQuickAdd: (defaultType?: Transaction['type']) => void;
  onEditTransaction: (tx: Transaction) => void;
  onExecuteRecurring: (ruleId: string) => void;
}

export function getDateRangeForFilter(
  filter: DashboardDateFilter,
  customStart: string,
  customEnd: string,
  referenceDateStr = '2026-11-06'
): { from: string; to: string; label: string } {
  const ref = new Date(referenceDateStr + 'T00:00:00');
  const fmt = (d: Date) => d.toISOString().slice(0, 10);

  switch (filter) {
    case 'today':
      return { from: referenceDateStr, to: referenceDateStr, label: 'Today (6 Nov 2026)' };
    case 'yesterday': {
      const y = new Date(ref);
      y.setDate(y.getDate() - 1);
      const s = fmt(y);
      return { from: s, to: s, label: 'Yesterday (5 Nov 2026)' };
    }
    case 'this_week': {
      const start = new Date(ref);
      start.setDate(ref.getDate() - 6);
      return { from: fmt(start), to: referenceDateStr, label: 'Last 7 Days' };
    }
    case 'this_month': {
      const start = `${referenceDateStr.slice(0, 7)}-01`;
      const end = `${referenceDateStr.slice(0, 7)}-30`;
      return { from: start, to: end, label: 'November 2026' };
    }
    case 'last_month': {
      return { from: '2026-10-01', to: '2026-10-31', label: 'October 2026' };
    }
    case 'this_year': {
      return { from: '2026-01-01', to: '2026-12-31', label: 'Year 2026' };
    }
    case 'custom':
      return {
        from: customStart || '2026-11-01',
        to: customEnd || '2026-11-30',
        label: `${customStart} to ${customEnd}`,
      };
  }
}

export const DashboardModule: React.FC<DashboardModuleProps> = ({
  snapshot,
  onNavigate,
  onOpenQuickAdd,
  onEditTransaction,
  onExecuteRecurring,
}) => {
  const lang = snapshot.settings.language;
  const currency = snapshot.settings.defaultCurrency;
  const numberFormat = snapshot.settings.numberFormat;
  const precision = snapshot.settings.currencyPrecision;

  const [dateFilter, setDateFilter] = useState<DashboardDateFilter>('this_month');
  const [customStart, setCustomStart] = useState<string>('2026-11-01');
  const [customEnd, setCustomEnd] = useState<string>('2026-11-30');

  const fmtMoney = (poisha: number, showPlus = false) =>
    formatCurrency(poisha, { currency, numberFormat, precision, showPlus });

  const dateRange = useMemo(
    () => getDateRangeForFilter(dateFilter, customStart, customEnd),
    [dateFilter, customStart, customEnd]
  );

  const metrics = useMemo(
    () => FinancialEngine.computeDashboardMetrics(snapshot, dateRange.from, dateRange.to),
    [snapshot, dateRange]
  );

  const activeBudgetEval = useMemo(() => {
    const b = snapshot.budgets[0];
    return b ? FinancialEngine.evaluateBudget(snapshot, b.id) : null;
  }, [snapshot]);

  // Daily/Period Income vs Expense BarChart data derived strictly from DB transactions
  const cashFlowChartData = useMemo(() => {
    const map: Record<string, { label: string; income: number; expense: number }> = {};
    const filtered = snapshot.transactions.filter(
      (tx) => tx.date >= dateRange.from && tx.date <= dateRange.to
    );
    for (const tx of filtered) {
      const key = tx.date.slice(5); // MM-DD
      if (!map[key]) {
        map[key] = { label: key, income: 0, expense: 0 };
      }
      if (tx.type === 'income') {
        map[key].income += Math.round(tx.amountPoisha / 100);
      } else if (tx.type === 'expense') {
        map[key].expense += Math.round(tx.amountPoisha / 100);
      } else if (tx.type === 'refund') {
        map[key].expense = Math.max(0, map[key].expense - Math.round(tx.amountPoisha / 100));
      }
    }
    const sorted = Object.values(map).sort((a, b) => a.label.localeCompare(b.label));
    return sorted.length > 0
      ? sorted
      : [{ label: dateRange.from.slice(5), income: 0, expense: 0 }];
  }, [snapshot.transactions, dateRange]);

  // Category-wise spending PieChart data derived strictly from DB transactions & splits
  const categoryChartData = useMemo(() => {
    const catMap = FinancialEngine.computeCategoryNetExpenses(
      snapshot,
      dateRange.from,
      dateRange.to
    );
    return Object.entries(catMap)
      .filter(([, poisha]) => poisha > 0)
      .map(([catId, poisha]) => {
        const cat = snapshot.categories.find((c) => c.id === catId);
        return {
          name: cat ? (lang === 'bn' ? cat.nameBn : cat.name) : catId,
          value: Math.round(poisha / 100),
          poisha,
          color: cat?.color || '#10b981',
        };
      })
      .sort((a, b) => b.poisha - a.poisha);
  }, [snapshot, dateRange, lang]);

  const recentTransactions = useMemo(() => {
    return [...snapshot.transactions]
      .filter((tx) => tx.date >= dateRange.from && tx.date <= dateRange.to)
      .sort((a, b) => `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`))
      .slice(0, 6);
  }, [snapshot.transactions, dateRange]);

  return (
    <div className="space-y-6 pb-8">
      {/* Top Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {dateRange.label}
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {(
              [
                ['today', t(lang, 'filterToday')],
                ['yesterday', t(lang, 'filterYesterday')],
                ['this_week', t(lang, 'filterThisWeek')],
                ['this_month', t(lang, 'filterThisMonth')],
                ['last_month', t(lang, 'filterLastMonth')],
                ['this_year', t(lang, 'filterThisYear')],
                ['custom', t(lang, 'filterCustom')],
              ] as Array<[DashboardDateFilter, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setDateFilter(key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  dateFilter === key
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {dateFilter === 'custom' && (
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-500">From:</label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-500">To:</label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
          </div>
        )}
      </div>

      {/* 8 Core Financial KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* 1. Total Balance */}
        <div
          onClick={() => onNavigate('accounts')}
          className="cursor-pointer bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-100">{t(lang, 'totalBalance')}</span>
            <Wallet className="w-4 h-4 text-emerald-200" />
          </div>
          <div className="text-lg sm:text-xl font-bold mt-2 tracking-tight">
            {fmtMoney(metrics.totalBalancePoisha)}
          </div>
          <div className="text-[11px] text-emerald-100 mt-1 flex items-center justify-between">
            <span>Net Worth: {fmtMoney(metrics.netWorthPoisha)}</span>
          </div>
        </div>

        {/* 2. Total Income */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'totalIncome')}
            </span>
            <span className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-2">
            {fmtMoney(metrics.totalIncomePoisha, true)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Excludes transfers & loans</div>
        </div>

        {/* 3. Total Expenses */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'totalExpenses')}
            </span>
            <span className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
              <ArrowDownRight className="w-4 h-4" />
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-rose-600 dark:text-rose-400 mt-2">
            {fmtMoney(metrics.totalExpensePoisha)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Net of expense refunds</div>
        </div>

        {/* 4. Net Cash Flow */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'netCashFlow')}
            </span>
            <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div
            className={`text-lg sm:text-xl font-bold mt-2 ${
              metrics.netCashFlowPoisha >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {fmtMoney(metrics.netCashFlowPoisha, true)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Income minus Expenses</div>
        </div>

        {/* 5. Total Receivable (Pawna) */}
        <div
          onClick={() => onNavigate('debts')}
          className="cursor-pointer bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 hover:border-sky-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'totalReceivable')}
            </span>
            <span className="p-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400">
              <HandCoins className="w-4 h-4" />
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-sky-600 dark:text-sky-400 mt-2">
            {fmtMoney(metrics.totalReceivablePoisha)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Money others owe me</div>
        </div>

        {/* 6. Total Payable (Dena) */}
        <div
          onClick={() => onNavigate('debts')}
          className="cursor-pointer bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 hover:border-amber-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'totalPayable')}
            </span>
            <span className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-amber-600 dark:text-amber-400 mt-2">
            {fmtMoney(metrics.totalPayablePoisha)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            + Loans: {fmtMoney(metrics.remainingLoanLiabilityPoisha)}
          </div>
        </div>

        {/* 7. Total Savings */}
        <div
          onClick={() => onNavigate('savings')}
          className="cursor-pointer bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 hover:border-teal-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'totalSavings')}
            </span>
            <span className="p-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
              <PiggyBank className="w-4 h-4" />
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-teal-600 dark:text-teal-400 mt-2">
            {fmtMoney(metrics.totalSavingsPoisha)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Across {snapshot.savingsGoals.length} active goals
          </div>
        </div>

        {/* 8. Monthly Budget Usage */}
        <div
          onClick={() => onNavigate('budgets')}
          className="cursor-pointer bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 hover:border-violet-400 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t(lang, 'monthlyBudgetUsage')}
            </span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300">
              {metrics.monthlyBudgetPercent.toFixed(1)}%
            </span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mt-2">
            {fmtMoney(metrics.monthlyBudgetSpentPoisha)}
          </div>
          <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mt-2">
            <div
              className={`h-full rounded-full ${
                metrics.monthlyBudgetPercent >= 100
                  ? 'bg-rose-500'
                  : metrics.monthlyBudgetPercent >= 75
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, metrics.monthlyBudgetPercent)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quick Action Bar */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => onOpenQuickAdd('expense')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" /> Record Expense
        </button>
        <button
          type="button"
          onClick={() => onOpenQuickAdd('income')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" /> Record Income
        </button>
        <button
          type="button"
          onClick={() => onOpenQuickAdd('transfer')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm"
        >
          <ArrowRightLeft className="w-3.5 h-3.5" /> Transfer Money
        </button>
        <button
          type="button"
          onClick={() => onNavigate('debts')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold shadow-sm"
        >
          <HandCoins className="w-3.5 h-3.5" /> Dena-Pawna Ledger
        </button>
      </div>

      {/* Interactive Charts Row: Income vs Expense & Category Spending */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Income vs Expense Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t(lang, 'incomeVsExpense')}
              </h3>
              <p className="text-xs text-slate-500">Live calculation from database ledger</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="text-xs font-medium text-emerald-600 hover:underline"
            >
              Full Analytics
            </button>
          </div>
          <div className="relative h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cashFlowChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="income" name="Income (৳)" fill="#10b981" radius={[6, 6, 0, 0]} />
                <Bar dataKey="expense" name="Expense (৳)" fill="#f43f5e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category-wise Spending Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t(lang, 'categorySpending')}
              </h3>
              <p className="text-xs text-slate-500">Includes split transaction breakdowns</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('categories')}
              className="text-xs font-medium text-emerald-600 hover:underline"
            >
              Manage Categories
            </button>
          </div>
          {categoryChartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-xs text-slate-400">
              No expenses recorded in this date window.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
              <div className="relative h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryChartData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={78}
                      paddingAngle={3}
                    >
                      {categoryChartData.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {categoryChartData.map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="font-medium text-slate-700 dark:text-slate-200 truncate">
                        {item.name}
                      </span>
                    </div>
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {fmtMoney(item.poisha)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Account Balances & Budget Progress Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Account Balance Overview */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t(lang, 'accountBalances')}
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('accounts')}
              className="text-xs font-medium text-emerald-600 hover:underline"
            >
              View All ({snapshot.accounts.filter((a) => a.status === 'active').length})
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {snapshot.accounts
              .filter((a) => a.status === 'active')
              .map((acc) => (
                <div
                  key={acc.id}
                  onClick={() => onNavigate('accounts')}
                  className="cursor-pointer p-3 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-emerald-400 flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className="w-3 h-8 rounded-full shrink-0"
                      style={{ backgroundColor: acc.color }}
                    />
                    <div className="truncate">
                      <div className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                        {lang === 'bn' && acc.nameBn ? acc.nameBn : acc.name}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase">{acc.type}</div>
                    </div>
                  </div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white shrink-0 ml-2">
                    {formatCurrency(acc.currentBalancePoisha, {
                      currency: acc.currency,
                      numberFormat,
                      precision,
                    })}
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Category Budget Progress Cards */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t(lang, 'budgetProgress')}
              </h3>
              <p className="text-xs text-slate-500">
                {activeBudgetEval ? activeBudgetEval.budget.name : 'Monthly Category Caps'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('budgets')}
              className="text-xs font-medium text-emerald-600 hover:underline"
            >
              Configure Budgets
            </button>
          </div>
          {activeBudgetEval ? (
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {activeBudgetEval.categoryBreakdown.map((item) => (
                <div key={item.categoryId} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: item.categoryColor }}
                      />
                      {item.categoryName}
                      {item.status === 'exceeded' && (
                        <span className="px-1.5 py-0.5 text-[10px] rounded bg-rose-100 text-rose-700 font-bold">
                          100% Limit
                        </span>
                      )}
                      {item.status === 'warning_75' && (
                        <span className="px-1.5 py-0.5 text-[10px] rounded bg-amber-100 text-amber-700 font-bold">
                          75%+ Alert
                        </span>
                      )}
                    </span>
                    <span className="text-slate-600 dark:text-slate-400">
                      <strong className="text-slate-900 dark:text-white">
                        {fmtMoney(item.spentPoisha)}
                      </strong>{' '}
                      / {fmtMoney(item.allocatedPoisha)} ({item.percentUsed.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        item.status === 'exceeded'
                          ? 'bg-rose-500'
                          : item.status === 'warning_90' || item.status === 'warning_75'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, item.percentUsed)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-xs text-slate-400">No active budget configured.</div>
          )}
        </div>
      </div>

      {/* Upcoming Bills, Loan EMIs, Dena-Pawna & Savings Progress */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Upcoming Bills & Recurring */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t(lang, 'upcomingBills')}
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('recurring')}
              className="text-xs text-emerald-600 hover:underline"
            >
              Manage
            </button>
          </div>
          <div className="space-y-2.5">
            {snapshot.recurringTransactions
              .filter((r) => r.status === 'active')
              .map((rule) => (
                <div
                  key={rule.id}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {rule.title}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Next: {rule.nextExecutionDate} ({rule.frequency})
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {fmtMoney(rule.amountPoisha)}
                    </span>
                    <button
                      type="button"
                      onClick={() => onExecuteRecurring(rule.id)}
                      className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-semibold"
                    >
                      Post
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Upcoming Loan Payments & Recent Debts */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Loans & Dena-Pawna
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('loans')}
              className="text-xs text-emerald-600 hover:underline"
            >
              All EMIs
            </button>
          </div>
          <div className="space-y-2.5">
            {snapshot.loans
              .filter((l) => l.status === 'active')
              .map((loan) => (
                <div
                  key={loan.id}
                  onClick={() => onNavigate('loans')}
                  className="cursor-pointer p-2.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                      {loan.name}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Due: {loan.nextDueDate} ({loan.paidInstallments}/{loan.totalInstallments} paid)
                    </div>
                  </div>
                  <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    {fmtMoney(loan.installmentAmountPoisha)}
                  </div>
                </div>
              ))}

            {snapshot.debts.slice(0, 2).map((debt) => (
              <div
                key={debt.id}
                onClick={() => onNavigate('debts')}
                className="cursor-pointer p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                    {debt.personName}{' '}
                    <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700">
                      {debt.direction === 'receivable' ? 'Pawna' : 'Dena'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500">Due: {debt.dueDate}</div>
                </div>
                <div
                  className={`text-xs font-bold ${
                    debt.direction === 'receivable' ? 'text-sky-600' : 'text-amber-600'
                  }`}
                >
                  {fmtMoney(debt.remainingPoisha)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Savings Goals Progress */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t(lang, 'savingsProgress')}
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('savings')}
              className="text-xs text-emerald-600 hover:underline"
            >
              Add Goal
            </button>
          </div>
          <div className="space-y-3">
            {snapshot.savingsGoals.map((goal) => {
              const pct = Math.min(
                100,
                Math.round((goal.savedAmountPoisha / Math.max(1, goal.targetAmountPoisha)) * 100)
              );
              return (
                <div key={goal.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {goal.name}
                    </span>
                    <span className="font-bold text-teal-600 dark:text-teal-400">{pct}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, backgroundColor: goal.color }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Saved: {fmtMoney(goal.savedAmountPoisha)}</span>
                    <span>Target: {fmtMoney(goal.targetAmountPoisha)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Transactions Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200/80 dark:border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            {t(lang, 'recentTransactions')}
          </h3>
          <button
            type="button"
            onClick={() => onNavigate('transactions')}
            className="text-xs font-medium text-emerald-600 hover:underline"
          >
            View All Ledger Entries ({snapshot.transactions.length})
          </button>
        </div>
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {recentTransactions.map((tx) => {
            const cat = snapshot.categories.find((c) => c.id === tx.categoryId);
            const acc = snapshot.accounts.find((a) => a.id === tx.accountId);
            const isPositive =
              tx.type === 'income' ||
              tx.type === 'refund' ||
              tx.type === 'loan_received' ||
              tx.type === 'debt_collection';
            return (
              <div
                key={tx.id}
                onClick={() => onEditTransaction(tx)}
                className="cursor-pointer py-3 flex items-center justify-between gap-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 px-2 rounded-xl transition-all"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                    style={{ backgroundColor: cat?.color || '#10b981' }}
                  >
                    {tx.type.slice(0, 3).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                      <span>{tx.description}</span>
                      {tx.isSplit && (
                        <span className="px-1.5 py-0.5 text-[10px] rounded bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                          Split
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-2">
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span>{acc?.name || tx.accountId}</span>
                      <span>•</span>
                      <span>{cat ? (lang === 'bn' ? cat.nameBn : cat.name) : tx.type}</span>
                    </div>
                  </div>
                </div>
                <div
                  className={`text-xs sm:text-sm font-bold shrink-0 ${
                    tx.type === 'transfer'
                      ? 'text-indigo-600 dark:text-indigo-400'
                      : isPositive
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {tx.type === 'transfer'
                    ? `⇄ ${fmtMoney(tx.amountPoisha)}`
                    : `${isPositive ? '+' : '-'} ${fmtMoney(tx.amountPoisha)}`}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
