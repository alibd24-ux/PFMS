// ============================================================================
// DECIMAL-SAFE FINANCIAL ARITHMETIC & BANGLADESHI CURRENCY FORMATTING
// Uses integer minor units (1 Taka = 100 Poisha) for all monetary storage and
// calculations. Never uses floating-point addition/subtraction on floats.
// ============================================================================

import { CurrencyCode, NumberFormatStyle } from '../types/models';

export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  BDT: '৳',
  USD: '$',
  EUR: '€',
  GBP: '£',
  INR: '₹',
};

const EN_TO_BN_DIGITS: Record<string, string> = {
  '0': '০',
  '1': '১',
  '2': '২',
  '3': '৩',
  '4': '৪',
  '5': '৫',
  '6': '৬',
  '7': '৭',
  '8': '৮',
  '9': '৯',
};

export function toBengaliDigits(str: string): string {
  return str.replace(/[0-9]/g, (d) => EN_TO_BN_DIGITS[d] || d);
}

/**
 * Safely parses a user-entered string or number into integer minor units (poisha).
 * Example: "125000.50" -> 12500050 poisha.
 * Avoids float multiplication drift by splitting whole and fractional parts.
 */
export function toPoisha(input: string | number): number {
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return 0;
    return Math.round(input * 100);
  }
  const cleaned = String(input)
    .replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)))
    .replace(/[^0-9.-]/g, '')
    .trim();
  if (!cleaned || cleaned === '-' || cleaned === '.') return 0;
  const isNegative = cleaned.startsWith('-');
  const unsigned = cleaned.replace(/^-/, '');
  const parts = unsigned.split('.');
  const wholeStr = parts[0] || '0';
  const fracStr = (parts[1] || '').padEnd(2, '0').slice(0, 2);
  const thirdDigit = Number((parts[1] || '')[2] || '0');
  const whole = parseInt(wholeStr, 10) || 0;
  const frac = parseInt(fracStr, 10) || 0;
  let totalPoisha = whole * 100 + frac;
  if (thirdDigit >= 5) totalPoisha += 1;
  return isNegative ? -totalPoisha : totalPoisha;
}

/**
 * Converts integer poisha to a major-unit string with 2 decimal places (e.g., "1250.50").
 */
export function poishaToMajorString(poisha: number, precision: 0 | 2 = 2): string {
  const safe = Math.round(Number(poisha) || 0);
  const isNegative = safe < 0;
  const abs = Math.abs(safe);
  const whole = Math.floor(abs / 100);
  const frac = abs % 100;
  if (precision === 0) {
    const roundedWhole = frac >= 50 ? whole + 1 : whole;
    return `${isNegative ? '-' : ''}${roundedWhole}`;
  }
  return `${isNegative ? '-' : ''}${whole}.${String(frac).padStart(2, '0')}`;
}

/**
 * Formats an integer number string using Bangladeshi / South Asian Lakh-Crore grouping:
 * last 3 digits, then groups of 2 digits: 125000 -> "1,25,000"
 */
export function formatIndianLakhGrouping(intStr: string): string {
  const clean = intStr.replace(/^0+(?=\d)/, '');
  if (clean.length <= 3) return clean;
  const lastThree = clean.slice(-3);
  const rest = clean.slice(0, -3);
  const groupedRest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return `${groupedRest},${lastThree}`;
}

/**
 * Formats an integer number string using standard international 3-digit grouping:
 * 125000 -> "125,000"
 */
export function formatInternationalGrouping(intStr: string): string {
  const clean = intStr.replace(/^0+(?=\d)/, '');
  return clean.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * Formats poisha into a display currency string.
 * Default Bengali/Bangladeshi style: `৳ 1,25,000.00` (or `৳ ১,২৫,০০০.০০` when bn_digits is active).
 */
export function formatCurrency(
  poisha: number,
  options?: {
    currency?: CurrencyCode;
    numberFormat?: NumberFormatStyle;
    precision?: 0 | 2;
    showPlus?: boolean;
  }
): string {
  const currency = options?.currency || 'BDT';
  const numberFormat = options?.numberFormat || 'bd_lakh';
  const precision = options?.precision !== undefined ? options.precision : 2;
  const symbol = CURRENCY_SYMBOLS[currency] || '৳';

  const safe = Math.round(Number(poisha) || 0);
  const isNegative = safe < 0;
  const abs = Math.abs(safe);
  let whole = Math.floor(abs / 100);
  const frac = abs % 100;
  if (precision === 0 && frac >= 50) {
    whole += 1;
  }

  const wholeStr = String(whole);
  const groupedWhole =
    numberFormat === 'intl'
      ? formatInternationalGrouping(wholeStr)
      : formatIndianLakhGrouping(wholeStr);

  const decimalPart = precision === 2 ? `.${String(frac).padStart(2, '0')}` : '';
  let formattedNumber = `${groupedWhole}${decimalPart}`;

  if (numberFormat === 'bn_digits') {
    formattedNumber = toBengaliDigits(formattedNumber);
  }

  const signPrefix = isNegative ? '- ' : options?.showPlus && safe > 0 ? '+ ' : '';
  return `${signPrefix}${symbol} ${formattedNumber}`;
}

/**
 * Safe integer arithmetic helpers
 */
export const MoneyMath = {
  add: (...amountsPoisha: number[]): number => {
    return amountsPoisha.reduce((acc, val) => acc + Math.round(val || 0), 0);
  },
  subtract: (aPoisha: number, bPoisha: number): number => {
    return Math.round(aPoisha || 0) - Math.round(bPoisha || 0);
  },
  percentage: (partPoisha: number, totalPoisha: number): number => {
    if (!totalPoisha || totalPoisha <= 0) return 0;
    return Math.round((partPoisha / totalPoisha) * 10000) / 100; // 2 decimal percentage
  },
  convertToBase: (
    amountPoisha: number,
    currency: CurrencyCode,
    baseCurrency: CurrencyCode,
    rates: Record<CurrencyCode, number>
  ): number => {
    if (currency === baseCurrency) return Math.round(amountPoisha);
    const fromRate = rates[currency] || 1;
    const toRate = rates[baseCurrency] || 1;
    return Math.round((amountPoisha * fromRate) / toRate);
  },
};
