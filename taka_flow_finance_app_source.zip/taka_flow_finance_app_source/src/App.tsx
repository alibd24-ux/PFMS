// ============================================================================
// ROOT APPLICATION SHELL (Material Design 3 Mobile-First & Desktop Responsive)
// Connects IndexedDB Repository, Centralized Financial Engine, Bottom Nav
// (1. Home, 2. Transactions, 3. Budgets, 4. Accounts, 5. More), Floating Add
// Transaction Button, Universal Transaction Modal (with Split & Receipt support),
// Notification Center, and Android Back-Button history integration.
// ============================================================================

import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  BarChart3,
  Briefcase,
  CheckCircle2,
  CreditCard,
  Database,
  FolderTree,
  Globe,
  HandCoins,
  Home,
  Layers,
  ListOrdered,
  Menu,
  Moon,
  Paperclip,
  PieChart as PieChartIcon,
  PiggyBank,
  Plus,
  RefreshCw,
  Settings,
  ShieldCheck,
  Split,
  Sun,
  Wallet,
  X,
} from 'lucide-react';
import {
  Attachment,
  DatabaseSnapshot,
  Transaction,
  TransactionType,
} from './types/models';
import { createInitialSeedSnapshot, IndexedDBRepository } from './db/database';
import { FinancialEngine } from './engine/financialEngine';
import { formatCurrency, poishaToMajorString, toPoisha } from './utils/money';
import { t } from './i18n/translations';
import { DashboardModule } from './modules/DashboardModule';
import { TransactionsModule } from './modules/TransactionsModule';
import { AccountsModule } from './modules/AccountsModule';
import { CategoriesModule } from './modules/CategoriesModule';
import { BudgetsModule } from './modules/BudgetsModule';
import { DebtsModule } from './modules/DebtsModule';
import {
  LoansModule,
  RecurringModule,
  SavingsModule,
} from './modules/LoansSavingsRecurringModule';
import { ReportsModule } from './modules/ReportsModule';
import { DataManagementModule, SettingsModule } from './modules/SettingsDataModule';

const dbRepo = new IndexedDBRepository();

export default function App() {
  const [snapshot, setSnapshot] = useState<DatabaseSnapshot>(() =>
    FinancialEngine.recalculateSnapshotIntegrity(createInitialSeedSnapshot())
  );
  const [activeTab, setActiveTab] = useState<string>('home');
  const [showMoreDrawer, setShowMoreDrawer] = useState(false);
  const [showNotifPanel, setShowNotifPanel] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [preRestoreBackup, setPreRestoreBackup] = useState<DatabaseSnapshot | null>(null);

  // Universal Add/Edit Transaction Modal State
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [txType, setTxType] = useState<TransactionType>('expense');
  const [txAmountStr, setTxAmountStr] = useState('');
  const [txDate, setTxDate] = useState('2026-11-06');
  const [txTime, setTxTime] = useState('14:30');
  const [txAccountId, setTxAccountId] = useState('acc_bank');
  const [txDestAccountId, setTxDestAccountId] = useState('acc_cash');
  const [txCategoryId, setTxCategoryId] = useState('cat_food');
  const [txSubcategoryId, setTxSubcategoryId] = useState('');
  const [txPersonName, setTxPersonName] = useState('');
  const [txDescription, setTxDescription] = useState('');
  const [txNotes, setTxNotes] = useState('');
  const [txTagsStr, setTxTagsStr] = useState('');
  const [txPaymentMethod, setTxPaymentMethod] = useState('Cash');
  const [txIsSplit, setTxIsSplit] = useState(false);
  const [txSplits, setTxSplits] = useState<
    Array<{ categoryId: string; subcategoryId?: string; amountStr: string; note: string }>
  >([]);
  const [txAttachmentName, setTxAttachmentName] = useState('');
  const [txError, setTxError] = useState<string | null>(null);

  // Load persisted IndexedDB snapshot on mount
  useEffect(() => {
    let mounted = true;
    dbRepo.loadSnapshot().then((loaded) => {
      if (mounted && loaded) {
        setSnapshot(FinancialEngine.recalculateSnapshotIntegrity(loaded));
        setPreRestoreBackup(dbRepo.getPreRestoreBackup());
      }
    });
    return () => {
      mounted = false;
    };
  }, []);

  // Android hardware back-button / history state support
  useEffect(() => {
    const onPopState = (e: PopStateEvent) => {
      if (isTxModalOpen) {
        setIsTxModalOpen(false);
        return;
      }
      if (showMoreDrawer) {
        setShowMoreDrawer(false);
        return;
      }
      if (e.state && e.state.tab) {
        setActiveTab(e.state.tab);
      } else {
        setActiveTab('home');
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [isTxModalOpen, showMoreDrawer]);

  const navigateToTab = (tab: string) => {
    setActiveTab(tab);
    setShowMoreDrawer(false);
    try {
      window.history.pushState({ tab }, '', `#${tab}`);
    } catch {
      // Ignore in sandboxed iframe
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3800);
  };

  const handleUpdateSnapshot = (next: DatabaseSnapshot, message?: string) => {
    const reconciled = FinancialEngine.recalculateSnapshotIntegrity(next);
    setSnapshot(reconciled);
    dbRepo.saveSnapshot(reconciled);
    if (message) triggerToast(message);
  };

  const openQuickAddTransaction = (defaultType?: TransactionType, fromAccountId?: string) => {
    const chosenType = defaultType || snapshot.settings.defaultTransactionType || 'expense';
    setEditingTx(null);
    setTxType(chosenType);
    setTxAmountStr('');
    setTxDate('2026-11-06');
    setTxTime('15:00');
    setTxAccountId(fromAccountId || snapshot.settings.defaultAccountId || 'acc_bank');
    setTxDestAccountId('acc_cash');
    const firstCat = snapshot.categories.find(
      (c) => c.type === (chosenType === 'income' ? 'income' : 'expense') && !c.isArchived
    );
    setTxCategoryId(firstCat?.id || 'cat_food');
    setTxSubcategoryId('');
    setTxPersonName('');
    setTxDescription('');
    setTxNotes('');
    setTxTagsStr('');
    setTxPaymentMethod('bKash');
    setTxIsSplit(false);
    setTxSplits([
      { categoryId: 'cat_food', amountStr: '', note: 'Part 1' },
      { categoryId: 'cat_grocery', amountStr: '', note: 'Part 2' },
    ]);
    setTxAttachmentName('');
    setTxError(null);
    setIsTxModalOpen(true);
  };

  const openEditTransactionModal = (tx: Transaction) => {
    setEditingTx(tx);
    setTxType(tx.type);
    setTxAmountStr(poishaToMajorString(tx.amountPoisha, 2));
    setTxDate(tx.date);
    setTxTime(tx.time || '12:00');
    setTxAccountId(tx.accountId);
    setTxDestAccountId(tx.destinationAccountId || 'acc_cash');
    setTxCategoryId(tx.categoryId);
    setTxSubcategoryId(tx.subcategoryId || '');
    setTxPersonName(tx.personName || '');
    setTxDescription(tx.description);
    setTxNotes(tx.notes || '');
    setTxTagsStr((tx.tags || []).join(', '));
    setTxPaymentMethod(tx.paymentMethod || 'Cash');
    setTxIsSplit(Boolean(tx.isSplit));
    const existingSplits = snapshot.transactionSplits
      .filter((s) => s.transactionId === tx.id)
      .map((s) => ({
        categoryId: s.categoryId,
        subcategoryId: s.subcategoryId,
        amountStr: poishaToMajorString(s.amountPoisha, 2),
        note: s.note,
      }));
    setTxSplits(
      existingSplits.length > 0
        ? existingSplits
        : [
            { categoryId: 'cat_food', amountStr: '', note: '' },
            { categoryId: 'cat_grocery', amountStr: '', note: '' },
          ]
    );
    setTxAttachmentName(
      tx.attachmentId
        ? snapshot.attachments.find((a) => a.id === tx.attachmentId)?.fileName || 'Receipt.jpg'
        : ''
    );
    setTxError(null);
    setIsTxModalOpen(true);
  };

  const handleSaveTransactionForm = (e: React.FormEvent) => {
    e.preventDefault();
    setTxError(null);

    let attachmentId = editingTx?.attachmentId;
    let nextAttachments = snapshot.attachments;
    if (txAttachmentName.trim() && !attachmentId) {
      attachmentId = `att_${Date.now()}`;
      const newAtt: Attachment = {
        id: attachmentId,
        transactionId: editingTx?.id || 'pending',
        fileName: txAttachmentName.trim(),
        mimeType: 'image/png',
        sizeBytes: 24500,
        dataUrl: 'data:text/plain;base64,UmVjZWlwdCBBdHRhY2htZW50',
        createdAt: new Date().toISOString(),
      };
      nextAttachments = [newAtt, ...snapshot.attachments];
    }

    const parsedSplits = txIsSplit
      ? txSplits.map((s) => ({
          categoryId: s.categoryId,
          subcategoryId: s.subcategoryId,
          amountPoisha: toPoisha(s.amountStr),
          note: s.note,
        }))
      : undefined;

    const res = FinancialEngine.upsertTransaction(
      { ...snapshot, attachments: nextAttachments },
      {
        id: editingTx?.id,
        type: txType,
        amountPoisha: toPoisha(txAmountStr),
        currency: snapshot.settings.defaultCurrency,
        exchangeRateToBase: 1,
        date: txDate,
        time: txTime,
        accountId: txAccountId,
        destinationAccountId: txType === 'transfer' ? txDestAccountId : undefined,
        categoryId: txCategoryId,
        subcategoryId: txSubcategoryId || undefined,
        personName: txPersonName.trim() || undefined,
        description: txDescription.trim() || `${txType.toUpperCase()} Entry`,
        notes: txNotes.trim(),
        tags: txTagsStr
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        paymentMethod: txPaymentMethod,
        attachmentId,
        isSplit: txIsSplit,
        splits: parsedSplits,
      }
    );

    if (!res.ok) {
      setTxError(res.error || 'Validation error');
      return;
    }

    handleUpdateSnapshot(
      res.snapshot,
      editingTx
        ? `Updated transaction "${res.transaction?.description}" and recalculated balances.`
        : `Added ${txType} transaction "${res.transaction?.description}".`
    );
    setIsTxModalOpen(false);
  };

  const isDark =
    snapshot.settings.theme === 'dark' ||
    (snapshot.settings.theme === 'system' &&
      typeof window !== 'undefined' &&
      Boolean(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches));
  const lang = snapshot.settings.language;
  const unreadNotifCount = snapshot.notifications.filter((n) => !n.isRead).length;

  const MORE_MODULES = [
    { key: 'categories', label: t(lang, 'categories'), icon: FolderTree, desc: 'Groups, Subcategories & Merge' },
    { key: 'debts', label: t(lang, 'debts'), icon: HandCoins, desc: 'Receivables (Pawna) & Payables (Dena)' },
    { key: 'loans', label: t(lang, 'loans'), icon: CreditCard, desc: 'Bank Loans, 0% EMIs & Amortization' },
    { key: 'savings', label: t(lang, 'savings'), icon: PiggyBank, desc: 'Emergency & Goal Reserves' },
    { key: 'recurring', label: t(lang, 'recurring'), icon: RefreshCw, desc: 'Scheduled Bills & Salaries' },
    { key: 'reports', label: t(lang, 'reports'), icon: BarChart3, desc: '15 Financial Reports & CSV/PDF Export' },
    { key: 'backup', label: t(lang, 'dataBackup'), icon: Database, desc: 'Full JSON Backup, Restore & CSV Import' },
    { key: 'settings', label: t(lang, 'settings'), icon: Settings, desc: 'Bengali/English, Themes & Preferences' },
  ];

  return (
    <div className={isDark ? 'dark' : ''}>
      <div
        className={`min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col ${
          snapshot.settings.fontSize === 'lg'
            ? 'text-base'
            : snapshot.settings.fontSize === 'sm'
            ? 'text-xs'
            : 'text-sm'
        }`}
      >
        {/* Top App Bar */}
        <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 py-3">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div
              onClick={() => navigateToTab('home')}
              className="cursor-pointer flex items-center gap-2.5"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white font-extrabold text-base shadow-sm">
                ৳
              </div>
              <div>
                <h1 className="text-sm sm:text-base font-extrabold tracking-tight text-slate-900 dark:text-white leading-none">
                  {snapshot.settings.appName || t(lang, 'appTitle')}
                </h1>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {t(lang, 'appSubtitle')}
                </p>
              </div>
            </div>

            {/* Desktop Secondary Module Pills */}
            <div className="hidden xl:flex items-center gap-1">
              {MORE_MODULES.map((m) => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.key}
                    type="button"
                    onClick={() => navigateToTab(m.key)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                      activeTab === m.key
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{m.label.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>

            {/* Right Quick Switches: Language (EN/বাংলা), Theme, Notifications */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  handleUpdateSnapshot(
                    {
                      ...snapshot,
                      settings: {
                        ...snapshot.settings,
                        language: lang === 'en' ? 'bn' : 'en',
                      },
                    },
                    lang === 'en' ? 'বাংলা ভাষা চালু করা হয়েছে' : 'Switched to English'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-emerald-50"
              >
                {lang === 'en' ? 'বাংলা' : 'EN'}
              </button>

              <button
                type="button"
                onClick={() =>
                  handleUpdateSnapshot({
                    ...snapshot,
                    settings: {
                      ...snapshot.settings,
                      theme: isDark ? 'light' : 'dark',
                    },
                  })
                }
                title="Toggle Light/Dark Theme"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              >
                {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={() => setShowNotifPanel(!showNotifPanel)}
                title="Alerts & Audit Logs"
                className="relative p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center">
                    {unreadNotifCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>

        {/* Toast Banner */}
        {toastMessage && (
          <div className="fixed top-16 right-4 z-50 bg-slate-900 dark:bg-emerald-700 text-white px-4 py-2.5 rounded-2xl shadow-lg text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-white shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Notifications & Audit Log Slide-Down Panel */}
        {showNotifPanel && (
          <div className="max-w-7xl mx-auto w-full px-4 pt-3">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-lg border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Notifications & Financial Audit Trail
                </h4>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdateSnapshot({
                        ...snapshot,
                        notifications: snapshot.notifications.map((n) => ({ ...n, isRead: true })),
                      })
                    }
                    className="text-xs text-emerald-600 font-semibold hover:underline"
                  >
                    Mark All Read
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowNotifPanel(false)}
                    className="text-xs text-slate-400"
                  >
                    Close
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-56 overflow-y-auto">
                <div className="space-y-1.5">
                  {snapshot.notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`p-2.5 rounded-xl text-xs border ${
                        n.isRead
                          ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800'
                          : 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900'
                      }`}
                    >
                      <div className="font-bold">{n.title}</div>
                      <div className="text-slate-500 text-[11px]">{n.message}</div>
                    </div>
                  ))}
                </div>
                <div className="space-y-1.5">
                  {snapshot.auditLogs.slice(0, 6).map((log) => (
                    <div
                      key={log.id}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-[11px] flex justify-between gap-2"
                    >
                      <span className="truncate">
                        <strong>[{log.action}]</strong> {log.summary}
                      </span>
                      <span className="text-slate-400 shrink-0">{log.timestamp.slice(11, 16)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 pt-5 pb-24">
          {activeTab === 'home' && (
            <DashboardModule
              snapshot={snapshot}
              onNavigate={navigateToTab}
              onOpenQuickAdd={(tType) => openQuickAddTransaction(tType)}
              onEditTransaction={openEditTransactionModal}
              onExecuteRecurring={(ruleId) => {
                const res = FinancialEngine.executeRecurringRule(snapshot, ruleId);
                if (res.ok) {
                  handleUpdateSnapshot(res.snapshot, 'Posted scheduled recurring transaction.');
                } else {
                  triggerToast(res.error || 'Already posted.');
                }
              }}
            />
          )}

          {activeTab === 'transactions' && (
            <TransactionsModule
              snapshot={snapshot}
              onUpdateSnapshot={handleUpdateSnapshot}
              onOpenModalForEdit={openEditTransactionModal}
              onOpenNewTransactionModal={openQuickAddTransaction}
            />
          )}

          {activeTab === 'budgets' && (
            <BudgetsModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'accounts' && (
            <AccountsModule
              snapshot={snapshot}
              onUpdateSnapshot={handleUpdateSnapshot}
              onOpenTransferModal={(fromId) => openQuickAddTransaction('transfer', fromId)}
            />
          )}

          {activeTab === 'categories' && (
            <CategoriesModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'debts' && (
            <DebtsModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'loans' && (
            <LoansModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'savings' && (
            <SavingsModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'recurring' && (
            <RecurringModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'reports' && <ReportsModule snapshot={snapshot} />}

          {activeTab === 'settings' && (
            <SettingsModule snapshot={snapshot} onUpdateSnapshot={handleUpdateSnapshot} />
          )}

          {activeTab === 'backup' && (
            <DataManagementModule
              snapshot={snapshot}
              onUpdateSnapshot={handleUpdateSnapshot}
              onSavePreRestoreSafetyBackup={(snap) => {
                dbRepo.savePreRestoreBackup(snap);
                setPreRestoreBackup(snap);
              }}
              preRestoreBackup={preRestoreBackup}
            />
          )}

          {activeTab === 'more' && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                All Financial Modules & System Tools
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                {MORE_MODULES.map((m) => {
                  const Icon = m.icon;
                  return (
                    <button
                      key={m.key}
                      type="button"
                      onClick={() => navigateToTab(m.key)}
                      className="text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-emerald-500 shadow-sm transition-all flex items-start gap-3"
                    >
                      <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-900 dark:text-white">
                          {m.label}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">{m.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </main>

        {/* Prominent Floating Add Transaction Button (FAB) */}
        <button
          type="button"
          onClick={() => openQuickAddTransaction()}
          title={t(lang, 'addTransaction')}
          className="fixed bottom-20 right-5 z-40 flex items-center gap-2 px-4 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xl shadow-emerald-600/30 transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">{t(lang, 'addTransaction')}</span>
        </button>

        {/* Material Design 3 Bottom Navigation Bar (1. Home, 2. Transactions, 3. Budgets, 4. Accounts, 5. More) */}
        <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1.5">
          <div className="max-w-xl mx-auto grid grid-cols-5 gap-1">
            {[
              { id: 'home', label: t(lang, 'navHome'), icon: Home },
              { id: 'transactions', label: t(lang, 'navTransactions'), icon: ListOrdered },
              { id: 'budgets', label: t(lang, 'navBudgets'), icon: PieChartIcon },
              { id: 'accounts', label: t(lang, 'navAccounts'), icon: Wallet },
              { id: 'more', label: t(lang, 'navMore'), icon: Menu },
            ].map((item) => {
              const Icon = item.icon;
              const isSelected =
                activeTab === item.id ||
                (item.id === 'more' && MORE_MODULES.some((m) => m.key === activeTab));
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateToTab(item.id)}
                  className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all ${
                    isSelected
                      ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <div
                    className={`px-3 py-0.5 rounded-full ${
                      isSelected ? 'bg-emerald-100/80 dark:bg-emerald-950/80' : ''
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[11px] mt-0.5">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>

        {/* Universal Add / Edit Transaction Modal (All 8 Transaction Types + Splits + Receipts) */}
        {isTxModalOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {editingTx ? 'Edit Transaction' : t(lang, 'addTransaction')}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsTxModalOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {txError && (
                <div className="mb-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-200 text-xs font-medium">
                  {txError}
                </div>
              )}

              <form onSubmit={handleSaveTransactionForm} className="space-y-3.5">
                {/* 8 Transaction Type Selector */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase text-slate-400 mb-1.5">
                    Transaction Type (8 Supported Ledger Types)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {(
                      [
                        ['expense', 'Expense'],
                        ['income', 'Income'],
                        ['transfer', 'Transfer'],
                        ['refund', 'Refund'],
                        ['loan_given', 'Loan Given'],
                        ['loan_received', 'Loan Received'],
                        ['debt_collection', 'Debt Collect'],
                        ['debt_repayment', 'Debt Repay'],
                      ] as Array<[TransactionType, string]>
                    ).map(([tKey, label]) => (
                      <button
                        key={tKey}
                        type="button"
                        onClick={() => {
                          setTxType(tKey);
                          const matchCat = snapshot.categories.find(
                            (c) =>
                              c.type ===
                                (tKey === 'income' || tKey === 'debt_collection'
                                  ? 'income'
                                  : 'expense') && !c.isArchived
                          );
                          if (matchCat) setTxCategoryId(matchCat.id);
                        }}
                        className={`py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all ${
                          txType === tKey
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Amount, Date, Time */}
                <div className="grid grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Amount (৳) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={txAmountStr}
                      onChange={(e) => setTxAmountStr(e.target.value)}
                      placeholder="0.00"
                      className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={txDate}
                      onChange={(e) => setTxDate(e.target.value)}
                      className="w-full px-2.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Time
                    </label>
                    <input
                      type="time"
                      value={txTime}
                      onChange={(e) => setTxTime(e.target.value)}
                      className="w-full px-2.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                </div>

                {/* Source & Destination Account */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      {txType === 'transfer' ? 'From Account *' : 'Account *'}
                    </label>
                    <select
                      value={txAccountId}
                      onChange={(e) => setTxAccountId(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      {snapshot.accounts
                        .filter((a) => a.status === 'active')
                        .map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.name} ({a.currency})
                          </option>
                        ))}
                    </select>
                  </div>

                  {txType === 'transfer' ? (
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                        Destination Account *
                      </label>
                      <select
                        value={txDestAccountId}
                        onChange={(e) => setTxDestAccountId(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        {snapshot.accounts
                          .filter((a) => a.status === 'active' && a.id !== txAccountId)
                          .map((a) => (
                            <option key={a.id} value={a.id}>
                              {a.name} ({a.currency})
                            </option>
                          ))}
                      </select>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                        Category *
                      </label>
                      <select
                        value={txCategoryId}
                        onChange={(e) => {
                          setTxCategoryId(e.target.value);
                          setTxSubcategoryId('');
                        }}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        {snapshot.categories
                          .filter((c) => !c.isArchived && c.isEnabled)
                          .map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name} ({c.groupName})
                            </option>
                          ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Subcategory & Person/Contact */}
                {txType !== 'transfer' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                        Subcategory (Optional)
                      </label>
                      <select
                        value={txSubcategoryId}
                        onChange={(e) => setTxSubcategoryId(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="">-- None --</option>
                        {snapshot.subcategories
                          .filter((s) => s.categoryId === txCategoryId && !s.isArchived)
                          .map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name} ({s.nameBn})
                            </option>
                          ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                        Person / Contact
                      </label>
                      <input
                        type="text"
                        value={txPersonName}
                        onChange={(e) => setTxPersonName(e.target.value)}
                        placeholder="e.g., Tanvir Ahmed"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>
                )}

                {/* Description & Payment Method */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Description *
                    </label>
                    <input
                      type="text"
                      required
                      value={txDescription}
                      onChange={(e) => setTxDescription(e.target.value)}
                      placeholder="What was this transaction for?"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Payment Method
                    </label>
                    <select
                      value={txPaymentMethod}
                      onChange={(e) => setTxPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <option value="Cash">Cash</option>
                      <option value="bKash">bKash</option>
                      <option value="Nagad">Nagad</option>
                      <option value="Rocket">Rocket</option>
                      <option value="Bank EFT">Bank EFT / NPSB</option>
                      <option value="Card">Debit / Credit Card</option>
                    </select>
                  </div>
                </div>

                {/* Split Transaction across Multiple Categories */}
                {txType === 'expense' && (
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-2">
                    <label className="flex items-center justify-between text-xs font-semibold cursor-pointer">
                      <span className="flex items-center gap-1.5">
                        <Split className="w-3.5 h-3.5 text-purple-600" /> Split Across Multiple
                        Categories
                      </span>
                      <input
                        type="checkbox"
                        checked={txIsSplit}
                        onChange={(e) => setTxIsSplit(e.target.checked)}
                      />
                    </label>

                    {txIsSplit && (
                      <div className="space-y-2 pt-2">
                        {txSplits.map((sp, idx) => (
                          <div key={idx} className="grid grid-cols-3 gap-2">
                            <select
                              value={sp.categoryId}
                              onChange={(e) => {
                                const next = [...txSplits];
                                next[idx].categoryId = e.target.value;
                                setTxSplits(next);
                              }}
                              className="px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            >
                              {snapshot.categories
                                .filter((c) => c.type === 'expense' && !c.isArchived)
                                .map((c) => (
                                  <option key={c.id} value={c.id}>
                                    {c.name}
                                  </option>
                                ))}
                            </select>
                            <input
                              type="number"
                              step="0.01"
                              placeholder="Amount"
                              value={sp.amountStr}
                              onChange={(e) => {
                                const next = [...txSplits];
                                next[idx].amountStr = e.target.value;
                                setTxSplits(next);
                              }}
                              className="px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                            <input
                              type="text"
                              placeholder="Split note"
                              value={sp.note}
                              onChange={(e) => {
                                const next = [...txSplits];
                                next[idx].note = e.target.value;
                                setTxSplits(next);
                              }}
                              className="px-2 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() =>
                            setTxSplits([
                              ...txSplits,
                              { categoryId: 'cat_others_exp', amountStr: '0', note: '' },
                            ])
                          }
                          className="text-[11px] font-semibold text-purple-600 hover:underline"
                        >
                          + Add Another Split Line
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Tags, Notes & Receipt Attachment */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Tags (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={txTagsStr}
                      onChange={(e) => setTxTagsStr(e.target.value)}
                      placeholder="bazar, family, urgent"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      Receipt / Document Attachment
                    </label>
                    <input
                      type="text"
                      value={txAttachmentName}
                      onChange={(e) => setTxAttachmentName(e.target.value)}
                      placeholder="e.g., voucher_nov06.jpg"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                    Notes
                  </label>
                  <input
                    type="text"
                    value={txNotes}
                    onChange={(e) => setTxNotes(e.target.value)}
                    placeholder="Additional details..."
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsTxModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800"
                  >
                    {t(lang, 'cancel')}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                  >
                    {t(lang, 'save')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
