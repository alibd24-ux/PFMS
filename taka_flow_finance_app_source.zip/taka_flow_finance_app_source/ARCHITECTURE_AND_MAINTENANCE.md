# Future Update, Schema Migration & Maintenance Guide

This document defines the step-by-step engineering workflow for extending **TakaFlow Pro** without breaking existing user data or financial calculations.

---

## 1. Database Schema Versioning & Safe Migrations (`src/db/database.ts`)

All 19 object stores live inside `TakaFlowProDB` (currently `CURRENT_SCHEMA_VERSION = 2`):
- `AppSettings`, `Accounts`, `Transactions`, `TransactionSplits`, `Categories`, `Subcategories`, `Budgets`, `BudgetCategories`, `Contacts`, `Debts`, `DebtPayments`, `Loans`, `LoanPayments`, `SavingsGoals`, `SavingsContributions`, `RecurringTransactions`, `Attachments`, `Notifications`, `AuditLogs`.

### How to Add a New Entity or Index (e.g., `v2 -> v3`)
1. Increment `CURRENT_SCHEMA_VERSION` in `src/db/database.ts` from `2` to `3`.
2. Add the TypeScript interface to `src/types/models.ts` and include it in `DatabaseSnapshot`.
3. Inside `IndexedDBRepository.openDB().onupgradeneeded`, add a conditional migration block:
   ```ts
   if (oldVersion < 3) {
     // Create new objectStore or new index without clearing existing objectStores
   }
   ```
4. Update `FinancialEngine.validateBackupJson` and `FinancialEngine.restoreBackupSnapshot` to provide default empty arrays (`incoming.newStore || []`) so backups exported from older schema versions (`v1` or `v2`) restore cleanly into `v3`.

---

## 2. Adding a New Transaction Type or Financial Rule (`src/engine/financialEngine.ts`)

All balance, budget, debt, loan, and report calculations pass through `FinancialEngine`:
1. **`recalculateSnapshotIntegrity(snapshot)`**: Recomputes every account's `currentBalancePoisha` from `openingBalancePoisha` + ledger transactions, reconciles `Debts` (`paidPoisha`, `remainingPoisha`, `status`), and reconciles `SavingsGoals`.
2. **`computeCategoryNetExpenses(snapshot, dateFrom, dateTo)`**: Calculates category spending for Budgets and Reports, factoring in `TransactionSplits` and subtracting `refund` transactions.
3. **`computeDashboardMetrics(snapshot, dateFrom, dateTo)`**: Computes the 8 Dashboard KPIs and Net Worth.

When introducing a new financial operation:
- Add its ledger rule in `recalculateSnapshotIntegrity` first.
- Add a unit test scenario in `tests/runFinancialTests.js`.
- Run `node tests/runFinancialTests.js` to confirm all 15 baseline regression tests continue to pass.
