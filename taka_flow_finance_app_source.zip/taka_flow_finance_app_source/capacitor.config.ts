// Capacitor Android & PWA Packaging Configuration
const config = {
  appId: 'com.takaflow.pro.finance',
  appName: 'TakaFlow Pro',
  webDir: 'dist',
  bundledWebRuntime: false,
  plugins: {
    Keyboard: {
      resize: 'body',
      style: 'DARK',
      resizeOnFullScreen: true,
    },
  },
};

export default config;
