# TakaFlow Pro (টাকাফ্লো প্রো) — Personal Finance & Dena-Pawna Management System

TakaFlow Pro is an original, production-oriented, local-first Personal Finance Management application built with **React**, **TypeScript**, **Material Design 3** principles, and a versioned **IndexedDB** database engine.

---

## 1. Architecture Overview

The project is separated into clean, decoupled layers so UI components never directly mutate account balances or bypass financial rules:

```text
taka_flow_finance_app/
├── package.json
├── tsconfig.json
├── capacitor.config.ts               # Android APK / Capacitor configuration
├── public/
│   └── manifest.json                 # Offline PWA manifest
├── src/
│   ├── types/
│   │   └── models.ts                 # 19 Normalized, versioned TypeScript entities
│   ├── utils/
│   │   └── money.ts                  # Integer minor-unit (poisha) math & ৳ 1,25,000.00 formatter
│   ├── i18n/
│   │   └── translations.ts           # Bengali (বাংলা) & English localization dictionary
│   ├── db/
│   │   └── database.ts               # IndexedDB v2 repository, migrations, & seed data
│   ├── engine/
│   │   └── financialEngine.ts        # Centralized Financial Calculation & Integrity Engine
│   ├── modules/
│   │   ├── DashboardModule.tsx       # 8 KPIs, 7 Date Filters, Charts, Upcoming Bills & Loans
│   │   ├── TransactionsModule.tsx    # 8 Transaction Types, Splits, Search, & Saved Presets
│   │   ├── AccountsModule.tsx        # Unlimited Accounts, Statements, & Safe Migration
│   │   ├── CategoriesModule.tsx      # Custom Groups, Subcategories, Reorder, & Safe Merge
│   │   ├── BudgetsModule.tsx         # Category/Account Budgets & 50/75/90/100% Warnings
│   │   ├── DebtsModule.tsx           # Dena-Pawna (Payables & Receivables) & Statements
│   │   ├── LoansSavingsRecurringModule.tsx # Loans/EMIs, Savings Goals & Recurring Rules
│   │   ├── ReportsModule.tsx         # 15 Financial Reports & CSV/Excel/PDF Exports
│   │   └── SettingsDataModule.tsx    # Themes, Localization & Validated JSON Backup/Restore
│   └── App.tsx                       # Root shell, Bottom Nav, FAB, & Android Back-button hook
├── tests/
│   └── runFinancialTests.js          # Automated test suite verifying all 15 scenarios
└── ARCHITECTURE_AND_MAINTENANCE.md   # Future update & schema migration guide
```

---

## 2. Setup, Testing & Build Instructions

### Run Automated Financial Integrity Tests
```bash
node tests/runFinancialTests.js
```

### Local Development & Production Web Bundle
```bash
npm install
npm run typecheck
npm run build
```

### Android APK Packaging (via Capacitor)
```bash
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

---

## 3. Financial Integrity Guarantees

1. **Integer Minor-Unit Storage (`poisha`)**: All monetary values are stored and calculated as integer `poisha` (`1 BDT = 100 poisha`), eliminating IEEE-754 floating-point drift.
2. **Derived Account Balances**: `currentBalancePoisha` is never edited in isolation; it is deterministically computed from `openingBalancePoisha` plus verified ledger entries.
3. **Strict Transaction Type Accounting**:
   - `transfer`: Deducts from source account and credits destination account; never counted as income, expense, or budget spending.
   - `refund`: Credits the account and reverses spending on the refunded expense category.
   - `loan_given` / `loan_received` / `debt_collection` / `debt_repayment`: Updates account balances and Dena-Pawna (`Debts`) or `Loans` principal without polluting ordinary income/expense reports.
   - `SavingsContributions`: Tracks deposits/withdrawals toward `SavingsGoals` without double-counting as expenses.
